package com.yash.ytms.services.ServiceImpls;

import java.time.LocalTime;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ytms.domain.Holiday;
import com.yash.ytms.dto.HolidayDto;
import com.yash.ytms.repository.HolidayRepository;
import com.yash.ytms.services.IServices.IHolidayService;

@Service
public class HolidaySerivceImpl implements IHolidayService {
	final Logger LOGGER = LoggerFactory.getLogger(HolidaySerivceImpl.class);

	@Autowired
	private ModelMapper modelMapper;
	@Autowired
	private HolidayRepository holidayRepository;

	@Override
	public List<HolidayDto> saveAllHolidays(List<HolidayDto> holidayDto) {
		LOGGER.info("In Save All Holidays");
		List<Holiday> holidays = holidayDto.stream().map(dto -> modelMapper.map(dto, Holiday.class)).collect(Collectors.toList());
		holidays.forEach(holiday -> holiday.setStart(holiday.getStart_date().atTime(LocalTime.MIDNIGHT)));
		holidays = holidayRepository.saveAllAndFlush(holidays);
		List<HolidayDto> dtos = holidays.stream().map(dto -> modelMapper.map(dto, HolidayDto.class))
				.collect(Collectors.toList());
		return dtos;
	}

	@Override
	public List<HolidayDto> getAllHolidays() {
		LOGGER.info("In Get All Holidays");
		return holidayRepository.findAll().stream().map(dto->modelMapper.map(dto,HolidayDto.class)).collect(Collectors.toList());
	}

}
