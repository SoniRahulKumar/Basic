export class TrainerAttendance {
  id?: string;

  training_id?: string;

  tranier_mail_id?: string;

  tranier_name?: string;

  tranining_name?: string;

  attendance_status?: boolean;

  attendance_date?: string;

  leave_Start_date?: Date;

  leave_End_date?:Date;

  leave_Start_time?: String;

  leave_End_time?:string;

  leave_status?: string;
  
  leave_impact_on_traning?:string;
}