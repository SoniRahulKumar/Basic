package com.yash.ytms.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ytms.dto.AssociateDto;
import com.yash.ytms.dto.AssociateExcelDto;
import com.yash.ytms.services.IServices.IAssociateService;

@RestController
@RequestMapping("/associate")
public class AssociateController {

	@Autowired
	private IAssociateService associateService;

	final Logger LOGGER = LoggerFactory.getLogger(AssociateController.class);

	@PostMapping("/uploadAssociate")
	public List<AssociateExcelDto> uploadAssociate(@RequestParam("file") MultipartFile file) {
		List<AssociateExcelDto> associateDtoList = null;
		LOGGER.info("FileName" + file.getOriginalFilename());
		try {
			associateDtoList = associateService.parseExcel(file);
			associateDtoList.stream().forEach(System.out::println);
			LOGGER.info("uploading file");
			return associateDtoList;
		} catch (Exception e) {
			LOGGER.error("Error i uploading file" + e);
			return associateDtoList;
		}
	}

	@GetMapping("/getAllAssociateTrainings")
	public List<AssociateDto> getAllAssociateTrainings() {
		LOGGER.info("Getting all getAllAssociateTrainings");
		return associateService.getAllAssociateTrainings();
	}
}
