package com.yash.yotaapi.services.impls;

import com.yash.yotaapi.dto.TestDto;
import com.yash.yotaapi.dto.TestsDto;
import com.yash.yotaapi.entity.Tests;
import com.yash.yotaapi.entity.Trainings;
import com.yash.yotaapi.entity.UserTrainingTest;
import com.yash.yotaapi.entity.YotaUser;
import com.yash.yotaapi.exceptions.ApplicationException;
import com.yash.yotaapi.exceptions.TestAvailableException;
import com.yash.yotaapi.exceptions.TrainingException;
import com.yash.yotaapi.repositories.TestRepository;
import com.yash.yotaapi.repositories.TrainingRepository;
import com.yash.yotaapi.repositories.UserTrainingTestRepository;
import com.yash.yotaapi.repositories.YotaUserRepository;
import com.yash.yotaapi.services.IServices.ITestService;
import io.jsonwebtoken.lang.Assert;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

@Service
public class TestServiceImpl implements ITestService {

    @Autowired
    private TestRepository testRepository;

    @Autowired
    private YotaUserRepository yotaUserRepository;

    @Autowired
    private ModelMapper mapper;

    @Autowired
    private UserTrainingTestRepository userTrainingTestRepository;

    @Autowired
    private TrainingRepository trainingRepository;

    private Logger logger = LoggerFactory.getLogger(TestServiceImpl.class);

    @Override
    public TestDto addTest(TestDto testDto) {
        // Check if the test already exists
        Tests existingTest = testRepository.findByTestTitle(testDto.getTestTitle());
        if (existingTest != null) {
            throw new TestAvailableException("Test is already exist");
        }
        Tests test = mapper.map(testDto, Tests.class);
        test = testRepository.save(test);
        Assert.notNull(test);
        return this.mapper.map(test, TestDto.class);
    }

    @Override
    public List<TestDto> fetchAllTest() {
        List<Tests> tests = testRepository.findAll();
        return tests.stream().map(t -> this.mapper.map(t, TestDto.class)).collect(Collectors.toList());
    }

    @Override
    public Optional<TestDto> findById(Long id) {
        Optional<Tests> tests = testRepository.findById(id);
        TestDto testDto = new TestDto();
        tests.ifPresent((test) -> {
            testDto.setId(test.getId());
            testDto.setTestTitle(test.getTestTitle());
            testDto.setDescription(test.getTestDescription());
            testDto.setInstruction(test.getTestInstruction());
            testDto.setType(test.getType());
            testDto.setTotalQuestions(test.getTotalQuestions());
            testDto.setTotalTime(test.getTotalTime());
        });

        return Optional.of(testDto);
    }

    public Long getAppearedTestCountByAssociateEmail(String email) throws ApplicationException {

        List<Long> testsId = testRepository.getTestIdByEmailId(email);
        Long appearedTestCount = 0L; // Initialize count to 0
        if (testsId.isEmpty()) {
            throw new ApplicationException("No Test assigned to the associate with email: " + email);
        }
        for (Long testId : testsId) {
            Long count = testRepository.countTestsByTestIdAndNotEmptyResultId(testId);
            appearedTestCount += count; // Add individual test counts to total
        }

        // Handle case where no tests are assigned to the user
        if (appearedTestCount == 0L) {
            return 0L; // Return 0 if no tests appeared in
        }

        return appearedTestCount;
    }

    public List<TestsDto> getTestsByAssociateEmail(String email) throws ApplicationException {
        YotaUser userByEmail = yotaUserRepository.getUserByEmail(email);
        List<Long> testIds = testRepository.getTestIdByEmpId(userByEmail.getEmpId());
        List<TestsDto> testsDTOs = new ArrayList<>();


        for (Long testId : testIds) {
            Optional<Tests> optionalTests = testRepository.findById(testId); // Fetch test by ID
            optionalTests.ifPresent(tests -> {
                TestsDto testsDTO = new TestsDto();
                testsDTO.setId(tests.getId());
                testsDTO.setTestTitle(tests.getTestTitle());
                testsDTO.setTestDescription(tests.getTestDescription());
                testsDTO.setTestInstruction(tests.getTestInstruction());
                testsDTO.setStatus(tests.getStatus());
                testsDTO.setStartDate(tests.getStartDate());
                testsDTO.setEndDate(tests.getEndDate());
                testsDTO.setCreated_at(tests.getCreatedAt());
                testsDTO.setModified_at(tests.getModifiedAt());
                testsDTO.setEndTime(tests.getEndTime());
                testsDTO.setTestType(tests.getType());
                testsDTOs.add(testsDTO);
            });
        }

        if (testsDTOs.isEmpty()) {
            throw new ApplicationException("No training assigned to the associate with email: " + email);
        }
        return testsDTOs;
    }

    public TestsDto getTestResultByUserEmailAndTestId(String email, Long testId) throws ApplicationException {
        Optional<Tests> optionalTest = testRepository.findByTestIdAndUserEmail(testId, email);

        if (!optionalTest.isPresent()) {
            throw new ApplicationException("No test found for the given email and test ID");
        }

        Tests tests = optionalTest.get();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        TestsDto testsDTO = new TestsDto();
        testsDTO.setId(tests.getId());
        testsDTO.setTestTitle(tests.getTestTitle());
        testsDTO.setTestDescription(tests.getTestDescription());
        testsDTO.setTestInstruction(tests.getTestInstruction());
        testsDTO.setStatus(tests.getStatus());
        testsDTO.setStartDate(tests.getStartDate());
        testsDTO.setEndDate(tests.getEndDate());
        testsDTO.setCreated_at(tests.getCreatedAt());
        testsDTO.setModified_at(tests.getModifiedAt());
        testsDTO.setEndTime(tests.getEndTime());
        testsDTO.setTestType(tests.getType());

        return testsDTO;
    }

    @Override
    @Transactional
    public void assignTestToUser(Long testId, Long trainingId, Long empId) {
        AtomicInteger atomicInteger = new AtomicInteger(1);
        boolean alreadyExit = userTrainingTestRepository.existsByTestIdAndTrainingsIdAndUserEmpId(testId, trainingId, empId);
        Tests test = testRepository.findById(testId)
                .orElseThrow(() -> new ApplicationException("Test with ID " + testId + " not found"));

        Trainings training = trainingRepository.findById(trainingId)
                .orElseThrow(() -> new TrainingException("Training is not available for trainingId :-" + trainingId, HttpStatus.BAD_REQUEST));

        YotaUser user = yotaUserRepository.findByempId(empId);
        if (user == null) {
            throw new ApplicationException("User with ID " + empId + " not found");
        }

        if (alreadyExit) {
            throw new TrainingException("This data is already present", HttpStatus.BAD_REQUEST);
        } else {
            UserTrainingTest userTrainingTest = new UserTrainingTest();
            userTrainingTest.setUser(user);
            userTrainingTest.setTrainings(training);
            userTrainingTest.setTest(test);
            Integer count = trainingRepository.countAssociateToAddedTraining(testId);
            int totalCount = count + atomicInteger.getAndIncrement();
            testRepository.updateTotalAssociateCount(totalCount, testId);
            userTrainingTestRepository.save(userTrainingTest);
        }
    }

    @Override
    public String addQuestionInTest(Long testId, List<Long> questionIds) {
        AtomicInteger atomicInteger = new AtomicInteger(0);
        questionIds.forEach(questionId -> {
            Integer i = testRepository.addQuestionsInTest(testId, questionId);
            atomicInteger.getAndIncrement();
        });
        if (atomicInteger.get() == 0) {
            return "Something went wrong while adding question in test";
        } else {
            return "Question added successfully in test.!!";
        }
    }

    @Override
    public String updateTotalQuestionCount(Integer totalQuestionCount, Long testId) {
        Integer i = testRepository.updateTotalQuestionCount(totalQuestionCount, testId);
        if (i > 0) {
            return "Total question count updated successfully";
        } else {
            return "Something went wrong while updating question count";
        }
    }

    @Override
    public boolean updateTestStatus(long testTitle) {
        boolean status = false;
        try {
            Tests tests = testRepository.findById(testTitle).orElseThrow(() -> new NullPointerException("Test Not Found!! "));
            logger.info("{} ", tests);

            String strStatus = tests.getStatus();
            if ("UNASSIGNED".equals(strStatus)) {
                tests.setStatus("ASSIGNED");
                testRepository.save(tests);
                status = true;
            }
        } catch (Exception e) {
            logger.error("Error updating test assignment status: {}", e.getMessage());
            throw new RuntimeException("Error updating test assignment status", e);
        }
        return status;
    }

}
