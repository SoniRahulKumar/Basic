package com.yash.ytms.repository;

import com.yash.ytms.domain.Associate;
import com.yash.ytms.dto.AssociateDto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AssociateRepository extends JpaRepository<Associate, Long> {
    @Query("select new com.yash.ytms.dto.AssociateDto(n.emp_id,n.emp_name,n.emp_mail_id,n.grade,n.competency,t.trainingName,t.trainingDescription,t.noOfDays," +
            "t.actualStartDate,t.actualEndDate,n.skill,t.upgradedSkills, n.current_allocation,n.project,n.current_location,t.trainingStatus, n.feedback,n.finalScore,t.trainer) " +
            " from Nomination n, TrainingRequestForm t where n.trainingId=t.id ")
    List<AssociateDto> findAllAssociateTrainingById();
    
    @Query("select new com.yash.ytms.dto.AssociateDto(n.emp_id,n.emp_name,n.emp_mail_id,n.grade,n.competency,t.id,t.trainingName,t.trainingDescription,t.noOfDays," +
            "t.actualStartDate,t.actualEndDate,n.skill,t.upgradedSkills, n.current_allocation,n.project,n.current_location,t.trainingStatus, n.feedback,n.finalScore,t.trainer) " +
            " from Nomination n, TrainingRequestForm t where n.trainingId=t.id and n.emp_mail_id=:empId ")
    List<AssociateDto> findAllAssociateTrainingByMailId(@Param(value = "empId") String empId);
    
    
    @Query("select new com.yash.ytms.dto.AssociateDto(n.emp_id,n.emp_name,n.emp_mail_id,n.grade,n.competency,t.trainingName,t.trainingDescription,t.noOfDays," +
            "t.actualStartDate,t.actualEndDate,n.skill,t.upgradedSkills, n.current_allocation,n.project,n.current_location,t.trainingStatus, n.feedback,n.finalScore,t.trainer) " +
            " from Nomination n, TrainingRequestForm t where n.trainingId=t.id and n.requestor=:requestor ")
    List<AssociateDto> findAllAssociateTrainingByIdAndRequestor(@Param(value = "requestor") String requestor);
}
