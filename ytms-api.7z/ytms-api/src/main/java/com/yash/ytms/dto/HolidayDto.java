package com.yash.ytms.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class HolidayDto {

//	private Long id;
	private String title;// Name Of Holiday
	private String start;// 00:00 convert LocalDate to LocalDate Time
	private LocalDate start_date;// to compare
	private boolean allDay = true;// always true
	private String backgroundColor = "#FFE0B2";
	private String eventBorderColor = "#aaa";
	private String eventTextColor = "#000";
	private String display = "background";
}
