package com.yash.ytms.dto;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

public class AttendanceDto {

	
	private Long id;
	private String emp_id;
	private String emp_mail_id;
	private Long trainingId;
	private Long attendance_percentage;
	private Long attendance_status;
	private Date actualStartDate;
	private Date actualEndDate;
	private Date currentDate;


}
