import React, { createContext } from "react";

const ReviewQuestionContext = createContext();

export default ReviewQuestionContext;