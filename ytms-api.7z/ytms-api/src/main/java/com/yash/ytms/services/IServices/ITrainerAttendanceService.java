package com.yash.ytms.services.IServices;

import java.util.List;

import com.yash.ytms.domain.TrainerAttedance;
import com.yash.ytms.dto.TrainerAttedanceDto;

public interface ITrainerAttendanceService {

	List<TrainerAttedanceDto> getPendingLeaves();

	TrainerAttedanceDto approvePendingLeave(TrainerAttedanceDto trainerAttedanceDto);
	
	public List<TrainerAttedance> saveAll(List<TrainerAttedance> trainerAttedances);
	
	
	List<TrainerAttedanceDto> approvedLeaves();
}
