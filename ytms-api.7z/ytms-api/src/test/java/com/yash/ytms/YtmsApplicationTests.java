package com.yash.ytms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YtmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
