package com.yash.ytms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.ytms.domain.TrainerAttedanceDate;


public interface TrainerAttendanceDateRepository extends JpaRepository<TrainerAttedanceDate,Long> {
	
	 
}
