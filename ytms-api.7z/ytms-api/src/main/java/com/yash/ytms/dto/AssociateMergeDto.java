package com.yash.ytms.dto;

import com.yash.ytms.domain.Nomination;
import com.yash.ytms.domain.TrainingRequestForm;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssociateMergeDto {

    private TrainingRequestForm trainingRequestForm;
    private List<Nomination> nominationList;
}
