package com.yash.ytms.services.IServices;

import java.util.List;

import com.yash.ytms.domain.OptionalHoliday;

public interface IOptionalHolidayService {
	
	OptionalHoliday addNewOptHoliday(OptionalHoliday holidayDto);

	List<OptionalHoliday> list();
	
	List<OptionalHoliday> addNewOptHolidays(List<OptionalHoliday> holidayDto);
	
	List<String> listOptDays();
}
