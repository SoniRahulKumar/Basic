package com.yash.yotaapi.constants;

/**
 * Project Name - YOTASecurityPOC
 * <p>
 * IDE Used - IntelliJ IDEA
 *
 * @author - yashr
 * @since - 02-04-2024
 */
public class AppConstants {

    public static final String DECLINED_USER_MESSAGE = "Your Request is Declined by Admin !";

    public static final String NEW_USER_REGISTRATION_SUCCESS_MESSAGE = "Account creation request submitted successfully to Technical Manager";
}
