package com.yash.ytms.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytms.dto.TrainingRequestFormDto;
import com.yash.ytms.dto.YtmsUserDto;
import com.yash.ytms.services.IServices.ITrainerService;

@RestController
@RequestMapping("/trainer")
public class TrainerController {

	final Logger LOGGER = LoggerFactory.getLogger(TrainerController.class);

	@Autowired
	private ITrainerService trainerService;

	@PostMapping("/getTrainers")
	public List<YtmsUserDto> getTrainerTrainingList(@RequestBody TrainingRequestFormDto trainingRequestFormDto) {
		LOGGER.info("Getting Available  Trainers ",trainingRequestFormDto);
		return trainerService.list(trainingRequestFormDto);
	}

}
