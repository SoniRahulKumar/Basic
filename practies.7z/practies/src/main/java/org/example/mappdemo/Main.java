package org.example.mappdemo;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

public class Main {

    public static void main(String[] args) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {

        HashMap<Student, String> map = new HashMap<>();
        map.put(new Student(1), "A");
        map.put(new Student(2), "B");
        map.put(new Student(3), "C");
        map.put(new Student(4), "D");
        map.put(new Student(5), "E");
        map.put(new Student(6), "F");
        map.put(new Student(7), "G");
        map.put(new Student(8), "H");
        map.put(new Student(9), "I");
        map.put(new Student(10), "J");
        map.put(new Student(11), "K");
        map.put(new Student(12), "L");
        map.put(new Student(13), "M");
        map.put(new Student(14), "J");
        map.put(new Student(15), "K");
        map.put(new Student(16), "L");
        map.put(new Student(17), "M");
//        map.put("k1", "v1");
//        map.put("k2", "v2");
//        map.put("k3", "v2");
//        map.put("k4", "v2");
//        map.put("k5", "v1");
//        map.put("k6", "v1");
//        map.put("k7", "v1");
//        map.put("k8", "v1");
//        map.put("k9", "v1");
//        map.put("k10", "v1");
//        map.put("k11", "v1");
        for (Integer i=1; i<=100; i++) {

            map.put(new Student(1), String.valueOf(i));

        }

    }
}
