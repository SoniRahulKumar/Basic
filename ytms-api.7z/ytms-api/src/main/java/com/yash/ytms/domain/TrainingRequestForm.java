package com.yash.ytms.domain;

import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.annotations.Formula;
import org.hibernate.annotations.SQLDelete;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.repository.Query;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Component
@SQLDelete(sql = "UPDATE Training SET Status = true WHERE id=?")
@Table(name = "Training_Managment")
@Entity
public class TrainingRequestForm {

	/** Unique identifier for the training. */

	@Id

	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private long id;

	/** Name used to identify the training. */

	@Size(min = 3, max = 25, message = "Training identifier name should be between 3 to 25 characters only")

	private String trainingIdentifierName;

	/** Name of the training. */

	@NotEmpty(message = "Training name is mandatory")

	@Column(unique = false, nullable = false)

	private String trainingName;

	/** Description of the training. */

	@NotBlank(message = "Training description is mandatory")

	private String trainingDescription;

	/** Start date of the training. */

	@NotNull(message = "Start date cannot be Null")

	@JsonFormat(pattern = "yyyy-MM-dd")

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)

	private Date startDate;

	/** End date of the training. */

	@JsonFormat(pattern = "yyyy-MM-dd")

	@NotNull(message = "End date cannot be null")

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)

	private Date endDate;

	/** Actual start date of the training. */

	@JsonFormat(pattern = "yyyy-MM-dd")

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)

	private Date actualStartDate;

	/** Actual end date of the training. */

	@JsonFormat(pattern = "yyyy-MM-dd")

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Column(name="actual_end_date")
	private Date actualEndDate;

	/** Date when the training was created. */

	@JsonFormat(pattern = "yyyy-MM-dd")

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)

	@CreatedDate

	private Date createdAt;

	/** Date when the training was last updated. */

	@JsonFormat(pattern = "yyyy-MM-dd")

	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)

	@LastModifiedDate

	private Date updatedAt;

	/** Status of the training. */

	private String status;

	/** Transient field for storing user name. */

//	@Transient

	private String userName;

	@Column(columnDefinition="varchar(255) default 'Planned'")
	private String trainingStatus;

	private int noOfParticipant;
	
	private String trainer;
	
	private String trainerEmail;

	//to be used only in case of request declined
	private String declinedMessage;
	//@Column(columnDefinition="String default 'Planned'")
//	private String trainingStatus;
	
	@Formula(value = "(SELECT COUNT(*) FROM Nominations v WHERE v.training_id=id)")
	private int noOfActualParticipant;
	
	@Column(columnDefinition="int default '0'")
	private int noOfDays;
	
	private String upgradedSkills;
	
	private String startTime;
	
	private String endTime;
	
	private String actualStartTime;
	
	private String actualEndTime;
	
	private String monthAndYear;
	
	@Formula(value = "(SELECT yu.full_name FROM ytms_user yu WHERE yu.email_add=user_name)")
	private String requestedBy;
	
	@Formula(value = "(SELECT c.name FROM ytms_user yu,competency_master c WHERE yu.competency=c.id and yu.email_add=user_name)")
	private String competency;
	
	@Formula(value = "(SELECT g.name FROM ytms_user yu,grade_master g WHERE yu.grade=g.id and yu.email_add=user_name)")
	private String grade;

	/** Pre-persist action to set the created date. */

	@PrePersist

	public void onCreate() {

		this.createdAt = new Date();

	}

	/** Pre-update action to set the updated date. */

	@PreUpdate

	public void onUpdate() {

		this.updatedAt = new Date();

	}

}
