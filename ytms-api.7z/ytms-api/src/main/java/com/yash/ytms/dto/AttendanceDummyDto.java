package com.yash.ytms.dto;

public interface AttendanceDummyDto {

	

	 String getEmp_mail_id();
	 Long getTraning_id();
	 Double getAttendance_percentage();
	


}
