package com.yash.dtoexcelconvertor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DtoExcelConvertorApplicationTests {

	@Test
	void contextLoads() {
	}

}
