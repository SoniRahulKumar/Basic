package com.yash.ytms.services.ServiceImpls;

import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yash.ytms.domain.OptionalHoliday;
import com.yash.ytms.repository.OptionalHolidayRepository;
import com.yash.ytms.services.IServices.IOptionalHolidayService;

@Service
@Transactional
public class OptionalHolidayService implements IOptionalHolidayService {
	
	
	
	@Autowired
	private  OptionalHolidayRepository optionalHolidayRepository;


	@Override
	public OptionalHoliday addNewOptHoliday(OptionalHoliday holidayDto) {
		optionalHolidayRepository.save(holidayDto);
		return holidayDto;

	}

	@Override
	public List<OptionalHoliday> list() {
		List<OptionalHoliday> list = optionalHolidayRepository.findAll();
		return list;
	}

	@Override
	public List<OptionalHoliday> addNewOptHolidays(List<OptionalHoliday> holidayDtos) {
		return optionalHolidayRepository.saveAll(holidayDtos);
	}

	@Override
	public List<String> listOptDays() {
		return list().stream().map(OptionalHoliday::getDate).map(e->e.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))).toList();
	}

}
