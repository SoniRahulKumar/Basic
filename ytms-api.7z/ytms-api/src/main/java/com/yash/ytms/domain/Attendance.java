package com.yash.ytms.domain;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "attendance_report")
public class Attendance {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column
	private String emp_id;
	@Column
	private String emp_mail_id;
	
	@Column
	private String emp_name;
	
	@Column
	private Double  attendance_percentage;
	
	@Column
	private boolean attendance_status;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column
	private Date actualStartDate;
	
	@Column
	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private Date actualEndDate;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column
	private Date presentDate;
	
	@Column
	private Long traning_id;

	
	@Column
	private Double traning_noOfDays;
	
	@Column
	private Double attend_noOfDays;
	
	@Column(name="reason_for_Leave")
	private String reasonForLeave;

	@Column(columnDefinition="varchar(255) default 'Active'")
	private String employmentStatus;
}
