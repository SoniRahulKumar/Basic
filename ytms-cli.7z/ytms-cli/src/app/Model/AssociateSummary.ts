export class AssociateSummaryModel{
    sNo?:string;
    emp_id!:string;
    emp_name!:string;
    emp_mail_id!:string;
    noOfTrainingsAttended!:string;
}
