package com.yash.dtoexcelconvertor.Convertor;

import org.springframework.stereotype.Component;

@Component
public class ConvertDtoToExcel {

    public void convertDtoToExcel(Object object) {

    }
}
