package com.yash.ytms.util;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.yash.ytms.dto.AssociateDto;
import com.yash.ytms.dto.AssociateSummaryDto;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

public class ExcelExporter {

	private XSSFWorkbook workbook;
	private XSSFSheet sheet;

	private List<AssociateSummaryDto> associateList;
	private List<AssociateDto> associateMgmtList;

	public ExcelExporter(List<AssociateSummaryDto> listUsers) {
		this.associateList = listUsers;
		workbook = new XSSFWorkbook();
	}

	private void writeHeader() {
		sheet = workbook.createSheet("Associates");
		Row row = sheet.createRow(0);
		CellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setBold(true);
		font.setFontHeight(16);
		style.setFont(font);
		createCell(row, 0, "Emp ID", style);
		createCell(row, 1, "Employee Name", style);
		createCell(row, 2, "Employee Email", style);
		createCell(row, 3, "No of Trainings Attended", style);
	}

	private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
		sheet.autoSizeColumn(columnCount);
		Cell cell = row.createCell(columnCount);
		if (valueOfCell instanceof Integer) {
			cell.setCellValue((Integer) valueOfCell);
		} else if (valueOfCell instanceof Long) {
			cell.setCellValue((Long) valueOfCell);
		} else if (valueOfCell instanceof String) {
			cell.setCellValue((String) valueOfCell);
		} else if (valueOfCell instanceof Date) {
			cell.setCellValue((Date) valueOfCell);
		}else if (valueOfCell instanceof Double) {
			cell.setCellValue((Double) valueOfCell);
		}else if (valueOfCell instanceof Boolean) {
			cell.setCellValue((Boolean) valueOfCell);
		}else if (valueOfCell == null) {
			cell.setCellValue(null+"");
		}else {
			cell.setCellValue(valueOfCell.toString());
		}
		cell.setCellStyle(style);
	}

	private void write() {
		int rowCount = 1;
		CellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setFontHeight(14);
		style.setFont(font);
		for (AssociateSummaryDto record : associateList) {
			Row row = sheet.createRow(rowCount++);
			int columnCount = 0;
			createCell(row, columnCount++, record.getEmp_id(), style);
			createCell(row, columnCount++, record.getEmp_name(), style);
			createCell(row, columnCount++, record.getEmp_mail_id(), style);
			createCell(row, columnCount++, record.getNoOfTrainingsAttended(), style);
		}
	}

	public void generateExcelFile(HttpServletResponse response) throws IOException {
		writeHeader();
		write();
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();
	}
	
	public ExcelExporter(List<AssociateDto> listUsers,String dtoType) {
		this.associateMgmtList = listUsers;
		workbook = new XSSFWorkbook();
	}

	private void writeAssociateMgmtHeader() {
		sheet = workbook.createSheet("AssociateManagementData");
		Row row = sheet.createRow(0);
		CellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setBold(true);
		font.setFontHeight(16);
		style.setFont(font);
		createCell(row, 0, "emp_id", style);
		createCell(row, 1, "emp_name", style);
		createCell(row, 2, "emp_mail_id", style);
		createCell(row, 3, "grade", style);
		createCell(row, 4, "trainingName", style);
		createCell(row, 5, "noOfDays", style);
		createCell(row, 6, "actualStartDate", style);
		createCell(row, 7, "actualEndDate", style);
		createCell(row, 8, "skill", style);
		createCell(row, 9, "upgraded skill", style);
		createCell(row, 10, "current_allocation", style);
		createCell(row, 11, "project", style);
		createCell(row, 12, "current_location", style);
		createCell(row, 13, "trainingStatus", style);
		createCell(row, 14, "final score", style);
		createCell(row, 15, "feedback", style);
	}

	private void writeAssociateMgmt() {
		int rowCount = 1;
		CellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setFontHeight(14);
		style.setFont(font);
		for (AssociateDto record : associateMgmtList) {
			Row row = sheet.createRow(rowCount++);
			int columnCount = 0;
			createCell(row, columnCount++, record.getEmp_id(), style);
			createCell(row, columnCount++, record.getEmp_name(), style);
			createCell(row, columnCount++, record.getEmp_mail_id(), style);
			createCell(row, columnCount++, record.getGrade(), style);
			createCell(row, columnCount++, record.getTrainingName(), style);
			createCell(row, columnCount++, record.getNoOfDays(), style);
			createCell(row, columnCount++, record.getActualStartDate()==null?record.getActualStartDate():record.getActualStartDate().toLocaleString(), style);
			createCell(row, columnCount++, record.getActualEndDate()==null?record.getActualEndDate():record.getActualEndDate().toLocaleString(), style);
			createCell(row, columnCount++, record.getSkill(), style);
			createCell(row, columnCount++, record.getUpgradedSkills(), style);
			createCell(row, columnCount++, record.getCurrent_allocation(), style);
			createCell(row, columnCount++, record.getProject(), style);
			createCell(row, columnCount++, record.getCurrent_location(), style);
			createCell(row, columnCount++, record.getTrainingStatus(), style);
			createCell(row, columnCount++, record.getFinalScore(), style);
			createCell(row, columnCount++, record.getFeedback(), style);
			
		}
	}

	public void generateAssociateMgmtExcelFile(HttpServletResponse response) throws IOException {
		writeAssociateMgmtHeader();
		writeAssociateMgmt();
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();
	}
	
}