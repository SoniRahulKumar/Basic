package com.yash.ytms.services.IServices;

import java.util.List;

import com.yash.ytms.dto.TrainingRequestFormDto;
import com.yash.ytms.dto.YtmsUserDto;

public interface ITrainerService {


	
	public List<YtmsUserDto> list(TrainingRequestFormDto trainingRequestFormDto);
	
	
}
