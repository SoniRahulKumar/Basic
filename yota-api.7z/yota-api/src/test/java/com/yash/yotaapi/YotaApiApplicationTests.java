package com.yash.yotaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YotaApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
