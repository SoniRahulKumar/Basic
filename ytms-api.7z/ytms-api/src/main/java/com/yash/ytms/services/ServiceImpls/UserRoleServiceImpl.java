package com.yash.ytms.services.ServiceImpls;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.yash.ytms.constants.UserRoleTypes;
import com.yash.ytms.domain.UserRole;
import com.yash.ytms.dto.UserRoleDto;
import com.yash.ytms.exception.ApplicationException;
import com.yash.ytms.repository.UserRoleRepository;
import com.yash.ytms.services.IServices.IUserRoleService;

/**
 * Project Name - ytms-api
 * <p>
 * IDE Used - IntelliJ IDEA
 *
 * @author - yash.raj
 * @since - 25-01-2024
 */
@Service
public class UserRoleServiceImpl implements IUserRoleService {
	final Logger LOGGER = LoggerFactory.getLogger(UserRoleServiceImpl.class);

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private UserRoleRepository roleRepository;

    @Override
    public UserRoleDto createUserRole(UserRoleDto userRoleDto) {
    	LOGGER.info("In Create User Role");
        UserRole userRole = null;
        if (ObjectUtils.isNotEmpty(userRoleDto)) {
            userRole = this
                    .modelMapper
                    .map(userRoleDto, UserRole.class);

            userRole = this
                    .roleRepository
                    .save(userRole);

            userRoleDto = this
                    .modelMapper
                    .map(userRole, UserRoleDto.class);
        } else {
            throw new ApplicationException("User Role Details are empty or null");
        }

        return userRoleDto;
    }

    @Override
    public UserRoleDto getUserRoleById(Long roleId) {
    	LOGGER.info("In Get User Role By ID");
        UserRoleDto userRoleDto = null;
        UserRole userRole = null;

        if (ObjectUtils.isNotEmpty(roleId)) {
            userRole = this
                    .roleRepository
                    .getUserRoleByRoleId(roleId);

            if (ObjectUtils.isNotEmpty(userRole)) {
                userRoleDto = this
                        .modelMapper
                        .map(userRole, UserRoleDto.class);
            } else {
                throw new ApplicationException("User Role not found with the provided Id");
            }
        } else {
            throw new ApplicationException("User Role Id is empty or null");
        }

        return userRoleDto;
    }

    @Override
    public UserRoleDto getUserRoleByRoleName(String roleName) {
    	LOGGER.info("In Get User Role By Role Name");
        UserRoleDto userRoleDto = null;
        UserRole userRole = null;

        if (StringUtils.isNotEmpty(roleName)) {
            userRole = this
                    .roleRepository
                    .getUserRoleByRoleName(roleName);

            if (ObjectUtils.isNotEmpty(userRole)) {
                userRoleDto = this
                        .modelMapper
                        .map(userRole, UserRoleDto.class);
            } else {
                throw new ApplicationException("User Role not found with the provided role name");
            }
        } else {
            throw new ApplicationException("User Role name is empty or null");
        }

        return userRoleDto;
    }

    @Override
    public Set<UserRoleDto> getAllUserRoles() {
    	LOGGER.info("In Get All User Role");
        Set<UserRoleDto> userRolesDto = new HashSet<>();
        Set<UserRole> userRoles = new HashSet<>();

        userRoles = this
                .roleRepository
                .getAllUserRoles();

        if (!userRoles.isEmpty()) {
            userRolesDto = userRoles
                    .stream()
                    .map(ur -> this
                            .modelMapper
                            .map(ur, UserRoleDto.class))
                    .collect(Collectors.toSet());
        }
        return userRolesDto;
    }

    @Override
    @Async
    @Scheduled(initialDelay = 1000, fixedDelay = 1800000)
    public void roleUpdateScheduler() {
    	LOGGER.info("In Role Update Scheduler");
        Set<UserRoleDto> allUserRoles = new HashSet<>();
        allUserRoles = this
                .getAllUserRoles();

        if (allUserRoles.isEmpty()) {

            UserRoleDto requesterUserRole = new UserRoleDto(501L, UserRoleTypes.ROLE_REQUESTER.toString());
            UserRoleDto trainerUserRole = new UserRoleDto(502L, UserRoleTypes.ROLE_TRAINER.toString());
            UserRoleDto techManagerUserRole = new UserRoleDto(503L, UserRoleTypes.ROLE_TECHNICAL_MANAGER.toString());
            
            UserRoleDto competencyUserRole = new UserRoleDto(504L, UserRoleTypes.ROLE_COMPETENCY_MANAGER.toString());
            
            allUserRoles.add(requesterUserRole);
            allUserRoles.add(trainerUserRole);
            allUserRoles.add(techManagerUserRole);
            allUserRoles.add(competencyUserRole);

            allUserRoles.forEach(this :: createUserRole);
		} else if (!allUserRoles.isEmpty()) {

			List<String> list = Arrays.asList(UserRoleTypes.ROLE_REQUESTER.name(), UserRoleTypes.ROLE_TRAINER.name(),
					UserRoleTypes.ROLE_TECHNICAL_MANAGER.name(), UserRoleTypes.ROLE_COMPETENCY_MANAGER.name());

			List<String> dbRoles = allUserRoles.stream().map(UserRoleDto::getRoleTypes).collect(Collectors.toList());
			allUserRoles.stream().filter(userRole -> !list.contains(userRole.getRoleTypes()))
					.forEach(this::createUserRole);

			Function<String, UserRoleDto> convertToUserRoleDto = (roleName) -> {
				if (roleName.equals(UserRoleTypes.ROLE_REQUESTER.name())) {
					return new UserRoleDto(501L, UserRoleTypes.ROLE_REQUESTER.toString());
				} else if (roleName.equals(UserRoleTypes.ROLE_TRAINER.name())) {
					return new UserRoleDto(502L, UserRoleTypes.ROLE_TRAINER.toString());
				} else if (roleName.equals(UserRoleTypes.ROLE_TECHNICAL_MANAGER.name())) {
					return new UserRoleDto(503L, UserRoleTypes.ROLE_TECHNICAL_MANAGER.toString());
				} else if (roleName.equals(UserRoleTypes.ROLE_COMPETENCY_MANAGER.name())) {
					return new UserRoleDto(504L, UserRoleTypes.ROLE_COMPETENCY_MANAGER.toString());
				}
				return null;

			};

			list.stream().filter(role -> !dbRoles.contains(role)).map(convertToUserRoleDto)
					.forEach(this::createUserRole);

		}
    }
}
