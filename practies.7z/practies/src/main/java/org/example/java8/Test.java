package org.example.java8;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Test {
    public static void main(String[] args) {
        String str ="rahulkumarsoni";
        //out - rahulkmsoni
        System.out.println("input  "+str);
        System.out.print("Output ");
        Arrays.asList(str.split("")).stream()
                .collect(Collectors.groupingBy(Function.identity(), LinkedHashMap::new ,Collectors.counting()))
                .entrySet().stream()
                .forEach(i ->System.out.print(i.getKey()+""));

    }
}
