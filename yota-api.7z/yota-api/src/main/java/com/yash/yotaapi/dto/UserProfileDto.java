package com.yash.yotaapi.dto;

import lombok.Data;

@Data
public class UserProfileDto {

    private Long empId;

    private String fullName;

    private String emailAdd;
}
