package com.yash.ytms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.ytms.domain.OptionalHoliday;

public interface OptionalHolidayRepository extends JpaRepository<OptionalHoliday, Long> {

}
