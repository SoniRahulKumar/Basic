package com.yash.ytms.services.ServiceImpls;

import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yash.ytms.dto.TrainingRequestFormDto;
import com.yash.ytms.dto.YtmsUserDto;
import com.yash.ytms.repository.TrainingRequestRepository;
import com.yash.ytms.services.IServices.ITrainerService;
import com.yash.ytms.services.IServices.IYtmsUserService;

@Service
@Transactional
public class TrainerServiceImpl implements ITrainerService {
	final Logger LOGGER = LoggerFactory.getLogger(TrainerServiceImpl.class);
	
	@Autowired
	private TrainingRequestRepository trainingRequestRepository;
	
	@Autowired
	private IYtmsUserService ytmsUserService;
	


	@Override
	public List<YtmsUserDto> list(TrainingRequestFormDto trainingRequestFormDto) {
		LOGGER.info("In Trainer List");
		List<YtmsUserDto> trainerList = ytmsUserService.getAllTrainers();
		List<String> list = trainingRequestRepository.findAllByActualStartDateAndActualEndDate(
				trainingRequestFormDto.getActualStartDate(), trainingRequestFormDto.getActualEndDate(),
				trainingRequestFormDto.getActualStartTime(), trainingRequestFormDto.getActualEndTime(),
				trainingRequestFormDto.getTrainer());

		trainerList = trainerList.stream().filter(e -> !list.contains(e.getFullName()))
				.filter(e -> !e.getFullName().equals(trainingRequestFormDto.getTrainer())).collect(Collectors.toList());

		return trainerList;

	}

}
