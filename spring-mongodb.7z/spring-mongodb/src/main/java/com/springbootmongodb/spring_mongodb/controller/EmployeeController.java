package com.springbootmongodb.spring_mongodb.controller;

import com.springbootmongodb.spring_mongodb.model.Employee;
import com.springbootmongodb.spring_mongodb.repository.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @PostMapping("/addEmployee")
    public String saveEmployee(@RequestBody Employee employee){
        employeeRepository.save(employee);

        return "Added Successfully";
    }
}
