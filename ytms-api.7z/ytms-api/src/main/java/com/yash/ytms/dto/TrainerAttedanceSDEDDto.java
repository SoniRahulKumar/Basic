package com.yash.ytms.dto;

import java.util.Date;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Data
public class TrainerAttedanceSDEDDto {

	private String tranier_mail_id;

	private Date leave_Start_date;

	private Date leave_End_date;

	private String leave_status;

	public TrainerAttedanceSDEDDto(String tranier_mail_id, Date leave_Start_date, Date leave_End_date,
			String leave_status) {
		super();
		this.tranier_mail_id = tranier_mail_id;
		this.leave_Start_date = leave_Start_date;
		this.leave_End_date = leave_End_date;
		this.leave_status = leave_status;
	}

}
