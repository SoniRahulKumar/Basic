package com.yash.ytms.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class NominationDto {
	
	private Long id;
	private String emp_id;
	private String emp_name;
	private String emp_mail_id;
	private String grade;
	private String skill;
	private String current_allocation;
	private String project;
	private String current_location;
	private Long trainingId;
	private String feedback;
	private Double preAssessment;
	private Double finalScore;
	private String requestor;
	private Double technicalSkills;

	private Double attitude;

	private Double commSkills;

	private Double workQuality;

	private Double overAllRating;
	
	private String competency;
	private String employment_status;
}
