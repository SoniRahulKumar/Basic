package com.yash.ytms.controller;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections4.map.HashedMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytms.domain.OptionalHoliday;
import com.yash.ytms.domain.TrainerAttedance;
import com.yash.ytms.domain.TrainerAttedanceDate;
import com.yash.ytms.dto.OptionalHolidayDto;
import com.yash.ytms.dto.ResponseWrapperDto;
import com.yash.ytms.dto.TrainerAttedanceDto;
import com.yash.ytms.dto.TrainingRequestFormDto;
import com.yash.ytms.repository.TrainerAttendanceRepository;
import com.yash.ytms.services.IServices.IOptionalHolidayService;
import com.yash.ytms.services.IServices.ITrainerAttendanceService;
import com.yash.ytms.services.IServices.IYtmsTraningRequestService;

@RestController
@RequestMapping("/register/trainerAttendance")
public class TrainerAttendanceController {

	@Autowired
	private TrainerAttendanceRepository trainerAttendanceRepository;
	
	@Autowired
	private IYtmsTraningRequestService traningRequestService;
	
	@Autowired
	private ITrainerAttendanceService trainerAttendanceService;
	
	@Autowired
	private IOptionalHolidayService optionalHolidayService;
	
    final Logger LOGGER = LoggerFactory.getLogger(TrainerAttendanceController.class);
	
    @PostMapping("/saveTranierAttendance/{traningId}")
    public ResponseEntity<Object> saveTranierAttendance(@PathVariable String traningId) {
    	LOGGER.info("Saving Tranier Attendance");
    	TrainingRequestFormDto tr= traningRequestService.getTrainingRequestFormById(Long.parseLong(traningId));
       
    	Date startDate=tr.getActualStartDate();
		Date endDate=tr.getActualEndDate();
	    LocalDate convertedStartdate= convert(startDate);
	    LocalDate covertedEnddate= convert(endDate);
	    
	    
	    
	    
	    HashedMap<String, Object> map= addDaysSkippingWeekendsAndOptionalHoliday(convertedStartdate, covertedEnddate, 0);
	     List<LocalDate> listDate=  (List<LocalDate>) map.get("attendsDateDateListInLocalDateFormat");
	     for(LocalDate date:listDate) {
	    	 
	    	 TrainerAttedance trainerAttedance=new TrainerAttedance();
	    	 
	    	 trainerAttedance.setTraining_id(tr.getId());
	    	 trainerAttedance.setTranier_mail_id(tr.getUserName());
	    	 trainerAttedance.setTranier_name(tr.getTrainer());
	    	 List<TrainerAttedanceDate> ll = new ArrayList<>();
				TrainerAttedanceDate trainerAttendanceDate=new TrainerAttedanceDate();
				trainerAttendanceDate.setAttendance_date(asDate(date));
				ll.add(trainerAttendanceDate);
				trainerAttedance.setTrainerAttendanceDates(ll);
	    	 trainerAttedance.setTranining_name(tr.getTrainingName());
	    	 trainerAttendanceRepository.save(trainerAttedance);
	     }
    	
    	return new ResponseEntity<>("Data Save Successfully !!!!!!", HttpStatus.OK);
    }
	
	
    @GetMapping("/getAllTranierAttendance/{traningId}")
    public List<TrainerAttedance> getAllTranierAttendance(@PathVariable String traningId) {
    	LOGGER.info("Getting getAllTranierAttendance");
    	    return trainerAttendanceRepository.findTranierAttendanceDeatils(Long.parseLong(traningId));
    }
    
    @PutMapping("/updateAttendanceStatus/{tarningId}")
    public ResponseEntity<Object> updateAttendanceStatus(@PathVariable String tarningId,@RequestBody List<TrainerAttedance> inputData) {
    	LOGGER.info("updateAttendanceStatus");
        List<TrainerAttedance>  retriveDbList=trainerAttendanceRepository.findTranierAttendanceDeatils(Long.parseLong(tarningId));
        
        
        for(TrainerAttedance attedance:inputData) {
	    	 

        	
	    	 TrainerAttedance trainerAttedance=new TrainerAttedance();
	    	 trainerAttedance.setId(attedance.getId());
	    	 trainerAttedance.setTraining_id(attedance.getTraining_id());
	    	 trainerAttedance.setTranier_mail_id(attedance.getTranier_mail_id());
	    	 trainerAttedance.setTranier_name(attedance.getTranier_name());
	    	 trainerAttedance.setTrainerAttendanceDates(attedance.getTrainerAttendanceDates());
	    	 //trainerAttedance.setTranining_name(tr.getTrainingName());
	    	 trainerAttendanceRepository.save(trainerAttedance);
	     }
  
        
        
        return new ResponseEntity<>("", HttpStatus.OK);
    }
    
	 public  HashedMap<String, Object> addDaysSkippingWeekendsAndOptionalHoliday(LocalDate stardate,LocalDate enddate, int days) {
		    LocalDate result = stardate;
		    int addedDays = 0;
		    HashedMap<String, Object> dateMap=new HashedMap<>();
		    List<LocalDate> finalLocalDateList=new ArrayList<>();
		    List<String> finalStringDateList=new ArrayList<>();
		    while (!result.isAfter(enddate)) {
		        
		        if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY || result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
		      
		        List<LocalDate>	list=getOptionalAndHolidayInLocalDates();
		        
		         
		         if(!list.contains(result)) {
		        	 ++addedDays;
		        	 finalLocalDateList.add(result);   
			         finalStringDateList.add(result.format(DateTimeFormatter.ISO_LOCAL_DATE));
		         }
		        	
		           
		        }
		        
		        result = result.plusDays(1);
		    }
		    
		    
		    dateMap.put("noOfdays",Double.valueOf(addedDays));
		    dateMap.put("attendsDateDateListInLocalDateFormat", finalLocalDateList);
		    dateMap.put("attendsDateListInStringFormat", finalStringDateList);
		    
		    
		    return dateMap;
		}
	 public static LocalDate convert (Date date) {
		    return date.toInstant()
		      .atZone(ZoneId.of("UTC"))
		      .toLocalDate();
		}

	 public  List<LocalDate> getOptionalAndHolidayInLocalDates(){
		
	 List <LocalDate> localdateList=new ArrayList<>();
		 for(String  date:listed()) {
			 LocalDate localDate = LocalDate.parse(date);	 
		     localdateList.add(localDate);
		 }
		 return localdateList;
	 }
	 
	 public List<String> listed(){
			List<OptionalHoliday> list =optionalHolidayService.list();
			return list.stream().map(OptionalHoliday::getDate).map(e->e.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))).toList();
		}
	 
	 public static Date asDate(LocalDate localDate) {
		    return Date.from(localDate.atStartOfDay().atZone(ZoneId.of("UTC")).toInstant());
		  }
	 
	 
	 public static double round(double value, int places) {
		    if (places < 0) throw new IllegalArgumentException();

		    long factor = (long) Math.pow(10, places);
		    value = value * factor;
		    long tmp = Math.round(value);
		    return (double) tmp / factor;
		}
	 
		@GetMapping("/getPendingLeaves")
		public List<TrainerAttedanceDto> getPendingLeaves() {
			LOGGER.info("Getting getPendingLeaves");
			return trainerAttendanceService.getPendingLeaves();
		}
		
		@PostMapping("/approvePendingLeave")
		@PreAuthorize("hasRole('ROLE_TECHNICAL_MANAGER')")
		public ResponseWrapperDto approvePendingLeave(@RequestBody TrainerAttedanceDto trainerAttedanceDto) {
			LOGGER.info("Getting getPendingLeaves");
			trainerAttendanceService.approvePendingLeave(trainerAttedanceDto);
			ResponseWrapperDto resp= new ResponseWrapperDto();
			resp.setMessage("Success");
			return resp;
		}
		
		@GetMapping("/approvedLeaves")
		public ResponseEntity<List<TrainerAttedanceDto>> list(){
			List<TrainerAttedanceDto>  list=trainerAttendanceService.approvedLeaves();
			return new ResponseEntity<>(list,HttpStatus.OK);
		}
		
		
}
