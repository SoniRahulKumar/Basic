package org.example.leadCode;

public class TwoSum {
    //    Input: nums = [2,7,11,15], target = 9
//    Output: [0,1]
//    Explanation: Because nums[0] + nums[1] == 9, we return [0, 1].
    public int[] twoSum(int[] nums, int target) {
        int[] arr = new int[2];
        for (int i : nums) {
            for (int j = 1; j <=nums.length-1; j++) {
                if (nums[i] + nums[j] == target) {
                    // System.out.println("["+ i +" " +(i+1)+"]");
                    arr = new int[]{i, j};
                    System.out.println("[" + i + "," + j + "]");
                }
            }
        }
        return arr;
    }

    public static void main(String[] args) {
        TwoSum twoSum = new TwoSum();
//        int[] nums = {2, 7, 11, 15};
//        int target = 9;
//        int[] nums = {3, 2, 4};
//        int target = 6;
        int[] nums = {3, 2, 3};
        int target = 6;
        twoSum.twoSum(nums, target);
//        int[] arr = twoSum.twoSum(nums, target);
//        System.out.println("Arr"+ arr);
    }

}