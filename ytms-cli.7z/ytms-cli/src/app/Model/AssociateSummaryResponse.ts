import { AssociateSummaryModel } from "./AssociateSummary";

export class AssociateSummaryResponseModel{
    list!: AssociateSummaryModel[];
    actualStartDate!:string;
}
