package com.yash.ytms.dto;

import java.util.Date;

import org.hibernate.annotations.Formula;

import com.yash.ytms.constants.UserAccountStatusTypes;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class TrainingRequestFormDto {

	private long id;
	
	private String trainingIdentifierName;
	
	private String trainingName;
	
	private String trainingDescription;
	
	private Date startDate;
	
	private Date endDate;
	
	private Date actualStartDate;
	
	private Date actualEndDate;
	
	private Date createdAt;
	
	private Date updatedAt;

	private String status = UserAccountStatusTypes.PENDING.toString();

	private String userName;

	//to be used only in case of request declined
	private String declinedMessage;
	
	private int noOfParticipant;

	private String fileName;
	
	private int noOfActualParticipant;

	private String trainingStatus;

	private String trainer;
	
	private String trainerEmail;
	
	private int noOfDays;
	
	private String upgradedSkills;
	
	private String startTime;
	
	private String endTime;
	
	private String actualStartTime;
	
	private String actualEndTime;
	
	private String monthAndYear;
	
	private String requestedBy;
	
	private String competency;
	
	private String grade;

}
