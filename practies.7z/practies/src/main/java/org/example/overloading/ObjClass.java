package org.example.overloading;

public class ObjClass {
    public String print(String input) {
        System.out.println("input");
        return input;
    }

    public Object print(Object obj) {
        System.out.println("obj");
        return obj;
    }

    public static void main(String[] args) {
        ObjClass objClass = new ObjClass();
        objClass.print(objClass);
    }

}
