package com.yash.jenkinspipeline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JenkinsPipelineApplicationTests {

	@Test
	void contextLoads() {
	}

}
