import {Component} from '@angular/core';

@Component({
  selector: 'app-requester-dashboard',
  templateUrl: './requester-dashboard.component.html',
  styleUrls: ['./requester-dashboard.component.css']
})
export class RequesterDashboardComponent {

}
