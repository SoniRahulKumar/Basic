package com.yash.ytms.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.yash.ytms.domain.Nomination;
import com.yash.ytms.dto.AssociateSummaryDto;

public interface NominationRepository extends JpaRepository<Nomination, Long> {
	
	List<Nomination> findAllByTrainingId(Long training_id);

	@Query("select new com.yash.ytms.dto.AssociateSummaryDto(e.emp_id,e.emp_name,e.emp_mail_id,count(e.trainingId) as noOfTrainingsAttended)  "
			+ " from Nomination e group by e.emp_id, e.emp_mail_id,e.emp_name ")
	List<AssociateSummaryDto> findAllAssociates();
	
	
	@Query("select e.trainingId from Nomination e where emp_mail_id=:empId")
	List<Long> findAllAssociatesByEmpId(@Param(value = "empId") String empId);
	
	@Query("select new com.yash.ytms.dto.AssociateSummaryDto(e.emp_id,e.emp_mail_id,count(e.trainingId) as noOfTrainingsAttended)  "
			+ " from Nomination e,TrainingRequestForm t where e.trainingId = t.id  and t.status ='APPROVED' group by e.emp_id, e.emp_mail_id")
	List<AssociateSummaryDto> findAllAssociatesWithStatus();
	
	
	@Query("select emp_name from Nomination e where emp_id =:empId and emp_mail_id=:emp_mail_id")
	List<String> findByIdAndName(@Param(value = "empId") String emp_id,@Param(value = "emp_mail_id") String emp_mail_id);
	
	
	@Query(countQuery = "SELECT p FROM Nomination p where p.trainingId = :trainingId")
	List<Nomination> findByTrainingId(Long trainingId);
	
	@Query("select new com.yash.ytms.dto.AssociateSummaryDto(e.emp_id,e.emp_mail_id,count(e.trainingId) as noOfTrainingsAttended)  "
			+ " from Nomination e,TrainingRequestForm t where e.trainingId = t.id  and t.status ='APPROVED'  and e.requestor=:requestor group by e.emp_id, e.emp_mail_id")
	List<AssociateSummaryDto> findAllAssociatesWithStatusAndRequestor(@Param(value = "requestor") String requestor);
	
	@Query("select e.requestor from Nomination e where trainingId=:trainingId")
	List<String> findRequestorBYTrainingId(@Param(value = "trainingId") Long trainingId);
	
	Optional<Nomination> findById(Long id);
}
