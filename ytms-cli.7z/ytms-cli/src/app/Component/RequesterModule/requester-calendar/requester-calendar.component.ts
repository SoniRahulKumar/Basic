import {Component} from '@angular/core';

@Component({
  selector: 'app-requester-calendar',
  templateUrl: './requester-calendar.component.html',
  styleUrls: ['./requester-calendar.component.css']
})
export class RequesterCalendarComponent {

}
