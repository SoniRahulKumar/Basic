package com.yash.ytms.constants;

/**
 * Project Name - ytms-api
 * <p>
 * IDE Used - IntelliJ IDEA
 *
 * @author - yash.raj
 * @since - 29-01-2024
 */
public class AppConstants {

	public static final String DECLINED_USER_MESSAGE = "Your Request is Declined by Admin !";

	/**
	 * @author shubham.nimase
	 */
	public static final String TRAINING_STATUS_INPROGRESS = "In progress";
	public static final String TRAINING_STATUS_HOLD = "Hold";
	public static final String TRAINING_STATUS_COMPLETE = "Complete";

}
