package org.example.java8;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class FindSumOfIIntegers {
    public static void main(String[] args) {
        int[] a = {1, 4, 6, 3, 7, 9, 4, 10, 8, 9, 4};

        int result = Arrays.stream(a).filter(i -> i % 2 == 0).sum();
        System.out.println("result " + result);

//        List<Integer> integers = Arrays.asList(a);
//        int amountPaid = integers.stream().max(Integer::compareTo(b));
//        System.out.println("amountPaid " + amountPaid);


       List<Integer> listOfInteger = Arrays.asList(1,2,3,4,5,6,700);
        int sum = listOfInteger.stream().reduce(0,Integer::sum);
        System.out.println("Sum " + sum);
        Double value = listOfInteger.stream().max(Integer::compareTo).map(n->n-(n*0.10)).get();
        System.out.println("value "+value);

        //Integer remainTotalValue=listOfInteger.stream().sorted(Comparator.reverseOrder()).skip(1).reduce(0,(x, y)->x+y);
        Integer remainTotalValue=listOfInteger.stream().sorted(Comparator.reverseOrder()).skip(1).reduce(0, Integer::sum);
        double totalValue = remainTotalValue.doubleValue()+value;
        System.out.println("totalValue "+totalValue);
    }
}
