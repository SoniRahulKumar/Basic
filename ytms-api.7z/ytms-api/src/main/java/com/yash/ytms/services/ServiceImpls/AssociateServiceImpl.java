package com.yash.ytms.services.ServiceImpls;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ytms.constants.UserRoleTypes;
import com.yash.ytms.domain.Attendance;
import com.yash.ytms.domain.Nomination;
import com.yash.ytms.domain.TrainingRequestForm;
import com.yash.ytms.dto.AssociateDto;
import com.yash.ytms.dto.AssociateExcelDto;
import com.yash.ytms.dto.AssociateMergeDto;
import com.yash.ytms.dto.AttendanceDummyDto;
import com.yash.ytms.repository.AssociateRepository;
import com.yash.ytms.repository.AttendanceRepository;
import com.yash.ytms.repository.NominationRepository;
import com.yash.ytms.repository.TrainingRequestRepository;
import com.yash.ytms.security.userdetails.CustomUserDetails;
import com.yash.ytms.services.IServices.IAssociateService;
import com.yash.ytms.util.DateTimeUtil;

@Service
public class AssociateServiceImpl implements IAssociateService {
	
	final Logger LOGGER = LoggerFactory.getLogger(AssociateServiceImpl.class);

    @Autowired
    private AssociateRepository associateRepository;
    
    @Autowired
    private AttendanceRepository attendanceRepository;

    @Autowired
    private TrainingRequestRepository trainingRequestRepository;

    @Autowired
    private NominationRepository nominationUploadRepository;

    @Autowired
    private ModelMapper modelMapper;


	@Override
    public List<AssociateExcelDto> parseExcel(MultipartFile file) throws IOException {
		LOGGER.info("In Parse Excel	---- ");

        Workbook workbook = WorkbookFactory.create(file.getInputStream());
        Sheet sheet = workbook.getSheetAt(0);

        List<AssociateExcelDto> associateDtoList = new ArrayList();

        Iterator<Row> rowIterator = sheet.iterator();
        // Conv
        // Skip header row if exists
        // rowIterator = rowIterator.skip(1);
        if (rowIterator.hasNext()) {
            rowIterator.next();
        }

        while (rowIterator.hasNext()) {
            Row row = rowIterator.next();
            if (row.getCell(0) == null) {
                break;
            }

            if (row.getCell(0) != null && row.getCell(0).toString() != "0"
                    && row.getCell(0).toString().trim() != "") {
                AssociateExcelDto associateDto = setAssociateObject(row);

                associateDtoList.add(associateDto);
            }

        }

        workbook.close();
        saveAssociateDataIntoDB(associateDtoList);

        return associateDtoList;
    }


    private AssociateExcelDto setAssociateObject(Row row) {
    	LOGGER.info("In Set Associate Object");
        AssociateExcelDto associateExcelDto = new AssociateExcelDto();
        String formattedEmp_id = new DecimalFormat("#").format(row.getCell(1).getNumericCellValue());
        if(formattedEmp_id != null && formattedEmp_id.trim() != "") {
        	
        
//        String formattedId = new DecimalFormat("#").format(row.getCell(0).getNumericCellValue());
        //String formattedNoOfTraining = new DecimalFormat("#").format(row.getCell(22).getNumericCellValue());
        
        String purposeToTraining = new DecimalFormat("#").format(row.getCell(9).getNumericCellValue());
//        associateExcelDto.setId(Long.parseLong(formattedId));
        associateExcelDto.setEmp_id(formattedEmp_id);
        associateExcelDto.setEmp_name(row.getCell(2).getStringCellValue());
        associateExcelDto.setEmp_mail_id(row.getCell(3).getStringCellValue());
        associateExcelDto.setGrade(row.getCell(4).getStringCellValue());
        associateExcelDto.setResourceType(row.getCell(5).getStringCellValue());
        associateExcelDto.setTrainingStack(row.getCell(6).getStringCellValue());
        associateExcelDto.setTrainingName(row.getCell(7).getStringCellValue());
        associateExcelDto.setPurposeToAttendTraining(row.getCell(8).getStringCellValue());
        associateExcelDto.setTrainingDuration(Integer.parseInt(purposeToTraining.trim()));
        associateExcelDto.setTrainingStartDate(row.getCell(10).getLocalDateTimeCellValue().toLocalDate());
        associateExcelDto.setTrainingEndDate(row.getCell(11).getLocalDateTimeCellValue().toLocalDate());
        associateExcelDto.setCurrentSkill(row.getCell(12).getStringCellValue());
        associateExcelDto.setUpgradedSkill(row.getCell(13).getStringCellValue());
        associateExcelDto.setPreAssessment(row.getCell(14).getNumericCellValue());
        associateExcelDto.setFinalScore(row.getCell(15).getNumericCellValue());
        associateExcelDto.setCurrent_allocation(row.getCell(16).getStringCellValue());
        associateExcelDto.setProject(row.getCell(17).getStringCellValue());
        associateExcelDto.setCurrent_location(row.getCell(18).getStringCellValue());
        associateExcelDto.setStatus(row.getCell(19).getStringCellValue());
        associateExcelDto.setFeedback(row.getCell(20).getStringCellValue());
        associateExcelDto.setTrainer(row.getCell(21).getStringCellValue());
        //associateExcelDto.setTrainingDescription(null);
        }
        return associateExcelDto;
    }

	@Override
	public List<AssociateDto> getAllAssociateTrainings() {
		LOGGER.info("In Get All Associate Training");

		List<AssociateDto> list = null;

		CustomUserDetails userDetails = (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal();

		List<String> roles =Arrays.asList(UserRoleTypes.ROLE_TECHNICAL_MANAGER.name(),UserRoleTypes.ROLE_COMPETENCY_MANAGER.name());		
		if (roles.contains(userDetails.getGrantedAuthorities().getAuthority())) {
			list = associateRepository.findAllAssociateTrainingById();
		} else {
			list = associateRepository.findAllAssociateTrainingByIdAndRequestor(userDetails.getUsername());
		}
		return list;
	}
    
	@Override
	public List<AssociateDto> findAllAssociateTrainingByMailId(String empId) {
		LOGGER.info("In Find All Associate Training By MailId");
		List<AssociateDto> associates = associateRepository.findAllAssociateTrainingByMailId(empId);
		List<AttendanceDummyDto> list = attendanceRepository.findAttendence(empId);

		for (int index = 0; index < associates.size(); index++) {
			AssociateDto aDto = associates.get(index);

			for (AttendanceDummyDto attendance : list) {

				if (attendance.getEmp_mail_id().equals(aDto.getEmp_mail_id())
						&& Objects.equals(attendance.getTraning_id(), aDto.getTrainingId())) {
					Double aPercentage = attendance.getAttendance_percentage();
					
					//double percentage = value * 100;        
					DecimalFormat formatter = new DecimalFormat("0.00");        
					
					String att=formatter.format(aPercentage) ;
					
					aDto.setAttendancePercentage(att);
				}

			}

		}

		return associates;

	}

    private void saveAssociateDataIntoDB(List<AssociateExcelDto> associateDtoList) {
    	LOGGER.info("In Save Associate Data Into DB");

        Map<String, AssociateMergeDto> mergeDtoMap = new HashMap<String, AssociateMergeDto>();
        AssociateMergeDto associateMergeDto = null;
        List<Nomination> nominationList = null;
        Nomination nomination = null;
        TrainingRequestForm trainingRequestForm = null;
        for (AssociateExcelDto dto : associateDtoList) {
            if (mergeDtoMap.containsKey(dto.getTrainingName())) {
                nomination = new Nomination();
                trainingRequestForm = new TrainingRequestForm();
                nominationList =  mergeDtoMap.get(dto.getTrainingName()).getNominationList();
                nominationList.add(setNominationData(dto));
                mergeDtoMap.get(dto.getTrainingName()).setNominationList(nominationList);
            } else {
                associateMergeDto = new AssociateMergeDto();
                nominationList = new ArrayList<>();
                nomination = new Nomination();
                trainingRequestForm = new TrainingRequestForm();
                associateMergeDto.setTrainingRequestForm(setTrainingData(dto));
                nomination = setNominationData(dto);
                nominationList.add(nomination);
                associateMergeDto.setNominationList(nominationList);
                mergeDtoMap.put(dto.getTrainingName(), associateMergeDto);
            }
        }
        Set<Map.Entry<String, AssociateMergeDto>> finalset = mergeDtoMap.entrySet();
        for (Map.Entry<String, AssociateMergeDto> iterator : finalset) {
            AssociateMergeDto object = (AssociateMergeDto) iterator.getValue();
            TrainingRequestForm trf = object.getTrainingRequestForm();
            trf = trainingRequestRepository.save(trf);
            List<Nomination> nomiationList = object.getNominationList();
            for (Nomination nominationEntity : nomiationList) {
                nominationEntity.setTrainingId(trf.getId());
                //nomiationList.add(nominationEntity);
                nominationUploadRepository.save(nominationEntity);
            }
            //nominationUploadRepository.saveAll(nomiationList);
        }
    }

    private Nomination setNominationData(AssociateExcelDto dto) {
    	LOGGER.info("In Set Nomination Data");
        Nomination nomination = new Nomination();
        nomination.setEmp_id(dto.getEmp_id());
        nomination.setEmp_name(dto.getEmp_name());
        nomination.setEmp_mail_id(dto.getEmp_mail_id());
        nomination.setGrade(dto.getGrade());
        nomination.setSkill(dto.getCurrentSkill());
        nomination.setCurrent_allocation(dto.getCurrent_allocation());
        nomination.setProject(dto.getProject());
        nomination.setCurrent_location(dto.getCurrent_location());
        nomination.setPreAssessment(dto.getPreAssessment());
        nomination.setFinalScore(dto.getFinalScore());
        nomination.setFeedback(dto.getFeedback());
        nomination.setAttitude(dto.getAttitude());
		nomination.setTechnicalSkills(dto.getTechnicalSkills());
		nomination.setCommSkills(dto.getCommSkills());
		nomination.setOverAllRating(dto.getOverAllRating());
		nomination.setWorkQuality(dto.getWorkQuality());
        return nomination;
    }

    private TrainingRequestForm setTrainingData(AssociateExcelDto dto) {
    	LOGGER.info("In Set Training Data");
        TrainingRequestForm trainingRequestForm = new TrainingRequestForm();
        trainingRequestForm.setTrainingName(dto.getTrainingName());
        trainingRequestForm.setStatus(dto.getStatus());
        trainingRequestForm.setActualStartDate(DateTimeUtil.asDate(dto.getTrainingStartDate()));
        trainingRequestForm.setActualEndDate(DateTimeUtil.asDate(dto.getTrainingEndDate()));
        trainingRequestForm.setNoOfDays(dto.getTrainingDuration());
        trainingRequestForm.setUpgradedSkills(dto.getUpgradedSkill());
        trainingRequestForm.setTrainingDescription(dto.getTrainingDescription());
        trainingRequestForm.setTrainingStatus(dto.getStatus());
        trainingRequestForm.setTrainer(dto.getTrainer());
        return trainingRequestForm;
    }

}

