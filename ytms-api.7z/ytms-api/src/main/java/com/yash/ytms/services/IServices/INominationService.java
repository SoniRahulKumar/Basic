package com.yash.ytms.services.IServices;

import java.io.IOException;
import java.security.Principal;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.yash.ytms.domain.AssociateSummaryResponseDto;
import com.yash.ytms.dto.NominationDto;
import com.yash.ytms.dto.TrainingRequestFormDto;

public interface INominationService {
	List<NominationDto> parseExcel(MultipartFile file) throws IOException;

	NominationDto saveNomination(NominationDto dto);

	List<NominationDto> findNominationsByTrainingID(Long trainingId);
	
	NominationDto getNomiationById(Long id);
	
	void deleteNominationById(Long id);
	
	AssociateSummaryResponseDto list();

	List<TrainingRequestFormDto> getAllTrainingsByAssociate(String emailId);

	NominationDto saveNomination(NominationDto dto, Principal principal);

	List<NominationDto> updateFeedBack(List<NominationDto> feedBackList);
	
	List<NominationDto> updateFinalScore(List<NominationDto> finalScoreList);
	
	NominationDto updateNomination(NominationDto dto);

}
