package com.yash.ytms.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Nominations")
public class Nomination {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private String emp_id;
	
	private String emp_name;
	
	private String emp_mail_id;
	
	private String grade;
	
	private String skill;
	
	private String current_allocation;
	
	private String project;
	
	private String current_location;
	
	private Long trainingId;
	
	@Column(columnDefinition = "TEXT")
	private String feedback;
	
	@Column(columnDefinition = "int default '0'")
	private Double preAssessment;
	
	@Column(columnDefinition = "int default '0'")
	private Double finalScore;

	@Column(name = "requestor")
	private String requestor;
	
	@Column(name = "technicalSkills")
	private Double technicalSkills;

	@Column(name = "attitude")
	private Double attitude;

	
	@Column(name = "commSkills")
	private Double commSkills;

	
	@Column(name = "workQuality")
	private Double workQuality;

	@Column(name = "overAllRating")
	private Double overAllRating;
	
	private String competency;

	@Column(columnDefinition="varchar(255) default 'Active'") 
	private String employment_status;
}
