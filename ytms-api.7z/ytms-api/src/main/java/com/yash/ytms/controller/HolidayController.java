package com.yash.ytms.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytms.dto.HolidayDto;
import com.yash.ytms.services.IServices.IHolidayService;

@RestController
@RequestMapping("/holiday")
public class HolidayController {
	@Autowired
	private IHolidayService holidayService;
	
	final Logger LOGGER = LoggerFactory.getLogger(HolidayController.class);

	@PostMapping("/save")
	public ResponseEntity<Void> saveHolidays(@RequestBody List<HolidayDto> holidayDto) {
		LOGGER.info("inside the method saveHolidays",holidayDto);
		holidayService.saveAllHolidays(holidayDto);
		return new ResponseEntity<>(HttpStatus.OK);
	}

	@GetMapping("/get/all")
	public ResponseEntity<List<HolidayDto>> getAllHolidays() {
		LOGGER.info("inside the method getAllHolidays");
		return new ResponseEntity<>(holidayService.getAllHolidays(), HttpStatus.OK);
	}

}
