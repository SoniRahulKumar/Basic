package com.yash.ytms.services.ServiceImpls;

import java.io.File;
import java.io.IOException;
import java.security.Principal;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ytms.constants.UserAccountStatusTypes;
import com.yash.ytms.constants.UserRoleTypes;
import com.yash.ytms.domain.FileName;
//import com.yash.ytms.constants.StatusTypes;
import com.yash.ytms.domain.TrainingRequestForm;
import com.yash.ytms.dto.CalendarDto;
import com.yash.ytms.dto.NominationDto;
import com.yash.ytms.dto.ResponseWrapperDto;
import com.yash.ytms.dto.TrainingRequestFormDto;
import com.yash.ytms.dto.TrfWithNominationDto;
import com.yash.ytms.repository.NominationRepository;
import com.yash.ytms.repository.StoreFileNameInRepository;
import com.yash.ytms.repository.TrainingRequestRepository;
import com.yash.ytms.repository.YtmsUserRepository;
import com.yash.ytms.security.userdetails.CustomUserDetails;
import com.yash.ytms.security.userdetails.CustomUserDetailsServiceImpl;
import com.yash.ytms.services.IServices.ICalendarService;
import com.yash.ytms.services.IServices.INominationService;
import com.yash.ytms.services.IServices.IYtmsTraningRequestService;
import com.yash.ytms.util.EmailUtil;

import jakarta.mail.MessagingException;


@Service
public class YtmsTraningRequestServiceImpl implements IYtmsTraningRequestService {
	final Logger LOGGER = LoggerFactory.getLogger(YtmsTraningRequestServiceImpl.class);

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private TrainingRequestRepository requestRepository;
    
    @Autowired
    private NominationRepository nominationRepository;

    @Autowired
    private CustomUserDetailsServiceImpl userDetails;

    @Autowired
    private INominationService iNominationService;

    @Autowired
    private EmailUtil emailUtil;
    
    @Autowired
	ICalendarService iCalendarService;

    @Autowired
    private YtmsUserRepository ytmsUserRepository;
    
    @Autowired
    private StoreFileNameInRepository storeFileNameInRepository;

    @Value("${attachFile.filePath}")
    private String filePath;

    @Override
    public ResponseWrapperDto saveTrainingRequestForm(TrfWithNominationDto formDto,Principal principal) {
    	LOGGER.info("In Save Training Request Form");
        ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();
        TrainingRequestForm trainingRequestForm = null;
        if (formDto != null && formDto.getTrainingRequestFormDto() != null) {
            try {
                trainingRequestForm = modelMapper.map(formDto.getTrainingRequestFormDto(), TrainingRequestForm.class);
                if (ObjectUtils.isNotEmpty(trainingRequestForm)) {
                    trainingRequestForm.setStatus(UserAccountStatusTypes.PENDING.toString());
                    trainingRequestForm = requestRepository.save(trainingRequestForm);
                    saveNomination(formDto.getNominationList(), trainingRequestForm.getId(), principal);
                    responseWrapperDto.setMessage("Data Save Successfully..");
                    List<String> usersList = this.ytmsUserRepository.findAllTechnicalManager();
                    if (ObjectUtils.isNotEmpty(usersList)) {
                        try {
                            emailUtil.sendNotificationMailForTechnicalManage(usersList, trainingRequestForm.getUserName());
                        } catch (MessagingException ex) {
                            responseWrapperDto.setMessage("unable send mail to technical manager ! " + ex.getMessage());
                        }
                    }

                } else {
                    responseWrapperDto.setMessage("transection fail !");
                }
            } catch (Exception e) {
                responseWrapperDto.setMessage("unable to save training data !");
            }
        } else {
            responseWrapperDto.setMessage("Training Request Form is empty !");
        }
        return responseWrapperDto;
    }

    @Override
    public ResponseWrapperDto approveTrainingRequestForm(TrainingRequestFormDto formDto, Principal principal) {
    	LOGGER.info("In Approve Training Request Form");
        ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();
        responseWrapperDto.setStatus("Success");
        TrainingRequestForm trainingRequestForm = null;
        if (formDto != null) {
            if (formDto.getActualEndDate().after(formDto.getActualStartDate())) {
            	
                Long count=	requestRepository.findByActualStartDateAndActualEndDate(formDto.getActualStartDate(), formDto.getActualEndDate(), formDto.getActualStartTime(), formDto.getActualEndTime(), formDto.getTrainer());
                if(count>0) {
                	 responseWrapperDto.setMessage("Time slot is not available for the trainer "+formDto.getTrainer()+" Please check another timing");
                	 responseWrapperDto.setStatus("Failure");
                	 return responseWrapperDto;
                }
            
            try {
                	
                	
                    Optional<TrainingRequestForm> oldformDtoOpt = requestRepository.findById(formDto.getId());
                    if (oldformDtoOpt.isPresent()) {
                        TrainingRequestForm oldformDto = oldformDtoOpt.get();
                        oldformDto.setActualStartDate(formDto.getActualStartDate());
                        oldformDto.setActualEndDate(formDto.getActualEndDate());
                        oldformDto.setActualStartTime(formDto.getActualStartTime());
                        oldformDto.setActualEndTime(formDto.getActualEndTime());
                        oldformDto.setTrainer(formDto.getTrainer());
                        oldformDto.setTrainerEmail(formDto.getTrainerEmail());
                        oldformDto.setStatus(UserAccountStatusTypes.APPROVED.toString());
                        oldformDto.setTrainingStatus(UserAccountStatusTypes.PLANNED.toString());
                        oldformDto.setNoOfDays(formDto.getNoOfDays());
                        //oldformDto.setDeclinedMessage("NA");
                        trainingRequestForm = modelMapper.map(oldformDto, TrainingRequestForm.class);
                        if (ObjectUtils.isNotEmpty(trainingRequestForm)) {
                            requestRepository.save(trainingRequestForm);
                            responseWrapperDto.setMessage("Data Save Successfully..");
                            emailUtil.sendNotificationMailForRequestApproved(trainingRequestForm.getUserName(), formDto.getFileName(),oldformDto);
                        } else {
                            responseWrapperDto.setMessage("transection fail !");
                        }
                        try {

                        	CalendarDto calendarDto = new CalendarDto();
                        	calendarDto.setTitle(oldformDto.getTrainingName());
                        	calendarDto.setStart_date(oldformDto.getActualStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
                        	calendarDto.setStart_time(LocalTime.parse(oldformDto.getActualStartTime()));
                        	calendarDto.setEnd_date(oldformDto.getActualStartDate().toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
                        	calendarDto.setEnd_time(LocalTime.parse(oldformDto.getActualEndTime()));
                        	calendarDto.setNumber_of_week_days(new Long(oldformDto.getNoOfDays()));
                        	calendarDto.setScheduleUser(ytmsUserRepository.findByFullName(oldformDto.getTrainer()));
                        	iCalendarService.updateCalendarEvent(calendarDto, principal);
						} catch (Exception e) {
							// TODO: handle exception
							e.printStackTrace();
						}
                    }

                } catch (Exception e) {
                	responseWrapperDto.setStatus("Failure");
                    responseWrapperDto.setMessage("unable to save training data !");
                }

            } else {
            	responseWrapperDto.setStatus("Failure");
                responseWrapperDto.setMessage("can not select End date after start date! ");
            }
        } else {
        	responseWrapperDto.setStatus("Failure");
            responseWrapperDto.setMessage("Training Request Form is empty !");

        }
        return responseWrapperDto;
    }

    @Override
    public ResponseWrapperDto declineTrainingRequestForm(TrainingRequestFormDto formDto) {
    	LOGGER.info("In Decline Training Request Form");
        ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();
        TrainingRequestForm trainingRequestForm = null;
        if (formDto != null) {
            try {
                Optional<TrainingRequestForm> oldformDtoOpt = requestRepository.findById(formDto.getId());
                if (oldformDtoOpt.isPresent()) {
                    TrainingRequestForm oldformDto = oldformDtoOpt.get();
                    oldformDto.setStatus(UserAccountStatusTypes.DECLINED.toString());
                    trainingRequestForm = modelMapper.map(oldformDto, TrainingRequestForm.class);
                    trainingRequestForm.setDeclinedMessage(formDto.getDeclinedMessage());
                    if (ObjectUtils.isNotEmpty(trainingRequestForm)) {
                        requestRepository.save(trainingRequestForm);
                        responseWrapperDto.setMessage("Data Save Successfully..");
                        emailUtil.sendNotificationMailForRequestReject(trainingRequestForm.getUserName(),trainingRequestForm);
                    } else {
                        responseWrapperDto.setMessage("transection fail !");
                    }
                }

            } catch (Exception e) {
                responseWrapperDto.setMessage("unable to save training data !");
            }

        } else {
            responseWrapperDto.setMessage("Training Request Form is empty !");

        }
        return responseWrapperDto;
    }

    @Override
    public List<TrainingRequestFormDto> getTrainingRequestForm(Principal principal) {
    	LOGGER.info("In Get Training Request Form");
        List<TrainingRequestFormDto> requestFormList = null;
        List<TrainingRequestForm> forms = new ArrayList<TrainingRequestForm>();
        String userName = principal.getName();
        CustomUserDetails customUserDetails = this.userDetails.loadUserByUsername(userName);
        String role = customUserDetails.getGrantedAuthorities().getAuthority();
        try {
        	List<String> roles =Arrays.asList(UserRoleTypes.ROLE_TECHNICAL_MANAGER.name(),UserRoleTypes.ROLE_COMPETENCY_MANAGER.name());
    		if (roles.contains(role))
            {
                forms = requestRepository.findAll();
//                if(forms != null)
//                	forms.sort(Comparator.comparing(TrainingRequestForm::getStatus,Comparator.nullsLast(Comparator.reverseOrder())).thenComparing(Comparator.comparing(TrainingRequestForm::getStartDate,Comparator.nullsLast(Comparator.naturalOrder()))));
            }
            else{
                    forms = requestRepository.findByUserName(userName);
                }
                LOGGER.info(String.valueOf(forms));
                forms.sort(Comparator.comparing(TrainingRequestForm::getId).reversed());
                requestFormList = modelMapper.map(forms, List.class);
            } catch(Exception e){
                // TODO: handle exception
                e.printStackTrace();
            }
            return requestFormList;
        }

    @Override
    public TrainingRequestFormDto getTrainingRequestFormById(long trainingId) {
    	LOGGER.info("In Get Training Request Form By ID");
        TrainingRequestFormDto requestForm = null;
        TrainingRequestForm form = new TrainingRequestForm();
        try {

            form = requestRepository.findById(trainingId).get();

            requestForm = modelMapper.map(form, TrainingRequestFormDto.class);
        } catch (Exception e) {
            // TODO: handle exception
            e.printStackTrace();
        }
        return requestForm;
    }

    @Override
    public ResponseWrapperDto editTrainingRequestForm(TrainingRequestFormDto formDto) {
    	LOGGER.info("In Edit Training Request Form");
        ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();
        TrainingRequestForm trainingRequestForm = null;
        Optional<TrainingRequestForm> getTraining = null;
        if (formDto != null) {
            try {
                getTraining = requestRepository.findById(formDto.getId());
                trainingRequestForm = modelMapper.map(formDto, TrainingRequestForm.class);
                if (getTraining.isPresent()) {
                    trainingRequestForm.setCreatedAt(getTraining.get().getCreatedAt());
                }
                if (ObjectUtils.isNotEmpty(trainingRequestForm)) {
                    trainingRequestForm.setStatus(UserAccountStatusTypes.PENDING.toString());
                    requestRepository.save(trainingRequestForm);
                    responseWrapperDto.setMessage("Data Updated Successfully..");
                    List<String> managerList = ytmsUserRepository.findAllTechnicalManager();
                    emailUtil.sendMailToTrainingStatus(managerList,trainingRequestForm);
                } else {
                    responseWrapperDto.setMessage("transection fail !");
                }
            } catch (Exception e) {
                responseWrapperDto.setMessage("unable to update training data !");
            }

        } else {
            responseWrapperDto.setMessage("Training Request Form is empty !");

        }
        return responseWrapperDto;
    }

    private List<NominationDto> saveNomination(List<NominationDto> nominationDtos, Long trainingId ,Principal principal) {
        nominationDtos.stream().forEach(e -> e.setTrainingId(trainingId));
        nominationDtos.stream().forEach(e -> {
        	LOGGER.info(principal.getName());
        	e.setRequestor(principal.getName());
            iNominationService.saveNomination(e);
        });
        return nominationDtos;
    }

    public ResponseWrapperDto uploadFile(MultipartFile file) {
    	LOGGER.info("In Upload File");
        ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();
        String fileName = file.getOriginalFilename();
        FileName fName = new FileName();
        try {
            File f = new File(filePath);
            if (f.exists() && f.isDirectory()) {
                file.transferTo(new File(filePath + fileName));
            } else {
                f.mkdir();
                file.transferTo(new File(filePath + fileName));
            }

            if (fileName.indexOf(".") > 0)
                fileName = fileName.substring(0, fileName.lastIndexOf("."));
            fName.setFileName(fileName);
            responseWrapperDto.setMessage("File upload successfully ");
            List<String> listOfFileName = storeFileNameInRepository.findAllFileName();
            if (!listOfFileName.contains(fileName)) {
                storeFileNameInRepository.save(fName);
            }
        } catch (IOException e) {
            responseWrapperDto.setMessage("Fail to upload excel in to folder: " + e.getMessage());

        }
        return responseWrapperDto;
    }

    public List<String> getFileName() {
    	LOGGER.info("In Get File Name");
        return storeFileNameInRepository.findAllFileName();
    }

    @Override
    public List<TrainingRequestFormDto> getTrainerTrainingList(Principal principal) {
    	LOGGER.info("In Get Trainer Training List");
        List<TrainingRequestFormDto> requestFormList = null;
        List<TrainingRequestForm> forms = new ArrayList<TrainingRequestForm>();
        String userName = principal.getName();
        CustomUserDetails customUserDetails = this.userDetails.loadUserByUsername(userName);
        String role = customUserDetails.getGrantedAuthorities().getAuthority();
		try {
			if (UserRoleTypes.ROLE_TRAINER.toString().equals(role)) {
				String trainerName = requestRepository.findTrainerName(userName);
				forms = requestRepository.findByTrainerContains(trainerName).stream().sorted((a, b) -> (int) (b.getId() - a.getId()))
						.collect(Collectors.toList());
			} else if (UserRoleTypes.ROLE_TECHNICAL_MANAGER.toString().equals(role)) {
				forms = requestRepository.findAll().stream().sorted((a, b) -> (int) (b.getId() - a.getId()))
						.collect(Collectors.toList());
			} else if (UserRoleTypes.ROLE_COMPETENCY_MANAGER.toString().equals(role)) {
				forms = requestRepository.findAll().stream().sorted((a, b) -> (int) (b.getId() - a.getId()))
						.collect(Collectors.toList());
			} else {
				forms = requestRepository.findByUserName(userName);
			}
			requestFormList = modelMapper.map(forms, List.class);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
        return requestFormList;
    }
    
    /*@Override
    //@PostFilter("filterObject.userName == authentication.name")
    public List<TrainingRequestFormDto> getUpcomingTrainingList(Principal principal) {
    	
    	String pattern = "yyyy-MM-dd";
    	DateFormat df = new SimpleDateFormat(pattern);
    	Date today = Calendar.getInstance().getTime();        	
    	String todayAsString = df.format(today);
        return modelMapper.map(requestRepository.findByStatusAndActualStartDateAfter("APPROVED",today), List.class);
    }*/
    

    @Override
    public List<TrainingRequestFormDto> getUpcomingTrainingList(Principal principal) {
    	LOGGER.info("In Get Upcoming Training List");
        List<TrainingRequestFormDto> requestFormList = null;
        List<TrainingRequestForm> forms = new ArrayList<TrainingRequestForm>();
        String userName = principal.getName();
        CustomUserDetails customUserDetails = this.userDetails.loadUserByUsername(userName);
        String role = customUserDetails.getGrantedAuthorities().getAuthority();
        try {
           /* if (UserRoleTypes.ROLE_TRAINER.toString().equals(role)) {
                String trainerName = requestRepository.findTrainerName(userName);
                forms = requestRepository.findByUserNameAndTrainerContainsAndStatusAndActualStartDateAfter(userName,trainerName,"APPROVED",Calendar.getInstance().getTime());
            } 
            if (UserRoleTypes.ROLE_TECHNICAL_MANAGER.toString().equals(role)) {
                forms = requestRepository.findByStatusAndActualStartDateAfter("APPROVED",Calendar.getInstance().getTime());
            }else {
            	 forms = requestRepository.findByUserNameAndStatusAndActualStartDateAfter(userName,"APPROVED",Calendar.getInstance().getTime());
            }*/
            forms = requestRepository.findByStatusAndActualStartDateAfter("APPROVED",Calendar.getInstance().getTime());
            
            forms.forEach((e)->  {e.setNoOfActualParticipant(nominationRepository.findByTrainingId(e.getId()).size());});
            
            
            requestFormList = modelMapper.map(forms, List.class);
        } catch (Exception e) {
            
        }
        return requestFormList;
    }

	@Override
	public ResponseWrapperDto changeTrainingStatus(long id,String status) {
		LOGGER.info("In Change Training Status");
		ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();
		responseWrapperDto.setStatus("200");
        Optional<TrainingRequestForm> getTraining = requestRepository.findById(id);
        if (getTraining.isPresent()) {
        	TrainingRequestForm trainingRequestForm=getTraining.get();
            try {
                    trainingRequestForm.setCreatedAt(getTraining.get().getCreatedAt());
                    trainingRequestForm.setTrainingStatus(status);
                    requestRepository.save(trainingRequestForm);
                    responseWrapperDto.setMessage("Data Updated Successfully..");
                    List<String> managerList = ytmsUserRepository.findAllTechnicalManager();
                    emailUtil.sendMailToTrainingStatus(managerList,trainingRequestForm);
                
            } catch (Exception e) {
                responseWrapperDto.setMessage("unable to update training data !");
            }

        } else {
            responseWrapperDto.setMessage("Training Request Form is empty !");

        }
        return responseWrapperDto;
	}

	@Override
	public List<TrainingRequestFormDto> getTrainingByStatus(String status) {
		LOGGER.info("In Get Training Request Form");
        List<TrainingRequestFormDto> requestFormList = null;
        List<TrainingRequestForm> forms = new ArrayList<TrainingRequestForm>();
        try {
        		forms = requestRepository.findByStatus(status);
                forms.sort(Comparator.comparing(TrainingRequestForm::getId).reversed());
                requestFormList = modelMapper.map(forms, List.class);
            } catch(Exception e){
                // TODO: handle exception
                e.printStackTrace();
            }
            return requestFormList;
	}
}
