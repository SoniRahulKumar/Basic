export const Messages = {
    EMAIL_REQUIRED: `email is required.`,
    EMAIL_PATTERN: `please provide a valid email address`
}