package com.yash.ytms.util;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.yash.ytms.dto.TrainingRequestFormDto;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

public class TrainingExcelExporter {

	private XSSFWorkbook workbook;
	private XSSFSheet sheet;

	private List<TrainingRequestFormDto> trainingList;

	public TrainingExcelExporter(List<TrainingRequestFormDto> trainingList) {
		this.trainingList = trainingList;
		workbook = new XSSFWorkbook();
	}

	private void writeHeader() {
		sheet = workbook.createSheet("Trainings");
		Row row = sheet.createRow(0);
		CellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setBold(true);
		font.setFontHeight(16);
		style.setFont(font);
		createCell(row, 0, "ID", style);
		createCell(row, 1, "Training Name", style);
		createCell(row, 2, "Status", style);
		createCell(row, 3, "Trainer Name", style);
		createCell(row, 4, "Requester Name", style);
		createCell(row, 5, "Number of Participents", style);
		createCell(row, 6, "Competency", style);
		createCell(row, 7, "Grade", style);
		createCell(row, 8, "Actual Start Date", style);
		createCell(row, 9, "Actual End Date", style);

	}

	private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
		sheet.autoSizeColumn(columnCount);
		Cell cell = row.createCell(columnCount);
		if (valueOfCell instanceof Integer) {
			cell.setCellValue((Integer) valueOfCell);
		} else if (valueOfCell instanceof Long) {
			cell.setCellValue((Long) valueOfCell);
		} else if (valueOfCell instanceof String) {
			cell.setCellValue((String) valueOfCell);
		} else if (valueOfCell instanceof Date) {
			cell.setCellValue((Date) valueOfCell);
		} else if (valueOfCell instanceof Double) {
			cell.setCellValue((Double) valueOfCell);
		} else if (valueOfCell instanceof Boolean) {
			cell.setCellValue((Boolean) valueOfCell);
		} else if (valueOfCell == null) {
			cell.setCellValue(null + "");
		} else {
			cell.setCellValue(valueOfCell.toString());
		}
		cell.setCellStyle(style);
	}

	private void write() {
		int rowCount = 1;
		CellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setFontHeight(14);
		style.setFont(font);
		for (TrainingRequestFormDto record : trainingList) {
			Row row = sheet.createRow(rowCount++);
			int columnCount = 0;
			createCell(row, columnCount++, record.getId(), style);
			createCell(row, columnCount++, record.getTrainingName(), style);
			createCell(row, columnCount++, record.getStatus(), style);
			createCell(row, columnCount++, record.getTrainer(), style);
			createCell(row, columnCount++, record.getUserName(), style);
			createCell(row, columnCount++, record.getNoOfActualParticipant(), style);
			createCell(row, columnCount++, record.getCompetency(), style);
			createCell(row, columnCount++, record.getGrade(), style);
			if (record.getActualStartDate() != null) {
				createCell(row, columnCount++, record.getActualStartDate().toLocaleString(), style);
			}
			if (record.getActualEndDate() != null) {
				createCell(row, columnCount++, record.getActualEndDate().toLocaleString(), style);
			}

		}
	}

	public void generateExcelFile(HttpServletResponse response) throws IOException {
		writeHeader();
		write();
		ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();
	}

}