package com.yash.ytms.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.ytms.domain.Holiday;

public interface HolidayRepository extends JpaRepository<Holiday,Long> {

}
