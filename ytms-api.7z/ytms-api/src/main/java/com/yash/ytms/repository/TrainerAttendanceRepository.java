package com.yash.ytms.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.yash.ytms.domain.TrainerAttedance;
import com.yash.ytms.dto.TrainerAttedanceDto;
import com.yash.ytms.dto.TrainerAttedanceSDEDDto;


public interface TrainerAttendanceRepository extends JpaRepository<TrainerAttedance,Long> {
	
	 @Query(value = "select * from trainer_attendance_report where training_id =:traningId", nativeQuery = true)
	 List<TrainerAttedance> findTranierAttendanceDeatils(long traningId);
	 
	 
	 @Query(value = "select b.attendance_date from trainer_attendance_report a,trainer_attendance_date b "
	 		+ "where  a.id= b.trainer_attendance_report_id and a.training_id=:traningId ", nativeQuery = true)
	 List<Date> findAttendanceDateData(Long traningId);
	 
	 @Query(value = "select t from TrainerAttedance t where leave_status = 'PENDING'", nativeQuery = false)
	 List<TrainerAttedance> findAll();
	 
	 @Query(value = "select t from TrainerAttedance t where leave_status = 'APPROVED'", nativeQuery = false)
	 List<TrainerAttedance> findAllAbsentLeave();
	 
	 @Query(value = "select count(*) from trainer_attendance_report a,trainer_attendance_date b\r\n"
	 		+ " where b.attendance_date LIKE CONCAT('%',:selectedDate,'%') \r\n"
	 		+ " and a.id=b.trainer_attendance_report_id\r\n"
	 		+ "  and training_id=:traningId ", nativeQuery = true)
	 Long findSelectedDateTrainerData(Date selectedDate,Long traningId);
	 
	 
	 @Query(value = "select t from TrainerAttedance t where (leave_status = 'APPROVED' or leave_status = 'DECLINED')", nativeQuery = false)
	 List<TrainerAttedance> findAllAPPROVED();
	 
	 //@Query(value = "select t.id, t.tranier_mail_id, GROUP_CONCAT(t.tranining_name SEPARATOR '#') as tranining_name,t.leave_start_date,t.leave_end_date,t.leave_status ,t.aprrove_by,t.leave_impact_on_traning,t.training_id,t.tranier_name from trainer_attendance_report t where (leave_status = 'APPROVED' or leave_status = 'DECLINED') group by t.id, t.tranier_mail_id,t.leave_start_date,t.leave_end_date,t.leave_status,t.aprrove_by,t.leave_impact_on_traning,t.training_id,t.tranier_name", nativeQuery = true)
	 //List<TrainerAttedance> findAllApprovedAndDeclined();
	 
	   // @Query(value = "select t.tranier_mail_id, GROUP_CONCAT(t.tranining_name SEPARATOR '#') as tranining_name,t.leave_start_date,t.leave_end_date,t.leave_status ,t.aprrove_by,t.leave_impact_on_traning from trainer_attendance_report t where (t.leave_status = 'APPROVED' or t.leave_status = 'DECLINED') group by t.id, t.tranier_mail_id,t.leave_start_date,t.leave_end_date,t.leave_status,t.aprrove_by,t.leave_impact_on_traning", nativeQuery = true)
		//List<TrainerAttedanceDto> findAllApprovedAndDeclined();
	 
	 @Query(value = "select  new com.yash.ytms.dto.TrainerAttedanceSDEDDto(t.tranier_mail_id,t.leave_Start_date,t.leave_End_date,t.leave_status) from TrainerAttedance t where (t.leave_status = 'APPROVED' or t.leave_status = 'DECLINED') group by  t.leave_Start_date,t.leave_End_date ,t.tranier_mail_id,t.leave_status", nativeQuery = false)
	 List<TrainerAttedanceSDEDDto> findAllBySdEd();
	 
	 
	 @Query(value = "select t.tranining_name from TrainerAttedance t where t.tranier_mail_id=:tranier_mail_id and t.leave_Start_date=:leave_Start_date and t.leave_End_date=:leave_End_date and t.leave_status=:leave_status", nativeQuery = false)
	 List<String> findAllByDates(String tranier_mail_id,Date leave_Start_date,Date leave_End_date,String leave_status);
}
