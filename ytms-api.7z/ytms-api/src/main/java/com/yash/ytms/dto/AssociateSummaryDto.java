package com.yash.ytms.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssociateSummaryDto {

	private String emp_id;

	private String emp_name;

	private String emp_mail_id;

	private Long noOfTrainingsAttended;

	public AssociateSummaryDto(String emp_id, String emp_mail_id, Long noOfTrainingsAttended) {
		super();
		this.emp_id = emp_id;
		this.emp_mail_id = emp_mail_id;
		this.noOfTrainingsAttended = noOfTrainingsAttended;
	}
	
	
	
}
