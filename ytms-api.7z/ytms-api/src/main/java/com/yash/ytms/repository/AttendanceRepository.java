package com.yash.ytms.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.yash.ytms.domain.Attendance;
import com.yash.ytms.domain.TrainingRequestForm;
import com.yash.ytms.dto.AttendanceDummyDto;

import jakarta.transaction.Transactional;

import java.util.Date;
import java.util.List;


@Repository
public interface AttendanceRepository extends JpaRepository<Attendance, Long> {
	
	
	
		
	 @Query(value = "select * from attendance_report where traning_id =:traningId", nativeQuery = true)
	 List<Attendance> findTrainingDeatils(long traningId);
	 
	 @Query(value = "select * from attendance_report where present_date LIKE CONCAT('%',:selectedDate,'%') and traning_id=:traningId ", nativeQuery = true)
	 List<Attendance> findSelectedDateTranieeData(Date selectedDate,Long traningId);
	 
	 @Query(value = "select * from attendance_report where traning_id =:traningId and emp_id=:emp_id", nativeQuery = true)
	 List<Attendance> findTranieeAttendanceData(long traningId,String emp_id);
	 
	 @Modifying
	 @Transactional
	 @Query(value = "update attendance_report  set actual_end_date = :actualEndDate,actual_start_date = :actualStartDate where traning_id=:traningId",nativeQuery = true)
	 int updateActualStartEndDate(Date actualEndDate,Date actualStartDate,Long traningId);
	 
	 @Query(value ="select "
	 		+ "  d.attendance_percentage, d.traning_id,d.emp_mail_id "
	 		+ "from attendance_report d inner join ( "
	 		+ "  select emp_mail_id,traning_id,max(attend_no_of_days) attend_no_of_days "
	 		+ "  from attendance_report "
	 		+ "  group by emp_mail_id,traning_id "
	 		+ ") t on t.emp_mail_id = d.emp_mail_id and t.attend_no_of_days=d.attend_no_of_days and t.traning_id=d.traning_id "
	 		+ "where d.emp_mail_id=:emp_id group by d.attendance_percentage,d.emp_mail_id,traning_id",nativeQuery=true)
	 public List<AttendanceDummyDto> findAttendence(String emp_id);
}
