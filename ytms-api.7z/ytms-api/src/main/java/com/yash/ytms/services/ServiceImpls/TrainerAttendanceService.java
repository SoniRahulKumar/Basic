package com.yash.ytms.services.ServiceImpls;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yash.ytms.domain.TrainerAttedance;
import com.yash.ytms.domain.TrainerAttedanceDate;
import com.yash.ytms.domain.TrainingRequestForm;
import com.yash.ytms.domain.YtmsUser;
import com.yash.ytms.dto.TrainerAttedanceDto;
import com.yash.ytms.dto.TrainerAttedanceSDEDDto;
import com.yash.ytms.repository.NominationRepository;
import com.yash.ytms.repository.TrainerAttendanceDateRepository;
import com.yash.ytms.repository.TrainerAttendanceRepository;
import com.yash.ytms.repository.TrainingRequestRepository;
import com.yash.ytms.repository.YtmsUserRepository;
import com.yash.ytms.security.userdetails.CustomUserDetails;
import com.yash.ytms.services.IServices.ITrainerAttendanceService;
import com.yash.ytms.util.EmailUtil;

@Service
@Transactional
public class TrainerAttendanceService implements ITrainerAttendanceService {
	final Logger LOGGER = LoggerFactory.getLogger(TrainerAttendanceService.class);

	@Autowired
	private TrainerAttendanceRepository trainerAttendanceRepository;

	@Autowired
	TrainerAttendanceDateRepository trainerAttendanceDateRepository;

	@Autowired
	private TrainingRequestRepository trainingRequestRepository;
	
	@Autowired
	private YtmsUserRepository ytmsUserRepository;;
	
	
	@Autowired
	private NominationRepository nominationRepository;

	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	private EmailUtil emailUtil;

	@Override
	public List<TrainerAttedanceDto> getPendingLeaves() {
		LOGGER.info("In Get Pending Leaves");
		List<TrainerAttedance> list = trainerAttendanceRepository.findAll();

		List<Long> ids = list.stream().map(TrainerAttedance::getTraining_id).toList();

		List<TrainingRequestForm> list2 = trainingRequestRepository.findAllById(ids);

		Map<Long, TrainingRequestForm> map = new HashMap<>();

		for (Long trainingId : ids) {

			Optional<TrainingRequestForm> op = list2.stream().filter(e -> Objects.equals(e.getId(), trainingId)).findFirst();

			if (op.isPresent()) {
				map.put(trainingId, op.get());
			}
		}

		List<TrainerAttedanceDto> listTrainerAttedanceDto = new ArrayList<>();

		list.stream().map(e -> {
			TrainerAttedanceDto trainerAttedanceDto = new TrainerAttedanceDto();
			trainerAttedanceDto.setId(e.getId());
			trainerAttedanceDto.setTraining_id(e.getTraining_id());
			trainerAttedanceDto.setLeave_Start_date(e.getLeave_Start_date());
			trainerAttedanceDto.setLeave_End_date(e.getLeave_End_date());
			trainerAttedanceDto.setLeave_Start_time(null);
			trainerAttedanceDto.setLeave_End_time(null);
			trainerAttedanceDto.setTranier_mail_id(e.getTranier_mail_id());
			trainerAttedanceDto.setTranier_name(e.getTranier_name());
			trainerAttedanceDto.setTranining_name(e.getTranining_name());
			trainerAttedanceDto.setLeave_impact_on_traning(e.getLeave_impact_on_traning());
			
			TrainingRequestForm training = map.get(e.getTraining_id());
			LOGGER.info(training.getActualStartTime());
			trainerAttedanceDto.setLeave_Start_time(training.getActualStartTime());
			trainerAttedanceDto.setLeave_End_time(training.getActualEndTime());
			listTrainerAttedanceDto.add(trainerAttedanceDto);
			return e;
		}).toList();
		
		return listTrainerAttedanceDto;
	}

	@Override
	public TrainerAttedanceDto approvePendingLeave(TrainerAttedanceDto trainerAttedanceDto) {
		LOGGER.info("In Approve Pending Leave");
		CustomUserDetails userDetails = (CustomUserDetails) SecurityContextHolder.getContext().getAuthentication()
				.getPrincipal();
		TrainerAttedance listTrainerAttedanceDto = modelMapper.map(trainerAttedanceDto, TrainerAttedance.class);
		listTrainerAttedanceDto.setAprrove_by(userDetails.getUsername());
		trainerAttendanceRepository.save(listTrainerAttedanceDto);
		
		
	    List<String> names=nominationRepository.findRequestorBYTrainingId(listTrainerAttedanceDto.getTraining_id());
		
		emailUtil.constructAndSendMailToTrainersAndRequestors(trainerAttedanceDto.getTranier_mail_id(),trainerAttedanceDto.getLeave_status(),names);
		return trainerAttedanceDto;
	}

	@Override
	public List<TrainerAttedance> saveAll(List<TrainerAttedance> trainerAttedances) {
		LOGGER.info("In Save All Trainer Attendace");
		for (TrainerAttedance trainerAttedance : trainerAttedances) {
			trainerAttendanceRepository.save(trainerAttedance);

			List<TrainerAttedanceDate> ll = trainerAttedance.getTrainerAttendanceDates();
			List<TrainerAttedanceDate> llb = ll.stream().map(e -> {
				e.setTrainerAttedance(trainerAttedance);
				return e;
			}).collect(Collectors.toList());
			trainerAttendanceDateRepository.saveAll(llb);

		}
		return trainerAttedances;
	}

	@Override
	public List<TrainerAttedanceDto> approvedLeaves() {
		LOGGER.info("In Approve Leaves");
		List<TrainerAttedanceDto> listDto = new ArrayList<>();
		List<TrainerAttedanceSDEDDto> list = trainerAttendanceRepository.findAllBySdEd();

		for (TrainerAttedanceSDEDDto tr : list) {

			TrainerAttedanceDto trainerAttedanceDto = new TrainerAttedanceDto();

			trainerAttedanceDto.setLeave_Start_date(tr.getLeave_Start_date());
			trainerAttedanceDto.setLeave_End_date(tr.getLeave_End_date());
			trainerAttedanceDto.setLeave_status(tr.getLeave_status());
			trainerAttedanceDto.setTranier_mail_id(tr.getTranier_mail_id());

			List<String> listNames = trainerAttendanceRepository.findAllByDates(tr.getTranier_mail_id(),
					tr.getLeave_Start_date(), tr.getLeave_End_date(), tr.getLeave_status());

			if (listNames.size() == 1) {
				String result = StringUtils.substringBetween(listNames.get(0), "(", ")");
				trainerAttedanceDto.setTranining_name(result);
			} else {
				String trainingName = "";
				for (String input : listNames) {
					String result = StringUtils.substringBetween(input, "(", ")");
					LOGGER.info(result);
					trainingName = trainingName.isEmpty() ? result : trainingName + "-" + result;
				}
				trainerAttedanceDto.setTranining_name(trainingName);
			}

			listDto.add(trainerAttedanceDto);
		}

		return listDto;

	}

}
