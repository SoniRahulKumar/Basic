package com.yash.yotaapi.exceptions;

public class TestAvailableException extends RuntimeException {
	private static final long serialVersionUID = 1L;
	
	public TestAvailableException(String message){
		
		super(message);
	}

}
