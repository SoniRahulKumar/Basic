package com.yash.dtoexcelconvertor.dto;

import lombok.Data;

import java.util.Date;
@Data
public class TrainingReqForm {

    private long id;
    private String trainingIdentifierName;
    private String trainingDescription;
    private Date startDate;
    private Date endDate;
    private Date actualStartDate;
    private Date actualEndDate;
    private Date createdAt;
    private Date updatedAt;
    private String status;
    private String userName;
    private int noOfParticipant;
    private String declinedMessage;
}
