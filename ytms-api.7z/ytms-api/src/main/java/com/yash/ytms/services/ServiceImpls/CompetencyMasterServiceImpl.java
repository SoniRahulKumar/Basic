/**
 * 
 */
package com.yash.ytms.services.ServiceImpls;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.yash.ytms.domain.CompetencyMaster;
import com.yash.ytms.dto.CompetencyMasterDto;
import com.yash.ytms.dto.ResponseWrapperDto;
import com.yash.ytms.exception.ApplicationException;
import com.yash.ytms.repository.CompetencyMasterRepository;
import com.yash.ytms.services.IServices.ICompetencyMasterService;

/**
 * 
 */
@Service
public class CompetencyMasterServiceImpl implements ICompetencyMasterService {
	final Logger LOGGER = LoggerFactory.getLogger(CompetencyMasterServiceImpl.class);
	@Autowired
	CompetencyMasterRepository competencyMasterRepository;
	
	@Autowired
    private ModelMapper modelMapper;
	
	public List<CompetencyMasterDto> getCompetencyMasterList(){
		LOGGER.info("In Get Competency Master List");
		return modelMapper.map(competencyMasterRepository.findAll(), List.class); 
	}
	
	@Override
    public CompetencyMasterDto createCompetencyMaster (CompetencyMasterDto competencyMasterDto) {
		LOGGER.info("In Create Competency Master");
		CompetencyMaster competencyMaster = null;

        if (ObjectUtils.isNotEmpty(competencyMasterDto)) {
        	competencyMaster = this
                    .modelMapper
                    .map(competencyMasterDto, CompetencyMaster.class);

        	competencyMaster = this
                    .competencyMasterRepository
                    .save(competencyMaster);

        	competencyMasterDto = this
                    .modelMapper
                    .map(competencyMaster, CompetencyMasterDto.class);
        } else {
            throw new ApplicationException("Competency Master are empty or null");
        }

        return competencyMasterDto;
    }
 
	@Override
    @Async
    @Scheduled(initialDelay = 1000, fixedDelay = 1800000)
    public void competencyMasterUpdateScheduler() {
		LOGGER.info("In Competency Master Update Scheduler");
        List<CompetencyMasterDto> allCompetency = new ArrayList<>();
        allCompetency = this.getCompetencyMasterList();
        int count =1;
        if (allCompetency.isEmpty()) {

//        	allCompetency.add(new CompetencyMasterDto(1, "JAVA", true));
//        	allCompetency.add(new CompetencyMasterDto(2, "REACT", true));
//        	allCompetency.add(new CompetencyMasterDto(3, "UI-HTML", true));
//        	allCompetency.add(new CompetencyMasterDto(4, "UI-CSS", true));
//        	allCompetency.add(new CompetencyMasterDto(5, "ANGULAR", true));
//        	allCompetency.add(new CompetencyMasterDto(6, "DotNet", true));
        	
        	allCompetency.add(new CompetencyMasterDto(count++, "Microsoft", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Optimizely", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Technical", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Account Management", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Core-Infra", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP OpenText", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "ServiceNow", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Agile Consulting", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SuccessFactors", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Java", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Python", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Security Protection Services", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "IBM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Infra", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Service Management", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Cloud Infra", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Monitoring & Automation", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Testing", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - ECC SD", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Salesforce", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Data & Analytics", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Bioinformatics", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "RPA", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP MII", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Business Analysis", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "XACT Testing", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Digital Workplace", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Testing", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "AWS - App Dev", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "DevOps", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Content Management System (CMS)", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Legacy", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Mobility", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "PTG Data", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "User Interface (UI)", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Business Consulting", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP DMC", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Oracle", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "EmbeddedSystem_FA_IoT", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP IAM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Infor", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "User Experience (UX)", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Service Desk", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Node.js", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "PMO - Digital", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Product Lifecycle Management (PLM)", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "PMO", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "QAD", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Resource Management - Digital", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Resource Management - SAP", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP MDG", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - APO", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Ariba", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Data", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - ECC BPC", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - ECC FICO", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - ECC EWM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - S/4 HANA - EWM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - ECC MM/WM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - ECC PM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - ECC PP / QM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - ECC PS", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - ECC REFX", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - ECC TRM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP EHS", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP HCM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP IBP", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - PEO", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - PLM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - S/4 HANA BPC", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - S/4 HANA FICO", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - S/4 HANA MM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - S/4 HANA PM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - S/4 HANA PP / QM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - S/4 HANA PS", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - S/4 HANA REFX", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - S/4 HANA SD", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - S/4 HANA TRM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Security & GRC", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "SAP Functional - SRM", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Security", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Process Excellence", true));
        	allCompetency.add(new CompetencyMasterDto(count++, "Customer Experience Management", true));

        	allCompetency.forEach(this :: createCompetencyMaster);
        }
    }
	
	public ResponseWrapperDto saveCompetency(CompetencyMasterDto formDto) {
		LOGGER.info("In Save Competency");
		ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();
		CompetencyMaster master = null;
		if (formDto != null) {
			try {
				master = modelMapper.map(formDto, CompetencyMaster.class);
				if (ObjectUtils.isNotEmpty(master)) {
					master.setStatus(true);
					responseWrapperDto.setData(competencyMasterRepository.save(master));
					responseWrapperDto.setMessage("Data Save Successfully..");
				} else {
					responseWrapperDto.setMessage("transection fail !");
				}
			} catch (Exception e) {
				responseWrapperDto.setMessage("unable to save data !");
			}

		} else {
			responseWrapperDto.setMessage("Request Form is empty !");

		}
		return responseWrapperDto;
	}
}
