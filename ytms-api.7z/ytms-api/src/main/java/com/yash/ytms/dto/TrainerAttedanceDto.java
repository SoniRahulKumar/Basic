package com.yash.ytms.dto;



import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Data
public class TrainerAttedanceDto {

	private Long id;
	
	private Long training_id;
	
	private String tranier_mail_id;
	
	private String tranier_name;
	
	private String tranining_name;
	
	private String leave_status;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private Date leave_Start_date;
	
	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	private Date leave_End_date;
	
    private String leave_Start_time;
	
	private String leave_End_time;
	
	private String aprrove_by;
	
	private String leave_impact_on_traning;
	
	

	public TrainerAttedanceDto(String tranier_mail_id, String tranining_name, 
			Date leave_Start_date, Date leave_End_date,String leave_status,String aprrove_by, String leave_impact_on_traning) {
		super();
		this.tranier_mail_id = tranier_mail_id;
		this.tranining_name = tranining_name;
		this.leave_status = leave_status;
		this.leave_Start_date = leave_Start_date;
		this.leave_End_date = leave_End_date;
		this.aprrove_by= aprrove_by;
		this.leave_impact_on_traning = leave_impact_on_traning;
	}
	
	
	

}
