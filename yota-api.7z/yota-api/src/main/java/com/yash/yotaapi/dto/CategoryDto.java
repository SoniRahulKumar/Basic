package com.yash.yotaapi.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * DTO for {@link com.yash.yotaapi.entity.Category}
 * <p>
 * Project Name - YOTA_NEW
 * <p>
 * IDE Used - IntelliJ IDEA
 *
 * @author - yashr
 * @since - 22-04-2024
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CategoryDto {

    private Long id;

    private String name;

//    @JsonIgnore
    private List<QuestionsDto> questions;

    private Integer questionCountUnderCategory = 0;

    @JsonIgnore
    private TechnologyDto technology;
}
