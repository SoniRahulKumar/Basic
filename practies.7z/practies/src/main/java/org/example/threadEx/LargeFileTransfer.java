package org.example.threadEx;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LargeFileTransfer {
    private static final int CHUNK_SIZE = 1024 * 1024 * 1024; // 1GB
    private static final int NUM_THREADS = 4; // Adjust as needed
    public static void transferFile(String sourcePath, String destinationPath) throws IOException {
        ExecutorService executor = Executors.newFixedThreadPool(NUM_THREADS);

        try (FileChannel sourceChannel = FileChannel.open(java.nio.file.Paths.get(sourcePath), java.nio.file.StandardOpenOption.READ);
             FileChannel destinationChannel = FileChannel.open(java.nio.file.Paths.get(destinationPath), java.nio.file.StandardOpenOption.CREATE, java.nio.file.StandardOpenOption.WRITE)) {

            long fileSize = sourceChannel.size();
            long position = 0;

            while (position < fileSize) {
                long chunkSize = Math.min(CHUNK_SIZE, fileSize - position);
                ByteBuffer buffer = ByteBuffer.allocate((int) chunkSize); // Cast is safe here

                sourceChannel.read(buffer, position);
                buffer.flip(); // Prepare buffer for writing

                // Submit the chunk transfer task to the thread pool
                executor.submit(() -> {
                    try {
                        destinationChannel.write(buffer); // Write the chunk
                        // ... (Add checksum calculation and verification here) ...
                    } catch (IOException e) {
                        e.printStackTrace(); // Handle errors appropriately
                    }
                });

                position += chunkSize;
            }
        }

        executor.shutdown(); // Important: Shut down the executor after all tasks are submitted
        while (!executor.isTerminated()) {
            // Wait for all tasks to complete
        }

        System.out.println("Transfer complete.");
    }

    public static void main(String[] args) throws IOException {
        String filePath = "D:/EclipseWS/Basic/Java1_8/src/StreamApi/DiscountProductPrice.java"; // Replace with your test file path
        File file = new File(filePath);
        transferFile(file.getAbsolutePath(), "D:/IntelliJWS/practies/src/main/java/org/example/java8");
    }
}