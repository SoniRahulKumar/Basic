package com.yash.dtoexcelconvertor.dto;

import java.util.Date;

//@Sheet
public class TrainingRequestForm {
   /* @SheetColumn("ID")
    private long id;
    @SheetColumn("TrainingIdentifierName")
    private String trainingIdentifierName;
    @SheetColumn("TrainingDescription")
    private String trainingDescription;
    @SheetColumn("StartDate")
    private Date startDate;
    @SheetColumn("EndDate")
    private Date endDate;
    @SheetColumn("ActualStartDate")
    private Date actualStartDate;
    @SheetColumn("ActualEndDate")
    private Date actualEndDate;
    @SheetColumn("CreatedAt")
    private Date createdAt;
    @SheetColumn("UpdatedAt")
    private Date updatedAt;
    @SheetColumn("Status")
    private String status;
    @SheetColumn("UserName")
    private String userName;
    @SheetColumn("NoOfParticipant")
    private int noOfParticipant;
    @SheetColumn("DeclinedMessage")
    private String declinedMessage;*/
}
