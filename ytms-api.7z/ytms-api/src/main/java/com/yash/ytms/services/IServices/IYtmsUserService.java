package com.yash.ytms.services.IServices;

import java.security.Principal;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.yash.ytms.dto.ResponseWrapperDto;
import com.yash.ytms.dto.UserRoleDto;
import com.yash.ytms.dto.YtmsUserDto;

/**
 * Project Name - ytms-api
 * <p>
 * IDE Used - IntelliJ IDEA
 *
 * @author - yash.raj
 * @since - 25-01-2024
 */
public interface IYtmsUserService {

    YtmsUserDto createNewUser(YtmsUserDto userDto);

    YtmsUserDto getUserByEmailAdd(String emailAdd);

    List<YtmsUserDto> getAllPendingUsers();

    Boolean approvePendingUser(String emailAdd, String roleName);

    Boolean declinePendingUser(String emailAdd);

    ResponseWrapperDto forgotPassword(String email);

    Boolean resetPassword(Map<String, String> map);

    ResponseWrapperDto changePassword(Map<String, String> map);

    List<YtmsUserDto> getAllTrainers();
    
    List<YtmsUserDto> findByUserRoleId(Long roleId);
    
    YtmsUserDto getUserByPrincipal(Principal principal);
    
    Set<UserRoleDto> getAllRole();
    
    List<YtmsUserDto> getAllApprovedUsers();
    
    List<String> findEmailByTrainer(String fullName);
    
}
