package com.yash.ytms.constants;

/**
 * Project Name - ytms-api
 * <p>
 * IDE Used - IntelliJ IDEA
 *
 * @author - yash.raj
 * @since - 25-01-2024
 */
public enum RequestStatusTypes {

    SUCCESS,

    FAILED,

    NOT_FOUND,

    UNAUTHORIZED
}
