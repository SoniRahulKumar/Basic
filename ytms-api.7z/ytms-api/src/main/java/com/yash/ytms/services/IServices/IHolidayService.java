package com.yash.ytms.services.IServices;

import java.util.List;

import com.yash.ytms.dto.HolidayDto;

public interface IHolidayService {
List<HolidayDto> saveAllHolidays(List<HolidayDto> holidayDto);
List<HolidayDto> getAllHolidays();
}
