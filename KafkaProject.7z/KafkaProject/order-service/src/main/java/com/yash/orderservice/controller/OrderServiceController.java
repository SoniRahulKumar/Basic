package com.yash.orderservice.controller;
import com.yash.basedomains.model.Order;
import com.yash.basedomains.model.OrderEvent;
import com.yash.orderservice.kafka.OrderProducer;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yash.basedomains.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1")
public class OrderServiceController {
    private OrderProducer orderProducer;
    public OrderServiceController(OrderProducer orderProducer) {
        this.orderProducer = orderProducer;
    }

    @PostMapping("/orders")
    public String sendMessage(@RequestBody Order order){

        order.setId(UUID.randomUUID().toString());

        OrderEvent orderEvent = new OrderEvent();
        orderEvent.setMessage("new order ");
        orderEvent.setStatus("pending");
        orderEvent.setOrder(order);

        orderProducer.sendMessage(orderEvent);

        return  "Order placed .....";
    }

}
