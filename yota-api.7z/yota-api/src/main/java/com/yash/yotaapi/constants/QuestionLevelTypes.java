package com.yash.yotaapi.constants;

/**
 * Project Name - YOTA_NEW
 * <p>
 * IDE Used - IntelliJ IDEA
 *
 * @author - yashr
 * @since - 22-04-2024
 */
public enum QuestionLevelTypes {

    EASY,

    MEDIUM,

    HARD
}
