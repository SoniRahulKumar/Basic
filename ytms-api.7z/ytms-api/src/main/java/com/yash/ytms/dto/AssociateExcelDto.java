package com.yash.ytms.dto;

import java.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssociateExcelDto {

    private Long id;
    private String emp_id;
    private String emp_name;
    private String emp_mail_id;
    private String grade;
    private String resourceType;
    private String trainingStack;
    private String trainingName;
    private String trainingDescription;
    private String purposeToAttendTraining;
    private Integer trainingDuration;
    private LocalDate trainingStartDate;
    private LocalDate trainingEndDate;
    private String currentSkill;
    private String upgradedSkill;
    private Double preAssessment;
    private Double finalScore;
    private String current_allocation;
    private String project;
    private String current_location;
    private String status;
    private String feedback;
    private String trainer;
    private Double technicalSkills;

	private Double attitude;

	private Double commSkills;

	private Double workQuality;

	private Double overAllRating;
   // private Integer noOfTraining;
   // private Integer attendance;

}
