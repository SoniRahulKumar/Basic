/**
 * 
 */
package com.yash.ytms.services.ServiceImpls;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.ObjectUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import com.yash.ytms.domain.UnitMaster;
import com.yash.ytms.dto.ResponseWrapperDto;
import com.yash.ytms.dto.UnitMasterDto;
import com.yash.ytms.exception.ApplicationException;
import com.yash.ytms.repository.UnitMasterRepository;
import com.yash.ytms.services.IServices.IUnitMasterService;

/**
 * 
 */
@Service
public class UnitMasterServiceImpl implements IUnitMasterService {
	final Logger LOGGER = LoggerFactory.getLogger(UnitMasterServiceImpl.class);
	
	 @Autowired
	 private UnitMasterRepository unitMasterRepository;
	 
	 @Autowired
	 private ModelMapper modelMapper;
	 
	 @Override
	 public List<UnitMasterDto> getUnitMasterList(){
		 LOGGER.info("In Get Unit Master List");
		 return modelMapper.map(unitMasterRepository.findAll(),List.class);
	 }
	 
	 @Override
	    public UnitMasterDto createUnitMaster(UnitMasterDto unitMasterDto) {
		 LOGGER.info("In Create Unit Master");
		 UnitMaster unitMaster = null;

	        if (ObjectUtils.isNotEmpty(unitMasterDto)) {
	        	unitMaster = this
	                    .modelMapper
	                    .map(unitMasterDto, UnitMaster.class);

	        	unitMaster = this
	                    .unitMasterRepository
	                    .save(unitMaster);

	            unitMasterDto = this
	                    .modelMapper
	                    .map(unitMaster, UnitMasterDto.class);
	        } else {
	            throw new ApplicationException("Unit Master are empty or null");
	        }

	        return unitMasterDto;
	    }
	 
	 @Override
	    @Async
	    @Scheduled(initialDelay = 1000, fixedDelay = 1800000)
	    public void unitUpdateScheduler() {
		 LOGGER.info("In Unit Update Scheduler");
	        List<UnitMasterDto> allUnits = new ArrayList<>();
	        allUnits = this
	                .getUnitMasterList();

	        if (allUnits.isEmpty()) {

	            allUnits.add(new UnitMasterDto(1, "BG1-BU3", true));
	            allUnits.add(new UnitMasterDto(2, "BG1-BU4", true));
	            allUnits.add(new UnitMasterDto(3, "BG2-BU1", true));
	            allUnits.add(new UnitMasterDto(4, "BG2-BU11", true));
	            allUnits.add(new UnitMasterDto(5, "BG2-BU12", true));
	            allUnits.add(new UnitMasterDto(6, "BG2-BU13", true));
	            allUnits.add(new UnitMasterDto(7, "BG2-BU15", true));
	            allUnits.add(new UnitMasterDto(8, "BG2-BU2", true));
	            allUnits.add(new UnitMasterDto(9, "BG2-BU6", true));
	            allUnits.add(new UnitMasterDto(10, "BG2-BU7", true));
	            allUnits.add(new UnitMasterDto(11, "BG2-BU9", true));
	            allUnits.add(new UnitMasterDto(12, "BG4-BU2", true));
	            allUnits.add(new UnitMasterDto(13, "BG4-BU3", true));
	            allUnits.add(new UnitMasterDto(14, "BG4-BU4", true));
	            allUnits.add(new UnitMasterDto(15, "BG4-BU5", true));
	            allUnits.add(new UnitMasterDto(16, "BG4-BU9", true));
	            allUnits.add(new UnitMasterDto(17, "BG502-BU001", true));
	            allUnits.add(new UnitMasterDto(18, "BG506-BU001", true));
	            allUnits.add(new UnitMasterDto(19, "BG506-BU006", true));
	            allUnits.add(new UnitMasterDto(20, "BG506-BU007", true));
	            allUnits.add(new UnitMasterDto(21, "BG506-BU008", true));
	            allUnits.add(new UnitMasterDto(22, "BG506-BU011", true));
	            allUnits.add(new UnitMasterDto(23, "BG506-BU013", true));
	            allUnits.add(new UnitMasterDto(24, "BG506-BU015", true));
	            allUnits.add(new UnitMasterDto(25, "BG512-BU004", true));
	            allUnits.add(new UnitMasterDto(26, "BG5-BU1", true));
	            allUnits.add(new UnitMasterDto(27, "BG5-BU10", true));
	            allUnits.add(new UnitMasterDto(28, "BG5-BU11", true));
	            allUnits.add(new UnitMasterDto(29, "BG5-BU12", true));
	            allUnits.add(new UnitMasterDto(30, "BG5-BU14", true));
	            allUnits.add(new UnitMasterDto(31, "BG5-BU15", true));
	            allUnits.add(new UnitMasterDto(32, "BG5-BU16", true));
	            allUnits.add(new UnitMasterDto(33, "BG5-BU2", true));
	            allUnits.add(new UnitMasterDto(34, "BG5-BU3", true));
	            allUnits.add(new UnitMasterDto(35, "BG5-BU5", true));
	            allUnits.add(new UnitMasterDto(36, "BG5-BU6", true));
	            allUnits.add(new UnitMasterDto(37, "BG5-BU7", true));
	            allUnits.add(new UnitMasterDto(38, "BG5-BU8", true));
	            allUnits.add(new UnitMasterDto(39, "BG5-BU9", true));
	            allUnits.add(new UnitMasterDto(40, "BG601-BU001", true));
	            allUnits.add(new UnitMasterDto(41, "BG602-BU001", true));
	            allUnits.add(new UnitMasterDto(42, "BG603-BU001", true));
	            allUnits.add(new UnitMasterDto(43, "BG606-BU001", true));
	            allUnits.add(new UnitMasterDto(44, "BG6-BU3", true));
	            allUnits.add(new UnitMasterDto(45, "BG6-BU5", true));
	            allUnits.add(new UnitMasterDto(46, "BG701-BU009", true));
	            allUnits.add(new UnitMasterDto(47, "BG701-BU010", true));
	            allUnits.add(new UnitMasterDto(48, "BG7-BU2", true));
	            allUnits.add(new UnitMasterDto(49, "SSG4-SSU2", true));
	            
	            allUnits.forEach(this :: createUnitMaster);
	        }
	    }

	

	public ResponseWrapperDto saveUnit(UnitMasterDto formDto) {
		LOGGER.info("In Save Unit");
		ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();
		UnitMaster master = null;
		if (formDto != null) {
			try {
				master = modelMapper.map(formDto, UnitMaster.class);
				if (ObjectUtils.isNotEmpty(master)) {
					master.setStatus(true);
					responseWrapperDto.setData(unitMasterRepository.save(master));
					responseWrapperDto.setMessage("Data Save Successfully..");
				} else {
					responseWrapperDto.setMessage("transection fail !");
				}
			} catch (Exception e) {
				responseWrapperDto.setMessage("unable to save data !");
			}

		} else {
			responseWrapperDto.setMessage("Request Form is empty !");

		}
		return responseWrapperDto;
	}
}
