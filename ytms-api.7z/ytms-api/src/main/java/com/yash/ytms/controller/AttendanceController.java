package com.yash.ytms.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;
import org.apache.commons.collections4.map.HashedMap;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.HorizontalAlignment;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.ytms.constants.UserAccountStatusTypes;
import com.yash.ytms.domain.Attendance;
import com.yash.ytms.domain.Nomination;
import com.yash.ytms.domain.OptionalHoliday;
import com.yash.ytms.domain.TrainerAttedance;
import com.yash.ytms.domain.TrainerAttedanceDate;
import com.yash.ytms.dto.ResponseWrapperDto;
import com.yash.ytms.dto.TrainingRequestFormDto;
import com.yash.ytms.repository.AttendanceRepository;
import com.yash.ytms.repository.NominationRepository;
import com.yash.ytms.repository.TrainerAttendanceRepository;
import com.yash.ytms.repository.TrainingRequestRepository;
import com.yash.ytms.services.IServices.IOptionalHolidayService;
import com.yash.ytms.services.IServices.ITrainerAttendanceService;
import com.yash.ytms.services.IServices.IYtmsTraningRequestService;
import com.yash.ytms.services.IServices.IYtmsUserService;
import com.yash.ytms.util.EmailUtil;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@RestController
@RequestMapping("/register/attendance")
public class AttendanceController {
	final Logger LOGGER = LoggerFactory.getLogger(AttendanceController.class);
	@Autowired
	NominationRepository nominationRepository;

	@Autowired
	TrainingRequestController trainingRequestController;

	@Autowired
	TrainingRequestRepository trainingRequestRepository;

	@Autowired
	private IYtmsTraningRequestService traningRequestService;
	
	
	@Autowired
	private IYtmsUserService ytmsUserService;
	
	@Autowired
	private ITrainerAttendanceService trainerAttendanceService;
	
	@Autowired
	private IOptionalHolidayService optionalHolidayService;


	@Autowired
	AttendanceRepository attendanceRepository;

	@Autowired
	TrainerAttendanceRepository trainerAttendanceRepository;

	@Autowired
	private EmailUtil emailUtil;
	
	@GetMapping("/createAttendanceforNewNomination/{traningId}/{nominationId}")
	public ResponseEntity<ResponseWrapperDto> createAttendanceForNewNominatio(@PathVariable String traningId,@PathVariable String nominationId) {

		ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();

		TrainingRequestFormDto tr = traningRequestService.getTrainingRequestFormById(Long.parseLong(traningId));
		Optional<Nomination> optionalList = nominationRepository.findById(Long.parseLong(nominationId));
		List<Attendance> allAttendancesList = attendanceRepository.findTrainingDeatils(Long.parseLong(traningId));
		if(allAttendancesList.size()>0) {
			
		
		Nomination nominee = null;
		if(optionalList.isPresent()) {
			nominee=optionalList.get();
		}

		Date startDate = tr.getActualStartDate();
		Date endDate = tr.getActualEndDate();
		LocalDate convertedStartdate = AttendanceController.convert(startDate);
		LocalDate covertedEnddate = AttendanceController.convert(endDate);
		List<TrainerAttedance> trainerAttedanceList = trainerAttendanceRepository
				.findTranierAttendanceDeatils(Long.parseLong(traningId));
		HashedMap<String, Object> map = 
				addDaysSkippingWeekendsAndOptionalHoliday(convertedStartdate, covertedEnddate, 0);
		List<LocalDate> listDate = (List<LocalDate>) map.get("attendsDateDateListInLocalDateFormat");
		Double noofDyas = (Double) map.get("noOfdays");

		LocalDate maxDate = listDate.stream().max(LocalDate::compareTo).get();
		Double noofDyasNeedtoAdd = 0.0;
		if (trainerAttedanceList.size() > 0 && listDate.size() > 0) {

			for (TrainerAttedance trainerAttedance : trainerAttedanceList) {
				List<TrainerAttedanceDate> listed = trainerAttedance.getTrainerAttendanceDates();
				for (TrainerAttedanceDate trainerAttedanceDate : listed) {
					LocalDate date = convert(trainerAttedanceDate.getAttendance_date());
					if (listDate.contains(date)) {

						listDate.remove(date);
						noofDyasNeedtoAdd++;
					}
				}
				
			}

			while (noofDyasNeedtoAdd > 0) {

				LocalDate result = maxDate.plusDays(1);
				if (checkDaysComeInWeekendsAndOptionalHoliday(result)) {
					listDate.add(result);
					noofDyasNeedtoAdd--;
				}
				maxDate = result;

			}

			LocalDate fEndDate = listDate.stream().max(LocalDate::compareTo).get();
			LocalDate fstartDate = listDate.stream().min(LocalDate::compareTo).get();
			endDate = asDate(fEndDate);
			startDate = asDate(fstartDate);
		}

		if (nominee!=null) {

			for (LocalDate date : listDate) {
				Attendance attendance = new Attendance();
				attendance.setActualEndDate(endDate);
				attendance.setActualStartDate(startDate);
				attendance.setEmp_id(nominee.getEmp_id());
				attendance.setEmp_mail_id(nominee.getEmp_mail_id());
				attendance.setPresentDate(asDate(date));
				attendance.setTraning_id(Long.parseLong(traningId));
				attendance.setTraning_noOfDays(noofDyas);
				attendance.setEmp_name(nominee.getEmp_name());
				attendance.setEmploymentStatus(nominee.getEmployment_status());
				attendanceRepository.save(attendance);

			}
		}

		}
		responseWrapperDto.setMessage("Data Submit Successfully!!!!!");

		return new ResponseEntity<ResponseWrapperDto>(responseWrapperDto, HttpStatus.OK);
	}




	@GetMapping("/getTraninerAttendaceData")
	public ResponseEntity<Object> getTraninerAttendaceData() {
		Map<String, Object> finalhashmap = new HashMap<>();
		Map<Long, String> hashmap = new HashMap<>();
		Map<Long, List<String>> idVsDateMap = new HashMap<>();
		Set<String> finalStringDateList = new HashSet<>();
		Set<Long> trainngIDs = new HashSet<>();
		List<TrainerAttedance> list = trainerAttendanceRepository.findAllAbsentLeave();

		for (TrainerAttedance trainerAttedance : list) {

			trainngIDs.add(trainerAttedance.getTraining_id());
			
			List<TrainerAttedanceDate> listed = trainerAttedance.getTrainerAttendanceDates();
			
			for(TrainerAttedanceDate trainerAttedanceDate:listed) {
				LocalDate result = convert(trainerAttedanceDate.getAttendance_date());
				String date = result.format(DateTimeFormatter.ISO_LOCAL_DATE);
				String leaveStatus=trainerAttedanceDate.getTrainerAttedance().getLeave_status();
				if(UserAccountStatusTypes.APPROVED.toString().equalsIgnoreCase(leaveStatus)) {
					finalStringDateList.add(date);	
				}
				
				if (!hashmap.containsKey(trainerAttedance.getTraining_id())) {
					hashmap.put(trainerAttedance.getTraining_id(), date);
				}
			}
			
			
			

		}

		for (Long tarningId : trainngIDs) {
			ArrayList<String> sdateList = new ArrayList<>();
			List<Date> datelist = trainerAttendanceRepository.findAttendanceDateData(tarningId);

			for (Date datetemp : datelist) {
				LocalDate tempresult = convert(datetemp);
				String fdate = tempresult.format(DateTimeFormatter.ISO_LOCAL_DATE);
				sdateList.add(fdate);
			}
			idVsDateMap.put(tarningId, sdateList);
		}

		finalhashmap.put("absentDates", finalStringDateList);
		finalhashmap.put("absentData", hashmap);
		finalhashmap.put("idvsdate", idVsDateMap);

		return new ResponseEntity<>(finalhashmap, HttpStatus.OK);
	}

	@GetMapping("/saveTraninerAttendaceData/{startDate}/{endDate}/{traningIds}/{isTraingImpact}")
	public ResponseEntity<ResponseWrapperDto> saveTraninerAttendaceData(@PathVariable String startDate,
			@PathVariable String endDate, @PathVariable String[] traningIds, @PathVariable String isTraingImpact) {
		String[] traingID = traningIds;
		String tempIsTraingImapct = "Yes";

		if (tempIsTraingImapct != null && tempIsTraingImapct != "" && "true".equalsIgnoreCase(isTraingImpact)) {
			tempIsTraingImapct = "No";
		}
		LocalDate convertedLeaveStartDate = LocalDate.parse(startDate);
		LocalDate convertedLeaveEndDate = LocalDate.parse(endDate);
		HashedMap<String, Object> map = addDaysSkippingWeekendsAndOptionalHoliday(convertedLeaveStartDate,
				convertedLeaveEndDate, 0);
		List<LocalDate> listDate = (List<LocalDate>) map.get("attendsDateDateListInLocalDateFormat");
		List<TrainerAttedance> listTrainerAttendance = new ArrayList<>();
		
	
		for (String traningId : traingID) {
			List<TrainerAttedanceDate> listTrainerAttendanceDates = new ArrayList<>();
			for (LocalDate date : listDate) {

				Long attendavce = trainerAttendanceRepository
						.findSelectedDateTrainerData(asDate(date), Long.parseLong(traningId));

				if (attendavce == 0) {
					TrainerAttedanceDate trainerAttendanceDate = new TrainerAttedanceDate();
					trainerAttendanceDate.setAttendance_date(asDate(date));
					listTrainerAttendanceDates.add(trainerAttendanceDate);

				}

			}
			if(listTrainerAttendanceDates.size() >0) {
				TrainingRequestFormDto tr = traningRequestService
						.getTrainingRequestFormById(Long.parseLong(traningId));
				TrainerAttedance trainerAttedance = new TrainerAttedance();

				trainerAttedance.setTraining_id(tr.getId());
				if(null != tr.getTrainerEmail()) {
					trainerAttedance.setTranier_mail_id(tr.getTrainerEmail());
				}else {
					List<String> emails = ytmsUserService.findEmailByTrainer(tr.getTrainer());
					trainerAttedance.setTranier_mail_id(emails.get(0));
				}
				trainerAttedance.setTranier_name(tr.getTrainer());
				
				trainerAttedance.setTranining_name(tr.getTrainingName());
				trainerAttedance.setLeave_Start_date(asDate(convertedLeaveStartDate));
				trainerAttedance.setLeave_End_date(asDate(convertedLeaveEndDate));
				trainerAttedance.setLeave_status("PENDING");
				trainerAttedance.setLeave_impact_on_traning(tempIsTraingImapct);
				trainerAttedance.setTrainerAttendanceDates(listTrainerAttendanceDates);
				listTrainerAttendance.add(trainerAttedance);
			}
			
		}
		
		
		trainerAttendanceService.saveAll(listTrainerAttendance);

		emailUtil.constructAndSendMailToTechnicalManagers(listTrainerAttendance);

		ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();
		responseWrapperDto.setMessage("Success");

		return new ResponseEntity<ResponseWrapperDto>(responseWrapperDto, HttpStatus.OK);
	}

	@GetMapping("/changeAttendanceBasedOnLeave/{startDate}/{endDate}/{traningIds}")
	public ResponseEntity<ResponseWrapperDto> changeAttendanceDataBasedOnLeave(@PathVariable String startDate,
			@PathVariable String endDate, @PathVariable String[] traningIds) {
		String[] traingID = traningIds;
		LocalDate convertedLeaveStartDate = LocalDate.parse(startDate);
		LocalDate convertedLeaveEndDate = LocalDate.parse(endDate);
		HashedMap<String, Object> map = addDaysSkippingWeekendsAndOptionalHoliday(convertedLeaveStartDate,
				convertedLeaveEndDate, 0);
		List<LocalDate> listDate = (List<LocalDate>) map.get("attendsDateDateListInLocalDateFormat");
		Double noofDyas = (Double) map.get("noOfdays");
		for (String traningId : traingID) {
			TrainingRequestFormDto tr = traningRequestService.getTrainingRequestFormById(Long.parseLong(traningId));
			List<Attendance> allAttendancesList = attendanceRepository.findTrainingDeatils(Long.parseLong(traningId));
			LocalDate originalTraningStartDate = convert(tr.getActualStartDate());
			LocalDate orignalTraningEndDate = convert(tr.getActualEndDate());
			HashedMap<String, Object> traningDeatilsMap = addDaysSkippingWeekendsAndOptionalHoliday(
					originalTraningStartDate, orignalTraningEndDate, 0);
			List<LocalDate> traningDatesList = (List<LocalDate>) traningDeatilsMap
					.get("attendsDateDateListInLocalDateFormat");
			Double traningnoofDyas = (Double) traningDeatilsMap.get("noOfdays");
			List<Nomination> listNom = nominationRepository.findAllByTrainingId(Long.parseLong(traningId));
			List<LocalDate> newDateNeedtoAaddList = new ArrayList<>();
			// When leave Apply for Single day
			if (convertedLeaveStartDate.isEqual(convertedLeaveEndDate)) {

				// when attendace Record is already present
				// if(allAttendancesList.size()>0) {
				LocalDate finalStartDate = originalTraningStartDate;
				LocalDate finalEndDate = orignalTraningEndDate;
				Double tempnoofDyas = 0.0;

				if (traningDatesList.contains(convertedLeaveEndDate)) {
					traningDatesList.remove(convertedLeaveEndDate);
				}

				if (originalTraningStartDate.isEqual(convertedLeaveEndDate)) {
					finalStartDate = traningDatesList.stream().min(LocalDate::compareTo).get();
				} else if (orignalTraningEndDate.isEqual(convertedLeaveEndDate)) {
					finalEndDate = convertedLeaveEndDate;
				}

				if (allAttendancesList.size() > 0) {

					// This is for delete the record which is present in Attendance for Apply leave
					// date
					for (LocalDate date : listDate) {
						List<Attendance> allAttendancesListtemp = attendanceRepository
								.findSelectedDateTranieeData(asDate(date), Long.parseLong(traningId));
				        LOGGER.info("attendence list size" + allAttendancesListtemp.size());

						if (allAttendancesListtemp.size() > 0) {
							attendanceRepository.deleteAll(allAttendancesListtemp);
						}

					}
				}

				// new date calculation
				while (noofDyas > tempnoofDyas) {
					LocalDate result = finalEndDate.plusDays(1);
					if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY || result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
						List<LocalDate> list = getOptionalAndHolidayInLocalDates();
						if (!list.contains(result)) {
							newDateNeedtoAaddList.add(result);
							tempnoofDyas++;
						}
					}
					finalEndDate = result;
				}

				if (allAttendancesList.size() == 0) {
					newDateNeedtoAaddList.addAll(traningDatesList);
				}
				finalEndDate = newDateNeedtoAaddList.stream().max(LocalDate::compareTo).get();
				// new record Genration according to new dates
				for (Nomination nominee : listNom) {
					for (LocalDate date : newDateNeedtoAaddList) {
						Attendance attendance = new Attendance();
						attendance.setActualEndDate(asDate(finalEndDate));
						attendance.setActualStartDate(asDate(finalStartDate));
						attendance.setEmp_id(nominee.getEmp_id());
						attendance.setEmp_mail_id(nominee.getEmp_mail_id());
						attendance.setPresentDate(asDate(date));
						attendance.setTraning_id(Long.parseLong(traningId));
						attendance.setTraning_noOfDays(traningnoofDyas);
						attendance.setEmp_name(nominee.getEmp_name());
						attendance.setEmploymentStatus(nominee.getEmployment_status());
				        LOGGER.info("attendence" + attendance);

						attendanceRepository.save(attendance);

					}

				}

				if (finalEndDate != null && finalStartDate != null) {
					// update start and end for All existing record
					attendanceRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
							Long.parseLong(traningId));
					// update start and end for in main table
					trainingRequestRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
							Long.parseLong(traningId));
				}
				// }

			} else {

				if (originalTraningStartDate.isEqual(convertedLeaveStartDate)
						&& orignalTraningEndDate.isEqual(convertedLeaveEndDate)) {
					LocalDate finalStartDate = originalTraningStartDate;
					LocalDate finalEndDate = orignalTraningEndDate;
					Double tempnoofDyas = 0.0;

					if (allAttendancesList.size() > 0) {

						// This is for delete the record which is present in Attendance for Apply leave
						// date
						for (LocalDate date : listDate) {
							List<Attendance> allAttendancesListtemp = attendanceRepository
									.findSelectedDateTranieeData(asDate(date), Long.parseLong(traningId));
							if (allAttendancesListtemp.size() > 0) {
								attendanceRepository.deleteAll(allAttendancesListtemp);
							}

						}
					}

					// new date calculation
					while (noofDyas > tempnoofDyas) {
						LocalDate result = finalEndDate.plusDays(1);
						if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY
								|| result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
							List<LocalDate> list = getOptionalAndHolidayInLocalDates();
							if (!list.contains(result)) {
								newDateNeedtoAaddList.add(result);
								tempnoofDyas++;
							}
						}
						finalEndDate = result;
					}

					finalEndDate = newDateNeedtoAaddList.stream().max(LocalDate::compareTo).get();
					finalStartDate = newDateNeedtoAaddList.stream().min(LocalDate::compareTo).get();

					for (Nomination nominee : listNom) {
						for (LocalDate date : newDateNeedtoAaddList) {
							Attendance attendance = new Attendance();
							attendance.setActualEndDate(asDate(finalEndDate));
							attendance.setActualStartDate(asDate(finalStartDate));
							attendance.setEmp_id(nominee.getEmp_id());
							attendance.setEmp_mail_id(nominee.getEmp_mail_id());
							attendance.setPresentDate(asDate(date));
							attendance.setTraning_id(Long.parseLong(traningId));
							attendance.setTraning_noOfDays(traningnoofDyas);
							attendance.setEmp_name(nominee.getEmp_name());
							attendance.setEmploymentStatus(nominee.getEmployment_status());
							attendanceRepository.save(attendance);

						}

					}

					if (finalEndDate != null && finalStartDate != null) {
						// update start and end for All existing record
						attendanceRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
						// update start and end for in main table
						trainingRequestRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
					}

				} else if (originalTraningStartDate.isBefore(convertedLeaveStartDate)
						&& orignalTraningEndDate.isEqual(convertedLeaveEndDate)) {

					LocalDate finalStartDate = originalTraningStartDate;
					LocalDate finalEndDate = orignalTraningEndDate;
					Double tempnoofDyas = 0.0;

					if (traningDatesList.size() > 0) {
						for (LocalDate date : listDate) {
							if (traningDatesList.contains(date)) {
								traningDatesList.remove(date);
							}
						}

					}

					if (allAttendancesList.size() > 0) {

						// This is for delete the record which is present in Attendance for Apply leave
						// date
						for (LocalDate date : listDate) {
							List<Attendance> allAttendancesListtemp = attendanceRepository
									.findSelectedDateTranieeData(asDate(date), Long.parseLong(traningId));
							if (allAttendancesListtemp.size() > 0) {
								attendanceRepository.deleteAll(allAttendancesListtemp);
							}

						}
					}

					// new date calculation
					while (noofDyas > tempnoofDyas) {
						LocalDate result = finalEndDate.plusDays(1);
						if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY
								|| result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
							List<LocalDate> list = getOptionalAndHolidayInLocalDates();
							if (!list.contains(result)) {
								newDateNeedtoAaddList.add(result);
								tempnoofDyas++;
							}
						}
						finalEndDate = result;
					}

					if (allAttendancesList.size() == 0) {
						newDateNeedtoAaddList.addAll(traningDatesList);
					}

					finalEndDate = newDateNeedtoAaddList.stream().max(LocalDate::compareTo).get();
					// finalStartDate=newDateNeedtoAaddList.stream().min(LocalDate::compareTo).get();

					for (Nomination nominee : listNom) {
						for (LocalDate date : newDateNeedtoAaddList) {
							Attendance attendance = new Attendance();
							attendance.setActualEndDate(asDate(finalEndDate));
							attendance.setActualStartDate(asDate(finalStartDate));
							attendance.setEmp_id(nominee.getEmp_id());
							attendance.setEmp_mail_id(nominee.getEmp_mail_id());
							attendance.setPresentDate(asDate(date));
							attendance.setTraning_id(Long.parseLong(traningId));
							attendance.setTraning_noOfDays(traningnoofDyas);
							attendance.setEmp_name(nominee.getEmp_name());
							attendance.setEmploymentStatus(nominee.getEmployment_status());
							attendanceRepository.save(attendance);

						}

					}

					if (finalEndDate != null && finalStartDate != null) {
						// update start and end for All existing record
						attendanceRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
						// update start and end for in main table
						trainingRequestRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
					}

				} else if (originalTraningStartDate.isAfter(convertedLeaveStartDate)
						&& orignalTraningEndDate.isEqual(convertedLeaveEndDate)) {
					LocalDate finalStartDate = null;
					LocalDate finalEndDate = orignalTraningEndDate;
					Double tempnoofDyas = 0.0;

					if (traningDatesList.size() > 0) {
						for (LocalDate date : listDate) {
							if (traningDatesList.contains(date)) {
								traningDatesList.remove(date);
							}
						}

					}

					if (allAttendancesList.size() > 0) {

						// This is for delete the record which is present in Attendance for Apply leave
						// date
						for (LocalDate date : listDate) {
							List<Attendance> allAttendancesListtemp = attendanceRepository
									.findSelectedDateTranieeData(asDate(date), Long.parseLong(traningId));
							if (allAttendancesListtemp.size() > 0) {
								attendanceRepository.deleteAll(allAttendancesListtemp);
							}

						}
					}

					if (noofDyas > traningnoofDyas) {
						noofDyas = traningnoofDyas;
					}

					// new date calculation
					while (noofDyas > tempnoofDyas) {
						LocalDate result = finalEndDate.plusDays(1);
						if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY
								|| result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
							List<LocalDate> list = getOptionalAndHolidayInLocalDates();
							if (!list.contains(result)) {
								newDateNeedtoAaddList.add(result);
								tempnoofDyas++;
							}
						}
						finalEndDate = result;
					}

					finalEndDate = newDateNeedtoAaddList.stream().max(LocalDate::compareTo).get();
					finalStartDate = newDateNeedtoAaddList.stream().min(LocalDate::compareTo).get();

					for (Nomination nominee : listNom) {
						for (LocalDate date : newDateNeedtoAaddList) {
							Attendance attendance = new Attendance();
							attendance.setActualEndDate(asDate(finalEndDate));
							attendance.setActualStartDate(asDate(finalStartDate));
							attendance.setEmp_id(nominee.getEmp_id());
							attendance.setEmp_mail_id(nominee.getEmp_mail_id());
							attendance.setPresentDate(asDate(date));
							attendance.setTraning_id(Long.parseLong(traningId));
							attendance.setTraning_noOfDays(traningnoofDyas);
							attendance.setEmp_name(nominee.getEmp_name());
							attendance.setEmploymentStatus(nominee.getEmployment_status());
							attendanceRepository.save(attendance);

						}

					}

					if (finalEndDate != null && finalStartDate != null) {
						// update start and end for All existing record
						attendanceRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
						// update start and end for in main table
						trainingRequestRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
					}

				} else if (originalTraningStartDate.isEqual(convertedLeaveStartDate)
						&& orignalTraningEndDate.isAfter(convertedLeaveEndDate)) {
					LocalDate finalStartDate = null;
					LocalDate finalEndDate = orignalTraningEndDate;
					Double tempnoofDyas = 0.0;
					if (traningDatesList.size() > 0) {
						for (LocalDate date : listDate) {
							if (traningDatesList.contains(date)) {
								traningDatesList.remove(date);
								tempnoofDyas++;
							}
						}

					}

					if (traningDatesList.size() > 0 && allAttendancesList.size() == 0) {
						tempnoofDyas = traningnoofDyas;
						finalEndDate = listDate.stream().max(LocalDate::compareTo).get();
						finalStartDate = traningDatesList.stream().min(LocalDate::compareTo).get();
					} else {
						finalStartDate = traningDatesList.stream().min(LocalDate::compareTo).get();
					}

					if (allAttendancesList.size() > 0) {

						// This is for delete the record which is present in Attendance for Apply leave
						// date
						for (LocalDate date : listDate) {
							List<Attendance> allAttendancesListtemp = attendanceRepository
									.findSelectedDateTranieeData(asDate(date), Long.parseLong(traningId));
							
							if (allAttendancesListtemp.size() > 0) {
								attendanceRepository.deleteAll(allAttendancesListtemp);
							}

						}
					}

					if (noofDyas > traningnoofDyas) {
						noofDyas = traningnoofDyas;
					}

					// new date calculation
					while (0 < tempnoofDyas) {
						LocalDate result = finalEndDate.plusDays(1);
						if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY
								|| result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
							List<LocalDate> list = getOptionalAndHolidayInLocalDates();
							if (!list.contains(result)) {
								newDateNeedtoAaddList.add(result);
								tempnoofDyas--;
							}
						}
						finalEndDate = result;
					}

					finalEndDate = newDateNeedtoAaddList.stream().max(LocalDate::compareTo).get();

					for (Nomination nominee : listNom) {
						for (LocalDate date : newDateNeedtoAaddList) {
							Attendance attendance = new Attendance();
							attendance.setActualEndDate(asDate(finalEndDate));
							attendance.setActualStartDate(asDate(finalStartDate));
							attendance.setEmp_id(nominee.getEmp_id());
							attendance.setEmp_mail_id(nominee.getEmp_mail_id());
							attendance.setPresentDate(asDate(date));
							attendance.setTraning_id(Long.parseLong(traningId));
							attendance.setTraning_noOfDays(traningnoofDyas);
							attendance.setEmp_name(nominee.getEmp_name());
							attendance.setEmploymentStatus(nominee.getEmployment_status());
							attendanceRepository.save(attendance);

						}

					}

					if (finalEndDate != null && finalStartDate != null) {
						// update start and end for All existing record
						attendanceRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
						// update start and end for in main table
						trainingRequestRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
					}

				} else if (originalTraningStartDate.isEqual(convertedLeaveStartDate)
						&& orignalTraningEndDate.isBefore(convertedLeaveEndDate)) {
					LocalDate finalStartDate = null;
					LocalDate finalEndDate = convertedLeaveEndDate;
					Double tempnoofDyas = 0.0;
					if (traningDatesList.size() > 0) {
						for (LocalDate date : listDate) {
							if (traningDatesList.contains(date)) {
								traningDatesList.remove(date);
								tempnoofDyas++;
							}
						}

					}

					if (allAttendancesList.size() > 0) {

						// This is for delete the record which is present in Attendance for Apply leave
						// date
						for (LocalDate date : listDate) {
							List<Attendance> allAttendancesListtemp = attendanceRepository
									.findSelectedDateTranieeData(asDate(date), Long.parseLong(traningId));
					        LOGGER.info("List Size" + allAttendancesListtemp.size());

							if (allAttendancesListtemp.size() > 0) {
								attendanceRepository.deleteAll(allAttendancesListtemp);
							}

						}
					}

					// new date calculation
					while (0 < tempnoofDyas) {
						LocalDate result = finalEndDate.plusDays(1);
						if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY
								|| result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
							List<LocalDate> list = getOptionalAndHolidayInLocalDates();
							if (!list.contains(result)) {
								newDateNeedtoAaddList.add(result);
								tempnoofDyas--;
							}
						}
						finalEndDate = result;
					}

					finalEndDate = newDateNeedtoAaddList.stream().max(LocalDate::compareTo).get();
					finalStartDate = newDateNeedtoAaddList.stream().min(LocalDate::compareTo).get();

					for (Nomination nominee : listNom) {
						for (LocalDate date : newDateNeedtoAaddList) {
							Attendance attendance = new Attendance();
							attendance.setActualEndDate(asDate(finalEndDate));
							attendance.setActualStartDate(asDate(finalStartDate));
							attendance.setEmp_id(nominee.getEmp_id());
							attendance.setEmp_mail_id(nominee.getEmp_mail_id());
							attendance.setPresentDate(asDate(date));
							attendance.setTraning_id(Long.parseLong(traningId));
							attendance.setTraning_noOfDays(traningnoofDyas);
							attendance.setEmp_name(nominee.getEmp_name());
							attendance.setEmploymentStatus(nominee.getEmployment_status());
							attendanceRepository.save(attendance);

						}

					}

					if (finalEndDate != null && finalStartDate != null) {
						// update start and end for All existing record
						attendanceRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
						// update start and end for in main table
						trainingRequestRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
					}

				} else if (originalTraningStartDate.isBefore(convertedLeaveStartDate)
						&& orignalTraningEndDate.isBefore(convertedLeaveEndDate)) {
					LocalDate finalStartDate = originalTraningStartDate;
					LocalDate finalEndDate = convertedLeaveEndDate;
					Double tempnoofDyas = 0.0;
					if (traningDatesList.size() > 0) {
						for (LocalDate date : listDate) {
							if (traningDatesList.contains(date)) {
								traningDatesList.remove(date);
								tempnoofDyas++;
							}
						}

					}

					if (allAttendancesList.size() > 0) {

						// This is for delete the record which is present in Attendance for Apply leave
						// date
						for (LocalDate date : listDate) {
							List<Attendance> allAttendancesListtemp = attendanceRepository
									.findSelectedDateTranieeData(asDate(date), Long.parseLong(traningId));
							if (allAttendancesListtemp.size() > 0) {
								attendanceRepository.deleteAll(allAttendancesListtemp);
							}

						}
					}

					// new date calculation
					while (0 < tempnoofDyas) {
						LocalDate result = finalEndDate.plusDays(1);
						if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY
								|| result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
							List<LocalDate> list = getOptionalAndHolidayInLocalDates();
							if (!list.contains(result)) {
								newDateNeedtoAaddList.add(result);
								tempnoofDyas--;
							}
						}
						finalEndDate = result;
					}

					finalEndDate = newDateNeedtoAaddList.stream().max(LocalDate::compareTo).get();
					// finalStartDate=newDateNeedtoAaddList.stream().min(LocalDate::compareTo).get();

					for (Nomination nominee : listNom) {
						for (LocalDate date : newDateNeedtoAaddList) {
							Attendance attendance = new Attendance();
							attendance.setActualEndDate(asDate(finalEndDate));
							attendance.setActualStartDate(asDate(finalStartDate));
							attendance.setEmp_id(nominee.getEmp_id());
							attendance.setEmp_mail_id(nominee.getEmp_mail_id());
							attendance.setPresentDate(asDate(date));
							attendance.setTraning_id(Long.parseLong(traningId));
							attendance.setTraning_noOfDays(traningnoofDyas);
							attendance.setEmp_name(nominee.getEmp_name());
							attendance.setEmploymentStatus(nominee.getEmployment_status());
							attendanceRepository.save(attendance);

						}

					}

					if (finalEndDate != null && finalStartDate != null) {
						// update start and end for All existing record
						attendanceRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
						// update start and end for in main table
						trainingRequestRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
					}

				} else if (originalTraningStartDate.isBefore(convertedLeaveStartDate)
						&& orignalTraningEndDate.isAfter(convertedLeaveEndDate)) {
					LocalDate finalStartDate = originalTraningStartDate;
					LocalDate finalEndDate = orignalTraningEndDate;
					Double tempnoofDyas = 0.0;
					if (traningDatesList.size() > 0) {
						for (LocalDate date : listDate) {
							if (traningDatesList.contains(date)) {
								traningDatesList.remove(date);
								tempnoofDyas++;
							}
						}

					}

					if (allAttendancesList.size() > 0) {

						// This is for delete the record which is present in Attendance for Apply leave
						// date
						for (LocalDate date : listDate) {
							List<Attendance> allAttendancesListtemp = attendanceRepository
									.findSelectedDateTranieeData(asDate(date), Long.parseLong(traningId));
							LOGGER.info("attendance size",allAttendancesListtemp.size());
							if (allAttendancesListtemp.size() > 0) {
								attendanceRepository.deleteAll(allAttendancesListtemp);
							}

						}
					}

					// new date calculation
					while (0 < tempnoofDyas) {
						LocalDate result = finalEndDate.plusDays(1);
						if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY
								|| result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
							List<LocalDate> list = getOptionalAndHolidayInLocalDates();
							if (!list.contains(result)) {
								newDateNeedtoAaddList.add(result);
								tempnoofDyas--;
							}
						}
						finalEndDate = result;
					}

					finalEndDate = newDateNeedtoAaddList.stream().max(LocalDate::compareTo).get();
					if (allAttendancesList.size() == 0) {
						newDateNeedtoAaddList.addAll(traningDatesList);
					}
					// finalStartDate=newDateNeedtoAaddList.stream().min(LocalDate::compareTo).get();

					for (Nomination nominee : listNom) {
						for (LocalDate date : newDateNeedtoAaddList) {
							Attendance attendance = new Attendance();
							attendance.setActualEndDate(asDate(finalEndDate));
							attendance.setActualStartDate(asDate(finalStartDate));
							attendance.setEmp_id(nominee.getEmp_id());
							attendance.setEmp_mail_id(nominee.getEmp_mail_id());
							attendance.setPresentDate(asDate(date));
							attendance.setTraning_id(Long.parseLong(traningId));
							attendance.setTraning_noOfDays(traningnoofDyas);
							attendance.setEmp_name(nominee.getEmp_name());
							LOGGER.info("attendance",attendance);
							attendance.setEmploymentStatus(nominee.getEmployment_status());
							attendanceRepository.save(attendance);

						}

					}

					if (finalEndDate != null && finalStartDate != null) {
						// update start and end for All existing record
						attendanceRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
						// update start and end for in main table
						trainingRequestRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
					}

				} else if (originalTraningStartDate.isAfter(convertedLeaveStartDate)
						&& orignalTraningEndDate.isAfter(convertedLeaveEndDate)) {

					LocalDate finalStartDate = null;
					LocalDate finalEndDate = orignalTraningEndDate;
					Double tempnoofDyas = 0.0;
					if (traningDatesList.size() > 0) {
						for (LocalDate date : listDate) {
							if (traningDatesList.contains(date)) {
								traningDatesList.remove(date);
								tempnoofDyas++;
							}
						}

					}

					if (allAttendancesList.size() > 0) {

						// This is for delete the record which is present in Attendance for Apply leave
						// date
						for (LocalDate date : listDate) {
							List<Attendance> allAttendancesListtemp = attendanceRepository
									.findSelectedDateTranieeData(asDate(date), Long.parseLong(traningId));
							if (allAttendancesListtemp.size() > 0) {
								attendanceRepository.deleteAll(allAttendancesListtemp);
							}

						}
					}

					// new date calculation
					while (0 < tempnoofDyas) {
						LocalDate result = finalEndDate.plusDays(1);
						if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY
								|| result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
							List<LocalDate> list = getOptionalAndHolidayInLocalDates();
							if (!list.contains(result)) {
								newDateNeedtoAaddList.add(result);
								tempnoofDyas--;
							}
						}
						finalEndDate = result;
					}

					finalEndDate = newDateNeedtoAaddList.stream().max(LocalDate::compareTo).get();
					if (allAttendancesList.size() == 0) {
						newDateNeedtoAaddList.addAll(traningDatesList);
					}
					finalStartDate = traningDatesList.stream().min(LocalDate::compareTo).get();

					for (Nomination nominee : listNom) {
						for (LocalDate date : newDateNeedtoAaddList) {
							Attendance attendance = new Attendance();
							attendance.setActualEndDate(asDate(finalEndDate));
							attendance.setActualStartDate(asDate(finalStartDate));
							attendance.setEmp_id(nominee.getEmp_id());
							attendance.setEmp_mail_id(nominee.getEmp_mail_id());
							attendance.setPresentDate(asDate(date));
							attendance.setTraning_id(Long.parseLong(traningId));
							attendance.setTraning_noOfDays(traningnoofDyas);
							attendance.setEmp_name(nominee.getEmp_name());
							attendance.setEmploymentStatus(nominee.getEmployment_status());
							attendanceRepository.save(attendance);

						}

					}

					if (finalEndDate != null && finalStartDate != null) {
						// update start and end for All existing record
						attendanceRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
						// update start and end for in main table
						trainingRequestRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
					}

				} else if (originalTraningStartDate.isAfter(convertedLeaveStartDate)
						&& orignalTraningEndDate.isBefore(convertedLeaveEndDate)) {

					LocalDate finalStartDate = convertedLeaveEndDate;
					LocalDate finalEndDate = convertedLeaveEndDate;
					Double tempnoofDyas = 0.0;
					if (traningDatesList.size() > 0) {
						for (LocalDate date : listDate) {
							if (traningDatesList.contains(date)) {
								traningDatesList.remove(date);
								tempnoofDyas++;
							}
						}

					}

					if (allAttendancesList.size() > 0) {

						// This is for delete the record which is present in Attendance for Apply leave
						// date
						for (LocalDate date : listDate) {
							List<Attendance> allAttendancesListtemp = attendanceRepository
									.findSelectedDateTranieeData(asDate(date), Long.parseLong(traningId));
							if (allAttendancesListtemp.size() > 0) {
								attendanceRepository.deleteAll(allAttendancesListtemp);
							}

						}
					}

					// new date calculation
					while (0 < tempnoofDyas) {
						LocalDate result = finalEndDate.plusDays(1);
						if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY
								|| result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
							List<LocalDate> list = getOptionalAndHolidayInLocalDates();
							if (!list.contains(result)) {
								newDateNeedtoAaddList.add(result);
								tempnoofDyas--;
							}
						}
						finalEndDate = result;
					}
					finalStartDate = newDateNeedtoAaddList.stream().min(LocalDate::compareTo).get();
					finalEndDate = newDateNeedtoAaddList.stream().max(LocalDate::compareTo).get();
					if (allAttendancesList.size() == 0) {
						newDateNeedtoAaddList.addAll(traningDatesList);
					}
					// finalStartDate=traningDatesList.stream().min(LocalDate::compareTo).get();

					for (Nomination nominee : listNom) {
						for (LocalDate date : newDateNeedtoAaddList) {
							Attendance attendance = new Attendance();
							attendance.setActualEndDate(asDate(finalEndDate));
							attendance.setActualStartDate(asDate(finalStartDate));
							attendance.setEmp_id(nominee.getEmp_id());
							attendance.setEmp_mail_id(nominee.getEmp_mail_id());
							attendance.setPresentDate(asDate(date));
							attendance.setTraning_id(Long.parseLong(traningId));
							attendance.setTraning_noOfDays(traningnoofDyas);
							attendance.setEmp_name(nominee.getEmp_name());
							attendance.setEmploymentStatus(nominee.getEmployment_status());
							attendanceRepository.save(attendance);

						}

					}

					if (finalEndDate != null && finalStartDate != null) {
						// update start and end for All existing record
						attendanceRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
						// update start and end for in main table
						trainingRequestRepository.updateActualStartEndDate(asDate(finalEndDate), asDate(finalStartDate),
								Long.parseLong(traningId));
					}

				}

			}

		}

		ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();

		responseWrapperDto.setMessage("Successfully updated");

		return new ResponseEntity<ResponseWrapperDto>(responseWrapperDto, HttpStatus.OK);
	}

	@GetMapping("/optionalHolidayList")
	public ResponseEntity<Object> getOpionalHolidayList() {
		return new ResponseEntity<>(getOptionalAndHolidayDates(), HttpStatus.OK);
	}
	
	@GetMapping("/attendViewData/{traningId}/{empId}")
	public ResponseEntity<List<EmployeeAbsentDateAndReason>> getAttendanceTableDataByEmployeeId(
			@PathVariable long traningId, @PathVariable String empId) {

		List<EmployeeAbsentDateAndReason> list = new ArrayList<>();
		List<Attendance> attdenceData = attendanceRepository.findTranieeAttendanceData(traningId, empId);

		for (Attendance attendance : attdenceData) {

			if (!attendance.isAttendance_status()) {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				Date currentDate = new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000L);

				if (attendance.getPresentDate().before(currentDate)) {
					EmployeeAbsentDateAndReason employeeAbsentDateAndReason = new EmployeeAbsentDateAndReason(
							sdf.format(attendance.getPresentDate()), attendance.getReasonForLeave());
					list.add(employeeAbsentDateAndReason);
				}

				Calendar cal1 = Calendar.getInstance();
				Calendar cal2 = Calendar.getInstance();
				cal1.setTime(attendance.getPresentDate());
				cal2.setTime(new Date());
				boolean sameDay = cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR)
						&& cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);

				if (sameDay && attendance.getAttend_noOfDays() != null) {
					EmployeeAbsentDateAndReason employeeAbsentDateAndReason = new EmployeeAbsentDateAndReason(
							sdf.format(attendance.getPresentDate()), attendance.getReasonForLeave());
					list.add(employeeAbsentDateAndReason);
				}

			}

		}
		return new ResponseEntity<>(list, HttpStatus.OK);
	}

	@Getter
	@AllArgsConstructor
	@NoArgsConstructor
	class EmployeeAbsentDateAndReason {
		private String absentDate;
		private String leaveReason;

	}

	@GetMapping("/attendViewData/{traningId}")
	public ResponseEntity<HashedMap<String, Object>> getAttendanceTableData(@PathVariable String traningId) {
		List<HashedMap<String, Object>> finalList = new ArrayList<>();
		List<Nomination> list = nominationRepository.findAllByTrainingId(Long.parseLong(traningId));
		HashedMap<String, Object> finalMap = new HashedMap<>();
		
		

		List<Attendance> allAttendancesList = attendanceRepository.findTrainingDeatils(Long.parseLong(traningId));
		List<Date> listOfMarkAttendance = new ArrayList<>();
		for (Attendance attendance : allAttendancesList) {

			if (attendance.isAttendance_status() && !listOfMarkAttendance.contains(attendance.getPresentDate())) {
				listOfMarkAttendance.add(attendance.getPresentDate());
			}
		}

		int days = listOfMarkAttendance.size();
		
		
		for (Nomination templist : list) {
			HashedMap<String, Object> tempMap = new HashedMap<>();
			List<Attendance> attdenceData = attendanceRepository.findTranieeAttendanceData(templist.getTrainingId(),
					templist.getEmp_id());
			double pertange = 0;
			double numOfdaysAttend = 0;
			double noOfDaystraning = 0;
			StringBuffer datesAttended = new StringBuffer();
			Attendance attendanceObj = new Attendance();
			for (Attendance attendance : attdenceData) {
				noOfDaystraning = attendance.getTraning_noOfDays();
				if (attendance.isAttendance_status()) {
					numOfdaysAttend = numOfdaysAttend + 1;
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					datesAttended.append((sdf.format(attendance.getPresentDate())).toString() + ",");
				}
				attendanceObj.setActualEndDate(attendance.getActualEndDate());
				attendanceObj.setActualStartDate(attendance.getActualStartDate());
				attendanceObj.setTraning_noOfDays(attendance.getTraning_noOfDays());
			}
			pertange = 100 * numOfdaysAttend / days;
			attendanceObj.setEmp_id(templist.getEmp_id());
			attendanceObj.setEmp_mail_id(templist.getEmp_mail_id());
			attendanceObj.setEmp_name(templist.getEmp_name());
			attendanceObj.setAttendance_percentage(round(pertange, 2));
			attendanceObj.setAttend_noOfDays(numOfdaysAttend);
			tempMap.put("attendeace", attendanceObj);
			tempMap.put("datesAttended", datesAttended);
			// finalMap.put("value", tempMap);
			finalList.add(tempMap);
		}
		finalMap.put("value", finalList);

		return new ResponseEntity<>(finalMap, HttpStatus.OK);
	}

	@GetMapping("/getAllAttendanceDateData/{traningId}")
	public ResponseEntity<Object> getAllAttendanceDateData(@PathVariable String traningId) {
		List<Attendance> result = attendanceRepository.findTrainingDeatils(Long.parseLong(traningId));
		return new ResponseEntity<>(result, HttpStatus.OK);
	}

	@GetMapping("/getStarAndEndDateData/{traningId}")
	public ResponseEntity<Object> getStarAndEndDateData(@PathVariable String traningId) {
		TrainingRequestFormDto tr = traningRequestService.getTrainingRequestFormById(Long.parseLong(traningId));
		List<Attendance> allAttendancesList = attendanceRepository.findTrainingDeatils(Long.parseLong(traningId));
		List<Date> listOfMarkAttendance = new ArrayList<>();
		List<String> resultListOfMarkAttendance = new ArrayList<>();
		for (Attendance attendance : allAttendancesList) {

			if (attendance.isAttendance_status() && !listOfMarkAttendance.contains(attendance.getPresentDate())) {
				// LocalDate convertedDate=
				// AttendanceController.convert(attendance.getPresentDate());
				listOfMarkAttendance.add(attendance.getPresentDate());
			}
		}

		for (Date date : listOfMarkAttendance) {
			LocalDate convertedDate = AttendanceController.convert(date);
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			resultListOfMarkAttendance.add((sdf.format(date)).toString());
			// resultListOfMarkAttendance.add(convertedDate.format(DateTimeFormatter.ofPattern("yyyy-dd-mm")));

		}

		List<TrainerAttedance> trainerAttedanceList = trainerAttendanceRepository
				.findTranierAttendanceDeatils(Long.parseLong(traningId));
		Set<String> finalStringDateList = new HashSet<>();
		for (TrainerAttedance trainerAttedance : trainerAttedanceList) {

			
			
			
			List<TrainerAttedanceDate> listed = trainerAttedance.getTrainerAttendanceDates();

			for (TrainerAttedanceDate trainerAttedanceDate : listed) {
			   String leaveStatus=trainerAttedanceDate.getTrainerAttedance().getLeave_status();
			   if("APPROVED".equalsIgnoreCase(leaveStatus)) {
				LocalDate result = convert(trainerAttedanceDate.getAttendance_date());
				String date = result.format(DateTimeFormatter.ISO_LOCAL_DATE);
				finalStringDateList.add(date);
			   }
			}

		}

		Date startDate = tr.getActualStartDate();
		Date endDate = tr.getActualEndDate();
		LocalDate convertedStartDate = AttendanceController.convert(startDate);
		LocalDate convertedEnddate = AttendanceController.convert(endDate);
		List<String> finalResult = new ArrayList<>();
		finalResult.add(convertedStartDate.format(DateTimeFormatter.ISO_LOCAL_DATE));
		finalResult.add(convertedEnddate.format(DateTimeFormatter.ISO_LOCAL_DATE));
		HashedMap<String, Object> map = new HashedMap<>();
		map.put("starendDate", finalResult);
		map.put("optionalHoliday", getOptionalAndHolidayDates());
		map.put("listOfMarkAttendanceDate", resultListOfMarkAttendance);
		map.put("trainerAbsentDates", finalStringDateList);
		return new ResponseEntity<>(map, HttpStatus.OK);
	}

	@GetMapping("/attendsDatesList/{traningId}")
	public ResponseEntity<Object> getAttendanceDateData(@PathVariable String traningId) {

		TrainingRequestFormDto tr = traningRequestService.getTrainingRequestFormById(Long.parseLong(traningId));
		List<Nomination> list = nominationRepository.findAllByTrainingId(Long.parseLong(traningId));

		Date startDate = tr.getActualStartDate();
		Date endDate = tr.getActualEndDate();
		LocalDate convertedStartDate = AttendanceController.convert(startDate);
		LocalDate convertedEnddate = AttendanceController.convert(endDate);

		HashedMap<String, Object> map = 
				addDaysSkippingWeekendsAndOptionalHoliday(convertedStartDate, convertedEnddate, 0);
		List<String> listDate = (List<String>) map.get("attendsDateListInStringFormat");
		List<String> finalResult = new ArrayList<>();
		List<String> listofHoliday = getOptionalAndHolidayDates();
		List<String> temp = new ArrayList<>();

		for (String date : listDate) {

			for (String hdate : listofHoliday) {

				if (!date.equals(hdate) && !temp.contains(date) && !listofHoliday.contains(date)) {
					// finalResult.add(date);
					temp.add(date);
				}

			}
		}

		for (String date : temp) {
			finalResult.add(date);
		}

		return new ResponseEntity<>(finalResult, HttpStatus.OK);
	}

	@GetMapping("/selectedDateTranieeData/{selectDate}/{tarningId}")
	public ResponseEntity<Object> getSelectedDateData(@PathVariable String selectDate, @PathVariable String tarningId) throws ParseException {
		//LocalDate date = LocalDate.parse(selectDate);
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date1 = formatter.parse(selectDate);
		List<Attendance> allAttendancesList = attendanceRepository.findTrainingDeatils(Long.parseLong(tarningId));
		List<Attendance> finalArryList =new ArrayList<>();
		for(Attendance at:allAttendancesList) {
			 Date d=at.getPresentDate();
			 if(d.getMonth()==date1.getMonth() && d.getDate()==date1.getDate() && d.getDay()==date1.getDay() && d.getYear()==date1.getYear() ) {
				 finalArryList.add(at);
				 }
		}
		//attendanceRepository.findSelectedDateTranieeData(date1, Long.parseLong(tarningId))
		return new ResponseEntity<>(
				finalArryList, HttpStatus.OK);

	}

	@PutMapping("/add-Attendance")
	public ResponseEntity<ResponseWrapperDto> saveAttendace(@RequestBody List<Attendance> data) {
		LOGGER.info("add-Attendance",data);
		for (Attendance tempData : data) {
			Attendance temp = attendanceRepository.getById(tempData.getId());
			Attendance attend = new Attendance();
			attend.setId(temp.getId());
			attend.setPresentDate(temp.getPresentDate());
			attend.setActualEndDate(temp.getActualEndDate());
			attend.setActualStartDate(temp.getActualStartDate());
			attend.setEmp_id(temp.getEmp_id());
			attend.setEmp_mail_id(temp.getEmp_mail_id());
			attend.setTraning_id(temp.getTraning_id());
			attend.setTraning_noOfDays(temp.getTraning_noOfDays());
			attend.setEmp_name(temp.getEmp_name());
			attend.setReasonForLeave(tempData.getReasonForLeave());
			// attend.setAttendance_percentage(temp.get)
			attend.setAttendance_status(tempData.isAttendance_status());
			attend.setEmploymentStatus(temp.getEmploymentStatus());
			double pertange = 0;
			double numOfdaysAttend = 0;

			if (tempData.isAttendance_status()) {
				numOfdaysAttend++;
			} else {
				numOfdaysAttend--;
			}

			List<Attendance> attdenceData = attendanceRepository.findTranieeAttendanceData(temp.getTraning_id(),
					temp.getEmp_id());
			for (Attendance attendData : attdenceData) {

				if (attendData.isAttendance_status()) {
					numOfdaysAttend++;
				}
			}

			if (numOfdaysAttend > 0) {
				pertange = 100 * numOfdaysAttend / tempData.getTraning_noOfDays();
				attend.setAttend_noOfDays(numOfdaysAttend);
			} else {
				attend.setAttend_noOfDays(0.0);
			}

			attend.setAttendance_percentage(pertange);

			attendanceRepository.save(attend);
			// attendanceRepository.save(tempData);
		}
		ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();
		responseWrapperDto.setMessage("Success");
		return new ResponseEntity<>(responseWrapperDto, HttpStatus.OK);
	}

	@PostMapping("/create/{traningId}")
	public ResponseEntity<ResponseWrapperDto> createAttendanceTableData(@PathVariable String traningId) {

		ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();

		TrainingRequestFormDto tr = traningRequestService.getTrainingRequestFormById(Long.parseLong(traningId));
		List<Nomination> list = nominationRepository.findAllByTrainingId(Long.parseLong(traningId));

		Date startDate = tr.getActualStartDate();
		Date endDate = tr.getActualEndDate();
		LocalDate convertedStartdate = AttendanceController.convert(startDate);
		LocalDate covertedEnddate = AttendanceController.convert(endDate);
		List<TrainerAttedance> trainerAttedanceList = trainerAttendanceRepository
				.findTranierAttendanceDeatils(Long.parseLong(traningId));
		HashedMap<String, Object> map = 
				addDaysSkippingWeekendsAndOptionalHoliday(convertedStartdate, covertedEnddate, 0);
		List<LocalDate> listDate = (List<LocalDate>) map.get("attendsDateDateListInLocalDateFormat");
		Double noofDyas = (Double) map.get("noOfdays");

		LocalDate maxDate = listDate.stream().max(LocalDate::compareTo).get();
		Double noofDyasNeedtoAdd = 0.0;
		if (trainerAttedanceList.size() > 0 && listDate.size() > 0) {

			for (TrainerAttedance trainerAttedance : trainerAttedanceList) {
				List<TrainerAttedanceDate> listed = trainerAttedance.getTrainerAttendanceDates();
				for (TrainerAttedanceDate trainerAttedanceDate : listed) {
					LocalDate date = convert(trainerAttedanceDate.getAttendance_date());
					if (listDate.contains(date)) {

						listDate.remove(date);
						noofDyasNeedtoAdd++;
					}
				}
				
			}

			while (noofDyasNeedtoAdd > 0) {

				LocalDate result = maxDate.plusDays(1);
				if (checkDaysComeInWeekendsAndOptionalHoliday(result)) {
					listDate.add(result);
					noofDyasNeedtoAdd--;
				}
				maxDate = result;

			}

			LocalDate fEndDate = listDate.stream().max(LocalDate::compareTo).get();
			LocalDate fstartDate = listDate.stream().min(LocalDate::compareTo).get();
			endDate = asDate(fEndDate);
			startDate = asDate(fstartDate);
		}

		for (Nomination nominee : list) {

			for (LocalDate date : listDate) {
				Attendance attendance = new Attendance();
				attendance.setActualEndDate(endDate);
				attendance.setActualStartDate(startDate);
				attendance.setEmp_id(nominee.getEmp_id());
				attendance.setEmp_mail_id(nominee.getEmp_mail_id());
				attendance.setPresentDate(asDate(date));
				attendance.setTraning_id(Long.parseLong(traningId));
				attendance.setTraning_noOfDays(noofDyas);
				attendance.setEmp_name(nominee.getEmp_name());
				attendance.setEmploymentStatus(nominee.getEmployment_status());
				attendanceRepository.save(attendance);

			}
		}

		if (trainerAttedanceList.size() > 0) {
			trainingRequestRepository.updateActualStartEndDate(endDate, startDate, Long.parseLong(traningId));
		}

		responseWrapperDto.setMessage("Data Submit Successfully!!!!!");

		return new ResponseEntity<ResponseWrapperDto>(responseWrapperDto, HttpStatus.OK);
	}

	public  boolean checkDaysComeInWeekendsAndOptionalHoliday(LocalDate stardate) {
		LocalDate result = stardate;
		boolean fResult = false;
		if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY || result.getDayOfWeek() == DayOfWeek.SUNDAY)) {
			List<LocalDate> list = getOptionalAndHolidayInLocalDates();
			if (!list.contains(result)) {
				fResult = true;
			}
		}
		return fResult;
	}

	public  HashedMap<String, Object> addDaysSkippingWeekendsAndOptionalHoliday(LocalDate stardate,
			LocalDate enddate, int days) {
		LocalDate result = stardate;
		int addedDays = 0;
		HashedMap<String, Object> dateMap = new HashedMap<>();
		List<LocalDate> finalLocalDateList = new ArrayList<>();
		List<String> finalStringDateList = new ArrayList<>();
		while (!result.isAfter(enddate)) {

			if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY || result.getDayOfWeek() == DayOfWeek.SUNDAY)) {

				List<LocalDate> list = getOptionalAndHolidayInLocalDates();

				if (!list.contains(result)) {
					++addedDays;
					finalLocalDateList.add(result);
					finalStringDateList.add(result.format(DateTimeFormatter.ISO_LOCAL_DATE));
				}

			}

			result = result.plusDays(1);
		}

		dateMap.put("noOfdays", Double.valueOf(addedDays));
		dateMap.put("attendsDateDateListInLocalDateFormat", finalLocalDateList);
		dateMap.put("attendsDateListInStringFormat", finalStringDateList);

		return dateMap;
	}

	public static HashedMap<String, Object> addDaysSkippingWeekends(LocalDate stardate, LocalDate enddate, int days) {
		LocalDate result = stardate;
		int addedDays = 0;
		HashedMap<String, Object> dateMap = new HashedMap<>();
		List<LocalDate> finalLocalDateList = new ArrayList<>();
		List<String> finalStringDateList = new ArrayList<>();
		while (!result.isAfter(enddate)) {

			if (!(result.getDayOfWeek() == DayOfWeek.SATURDAY || result.getDayOfWeek() == DayOfWeek.SUNDAY)) {

				++addedDays;
				finalLocalDateList.add(result);
				finalStringDateList.add(result.format(DateTimeFormatter.ISO_LOCAL_DATE));

			}

			result = result.plusDays(1);
		}

		dateMap.put("noOfdays", Double.valueOf(addedDays));
		dateMap.put("attendsDateDateListInLocalDateFormat", finalLocalDateList);
		dateMap.put("attendsDateListInStringFormat", finalStringDateList);

		return dateMap;
	}

	@PostMapping("/attendanceDownload/{traningId}")
	public void download(HttpServletResponse response, @PathVariable String traningId)
			throws DecoderException, ParseException {

		try {
			TrainingRequestFormDto tr = traningRequestService.getTrainingRequestFormById(Long.parseLong(traningId));
			Date startDate = tr.getActualStartDate();
			Date endDate = tr.getActualEndDate();
			LocalDate convertedStartDate = AttendanceController.convert(startDate);
			LocalDate convertedEnddate = AttendanceController.convert(endDate);
			List<Date> listOfMarkAttendance = new ArrayList<>();
			HashedMap<String, Object> map = AttendanceController.addDaysSkippingWeekends(convertedStartDate,
					convertedEnddate, 0);
			List<String> listDate = (List<String>) map.get("attendsDateListInStringFormat");
			List<String> listOptinalHoliday = getOptionalAndHolidayDates();
			List<String> listTraninerLeave = new ArrayList<>();
			List<String> optinalHoliday = new ArrayList<>();
			List<TrainerAttedance> trainerAttedanceList = trainerAttendanceRepository
					.findTranierAttendanceDeatils(Long.parseLong(traningId));
			if (trainerAttedanceList.size() > 0) {

				for (TrainerAttedance trainerAttedance : trainerAttedanceList) {
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
					
					List<TrainerAttedanceDate> listed = trainerAttedance.getTrainerAttendanceDates();
					for (TrainerAttedanceDate trainerAttedanceDate : listed) {
						String formatDate = formatter.format(trainerAttedanceDate.getAttendance_date());
						if (listDate.contains(formatDate)) {
							listTraninerLeave.add(formatDate);
							// listDate.remove(formatDate);

						}
					}
					
				

				}
			}

			for (String date : listDate) {
				if (listOptinalHoliday.contains(date)) {
					optinalHoliday.add(date);
				}
			}

			List<Nomination> list = nominationRepository.findAllByTrainingId(Long.parseLong(traningId));
			HashedMap<String, HashedMap<String, String>> fMap = new HashedMap<>();
			Map<String, HashedMap<String, String>> sortedMap = new TreeMap<>();
			ConcurrentHashMap<String, Integer> finalPresentCountMap = new ConcurrentHashMap<>();
			ConcurrentHashMap<String, Integer> finalTraineePresentCountMap = new ConcurrentHashMap<>();
			for (Nomination templist : list) {
				HashedMap<String, String> tempMap = new HashedMap<>();
				tempMap.put("empId", templist.getEmp_id());
				tempMap.put("empMail", templist.getEmp_mail_id());
				tempMap.put("empName", templist.getEmp_name());
				List<Attendance> attdenceData = attendanceRepository.findTranieeAttendanceData(templist.getTrainingId(),
						templist.getEmp_id());
				for (Attendance attendance : attdenceData) {
					finalTraineePresentCountMap.put("traning_noOfDays",
							(int) Math.round(attendance.getTraning_noOfDays()));

					if (attendance.isAttendance_status()
							&& !listOfMarkAttendance.contains(attendance.getPresentDate())) {
						// LocalDate convertedDate=
						// AttendanceController.convert(attendance.getPresentDate());
						listOfMarkAttendance.add(attendance.getPresentDate());
					}

					Date d = attendance.getPresentDate();
					// Date date = new Date();
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					LocalDate ldate = LocalDate.from(d.toInstant().atZone(ZoneOffset.UTC));
					String s = (sdf.format(d)).toString();
					if (listDate.contains(s)) {
						for (String date : listDate) {
							if (date.equalsIgnoreCase(s)) {
								
								if(!attendance.getEmploymentStatus().equalsIgnoreCase("Active")) {
									tempMap.put(date,attendance.isAttendance_status() ? "Present" : "Absent"+"_"+attendance.getEmploymentStatus() );
								}
								else {
									tempMap.put(date, attendance.isAttendance_status() ? "Present" : "Absent");	
								}
								
								if (attendance.isAttendance_status()) {

									if (finalTraineePresentCountMap.containsKey(attendance.getEmp_id())) {
										Integer val = finalTraineePresentCountMap.get(attendance.getEmp_id());
										finalTraineePresentCountMap.put(attendance.getEmp_id(), val + 1);

									} else {
										finalTraineePresentCountMap.put(attendance.getEmp_id(), 1);
									}

									if (finalPresentCountMap.containsKey(date)) {
										Integer val = finalPresentCountMap.get(date);
										finalPresentCountMap.put(s, val + 1);

									} else {
										finalPresentCountMap.put(s, 1);
									}

								}

							}

						}
					}

					if (listTraninerLeave.size() > 0) {
						for (String leaveDate : listTraninerLeave) {
							tempMap.put(leaveDate, "Traniner On leave");
						}

					}

					if (optinalHoliday.size() > 0) {
						for (String optionalDate : optinalHoliday) {
							tempMap.put(optionalDate, "Optional/Holiday");
						}
					}

				}

				fMap.put(templist.getEmp_id(), tempMap);

			}

			String fileName = "Attendance_Report_";

			response.setContentType("application/octet-stream");
			DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
			String currentDateTime = dateFormatter.format(new Date());

			String headerKey = "Content-Disposition";
			String headerValue = "attachment; filename=" + fileName + tr.getId() + "_" + tr.getTrainingName() + "_"
					+ currentDateTime + ".xlsx";
			response.setHeader(headerKey, headerValue);

			// workbook object
			XSSFWorkbook workbook = new XSSFWorkbook();

			// spreadsheet object
			XSSFSheet spreadsheet = workbook.createSheet("Sheet1");
			spreadsheet.createFreezePane(7, 0, 7, 0);
			// creating a row object
			XSSFRow row;

			int rowid = 1;
			int cellid = 0; // writing the data into the sheets...
			List<String> headers = new ArrayList();
			headers.add("Sr.No");
			headers.add("Employee ID");
			headers.add("Employee Email");
			headers.add("Employee Name");
			headers.add("Total Traning days");
			headers.add("Attended days");
			headers.add("Percentage");
			spreadsheet.setColumnWidth(1, 25 * 150);
			spreadsheet.setColumnWidth(2, 25 * 256);
			spreadsheet.setColumnWidth(3, 25 * 256);
			spreadsheet.setColumnWidth(4, 25 * 150);
			spreadsheet.setColumnWidth(5, 25 * 150);
			spreadsheet.setColumnWidth(6, 25 * 150);
			spreadsheet.setColumnWidth(7, 25 * 256);
			int col = 8;
			for (String date : listDate) {
				String[] tokens = date.split("-");
				DateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
				 Date sdate = inputFormat.parse(date);

		            // Create a date formatter with the desired output format including month name
		            DateFormat outputFormat = new SimpleDateFormat("dd-MMMM-yyyy", Locale.ENGLISH);

		            // Format the Date object into the desired format
		            String newFormat = outputFormat.format(sdate);
				headers.add(newFormat);
				spreadsheet.setColumnWidth(col, 25 * 200);
				col++;
			}

			row = spreadsheet.createRow(0);
			XSSFCellStyle style = workbook.createCellStyle();
			XSSFFont font = workbook.createFont();
			font.setFontName(HSSFFont.FONT_ARIAL);
			font.setFontHeightInPoints((short) 10);
			font.setBold(true);
			style.setFont(font);
			style.setAlignment(HorizontalAlignment.CENTER);

			for (int rn = 0; rn < headers.size(); rn++) {
				XSSFCell cell = row.createCell(rn);
				cell.setCellValue(headers.get(rn));
				cell.setCellStyle(style);

			}
			int srno = 1;
			HashedMap<String, HashedMap<String, String>> fCountMap = new HashedMap<>();
			sortedMap.putAll(fMap);
			for (Entry<String, HashedMap<String, String>> entry : sortedMap.entrySet()) {
				row = spreadsheet.createRow(rowid++);
				HashedMap<String, String> obj = entry.getValue();
				row.createCell(0).setCellValue(srno);
				int colno = 7;
				XSSFCellStyle stylecol = workbook.createCellStyle();
				stylecol.setAlignment(HorizontalAlignment.CENTER);
				for (Entry<String, String> entryTemp : obj.entrySet()) {

					if ("empId".equalsIgnoreCase(entryTemp.getKey())) {
						XSSFCell cell = row.createCell(1);
						cell.setCellValue(entryTemp.getValue());
						cell.setCellStyle(stylecol);

						if (finalTraineePresentCountMap.containsKey(entryTemp.getValue())) {

							int days = finalTraineePresentCountMap.get(entryTemp.getValue());
							int per = 0;

							if (listOfMarkAttendance.size() > 0) {
								per = ((days) * 100) / listOfMarkAttendance.size();
							}

							XSSFCell cell1 = row.createCell(5);
							cell1.setCellValue(days);
							cell1.setCellStyle(stylecol);

							XSSFCell cell6 = row.createCell(6);
							cell6.setCellValue(per);
							cell6.setCellStyle(stylecol);

						} else {
							XSSFCell cell1 = row.createCell(5);
							cell1.setCellValue("0");
							cell1.setCellStyle(stylecol);

							XSSFCell cell6 = row.createCell(6);
							cell6.setCellValue("0");
							cell6.setCellStyle(stylecol);

						}

					} else if ("empMail".equalsIgnoreCase(entryTemp.getKey())) {
						XSSFCell cell = row.createCell(2);
						cell.setCellValue(entryTemp.getValue());
						cell.setCellStyle(stylecol);
					} else if ("empName".equalsIgnoreCase(entryTemp.getKey())) {
						XSSFCell cell = row.createCell(3);
						cell.setCellValue(entryTemp.getValue());
						cell.setCellStyle(stylecol);
					}

				}

				for (Entry<String, Integer> entryTemp : finalTraineePresentCountMap.entrySet()) {
					if ("traning_noOfDays".equalsIgnoreCase(entryTemp.getKey())) {
						XSSFCell cell = row.createCell(4);
						cell.setCellValue(entryTemp.getValue());
						cell.setCellStyle(stylecol);

					}

				}

				for (String date : listDate) {
					int noOfAbsentCount = 0;
					int noOfpresntCount = 0;
					for (Entry<String, String> entryTemp1 : obj.entrySet()) {
						if (date.equalsIgnoreCase(entryTemp1.getKey())) {

							DateTimeFormatter DATEFORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd");
							LocalDate cdate = LocalDate.parse(date, DATEFORMATTER);

							SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-mm-dd");
							Date date1 = simpleDateFormat.parse(date);
							Date currentdate = new Date();
							String modifiedDate = new SimpleDateFormat("yyyy-MM-dd").format(currentdate);
							Date currentModiferdate = simpleDateFormat.parse(modifiedDate);

							LocalDate convertedcurrentdate = LocalDate.now();
							;
							DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-mm-dd");
							// LocalDate cdate = LocalDate.parse((CharSequence) date1,
							// DateTimeFormatter.ofPattern("yyyy-mm-dd"));
							// LocalDate cdate = LocalDate.parse(date, formatter);
							// LocalDate cdate = convert(date1);

							String rgbS = "ffc095";

							if (cdate.isAfter(convertedcurrentdate)) {
								rgbS = "e4fffd";
							}

							if ("Traniner On leave".equalsIgnoreCase(entryTemp1.getValue())) {
								rgbS = "a4a4a4";
							} else if ("Optional/Holiday".equalsIgnoreCase(entryTemp1.getValue())) {
								rgbS = "e59e9e";
							}

							byte[] rgbB;
							try {
								rgbB = Hex.decodeHex(rgbS);
								// get byte array from hex string
								XSSFColor color = new XSSFColor(rgbB, null);

								XSSFFont font1 = workbook.createFont();
								font1.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
								XSSFCellStyle style1 = workbook.createCellStyle();

								style1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
								style1.setAlignment(HorizontalAlignment.CENTER);
								// style.setFillForegroundColor(HSSFColor.RED.index);

								XSSFCell cell = row.createCell(colno);

								if (cdate.isAfter(convertedcurrentdate)) {
									cell.setCellValue("NA");
								} else {
									
									String[] s=entryTemp1.getValue().split("_");
									
									if(s.length>1) {
										cell.setCellValue(s[1]);	
									}
									else {
										cell.setCellValue(entryTemp1.getValue());	
									}
									
									
								}

								// cell.setCellValue(entryTemp1.getValue());
								if ("Absent".equalsIgnoreCase(entryTemp1.getValue())) {
									style1.setFillForegroundColor(color);
									cell.setCellStyle(style1);
									noOfAbsentCount++;
								} else if ("Traniner On leave".equalsIgnoreCase(entryTemp1.getValue())
										|| "Optional/Holiday".equalsIgnoreCase(entryTemp1.getValue())) {
									style1.setFillForegroundColor(color);
									cell.setCellStyle(style1);
									cell.setCellValue(entryTemp1.getValue());

								}

								else {
									XSSFCellStyle stylep = workbook.createCellStyle();
									stylep.setAlignment(HorizontalAlignment.CENTER);
									cell.setCellStyle(stylep);
								}

								colno++;
							} catch (DecoderException e) {
								 LOGGER.error("Error while generating excel file" + e);
							}
						}

					}
					HashedMap<String, String> absentPresentCount = new HashedMap<String, String>();
					absentPresentCount.put("absentCount", String.valueOf(noOfAbsentCount));
					absentPresentCount.put("PresentCount", String.valueOf(noOfpresntCount));
					fCountMap.put(date, absentPresentCount);

				}

				srno++;

			}
			String rgbS = "CDFFAC";
			byte[] rgbB;
			rgbB = Hex.decodeHex(rgbS);
			XSSFColor color = new XSSFColor(rgbB, null);

			XSSFFont font1 = workbook.createFont();
			font1.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
			XSSFCellStyle style1 = workbook.createCellStyle();
			style1.setFont(font);
			style1.setFillPattern(FillPatternType.SOLID_FOREGROUND);
			// style.setFillForegroundColor(HSSFColor.RED.index);
			style1.setFillForegroundColor(color);
			style1.setAlignment(HorizontalAlignment.CENTER);

			row = spreadsheet.createRow(rowid++);
			XSSFCell cell0 = row.createCell(0);
			cell0.setCellValue("Daywise Attendance count");
			cell0.setCellStyle(style1);
			XSSFCell cell1 = row.createCell(1);
			cell1.setCellValue("");
			cell1.setCellStyle(style1);
			XSSFCell cell2 = row.createCell(2);
			cell2.setCellValue("");
			cell2.setCellStyle(style1);
			XSSFCell cell3 = row.createCell(3);
			cell3.setCellValue("");
			cell3.setCellStyle(style1);
			XSSFCell cell4 = row.createCell(4);
			cell4.setCellValue("");
			cell4.setCellStyle(style1);
			XSSFCell cell5 = row.createCell(5);
			cell5.setCellValue("");
			cell5.setCellStyle(style1);
			XSSFCell cell6 = row.createCell(6);
			cell6.setCellValue("");
			cell6.setCellStyle(style1);
			XSSFCell cell7 = row.createCell(7);
			cell7.setCellValue("");
			cell7.setCellStyle(style1);

			spreadsheet.addMergedRegion(new CellRangeAddress(rowid - 1, // first row (0-based)
					rowid - 1, // last row (0-based)
					0, // first column (0-based)
					6 // last column (0-based)
			));
			int colno = 7;

			for (String date : listDate) {

				for (Entry<String, Integer> entry : finalPresentCountMap.entrySet()) {

					if (finalPresentCountMap.containsKey(date)) {
						if (date.equalsIgnoreCase(entry.getKey())) {
							int t = (rowid - 2) - entry.getValue();
							String s = "Present :" + entry.getValue() + " Absent :" + t;
							XSSFCell cell = row.createCell(colno);
							cell.setCellValue(s);
							cell.setCellStyle(style1);

						}

					} else if (listTraninerLeave.contains(date)) {
						String rgbS1 = "a4a4a4";
						byte[] rgbB1;
						rgbB = Hex.decodeHex(rgbS1);
						XSSFColor color1 = new XSSFColor(rgbB, null);

						XSSFFont font2 = workbook.createFont();
						font1.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
						XSSFCellStyle style3 = workbook.createCellStyle();
						style3.setFont(font2);
						style3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
						// style.setFillForegroundColor(HSSFColor.RED.index);
						style3.setFillForegroundColor(color1);
						style3.setAlignment(HorizontalAlignment.CENTER);
						XSSFCell cell = row.createCell(colno);
						cell.setCellValue("");
						cell.setCellStyle(style3);

					} else if (optinalHoliday.contains(date)) {
						String rgbS1 = "e59e9e";
						byte[] rgbB1;
						rgbB = Hex.decodeHex(rgbS1);
						XSSFColor color1 = new XSSFColor(rgbB, null);

						XSSFFont font2 = workbook.createFont();
						font1.setColor(HSSFColor.HSSFColorPredefined.BLACK.getIndex());
						XSSFCellStyle style3 = workbook.createCellStyle();
						style3.setFont(font2);
						style3.setFillPattern(FillPatternType.SOLID_FOREGROUND);
						// style.setFillForegroundColor(HSSFColor.RED.index);
						style3.setFillForegroundColor(color1);
						style3.setAlignment(HorizontalAlignment.CENTER);
						XSSFCell cell = row.createCell(colno);
						cell.setCellValue("");
						cell.setCellStyle(style3);
					} else {
						String s = "Present : 0" + " Absent :" + (rowid - 2);
						XSSFCell cell = row.createCell(colno);
						cell.setCellValue(s);
						cell.setCellStyle(style1);

					}

				}
				colno++;
			}

			ServletOutputStream outputStream = response.getOutputStream();
			workbook.write(outputStream);
			workbook.close();
			outputStream.close();
			response.flushBuffer();
		} catch (IOException e) { // TODO Auto-generated
			// catch block
			// logger.error(e.getMessage());
		}
	}

	public static LocalDate convert(Date date) {
		if(date !=null)
		return date.toInstant().atZone(ZoneId.of("UTC")).toLocalDate();
		else {
			return LocalDate.now(); 
		}
	}

	public  List<String> getOptionalAndHolidayDates() {
		
		List<String> datelist = Arrays.asList("2024-01-01", "2024-01-15", "2024-01-26", "2024-03-08", "2024-03-25",
				"2024-03-29", "2024-03-30", "2024-04-09", "2024-04-11", "2024-04-14", "2024-04-21", "2024-05-01","2024-05-13",
				"2024-06-02", "2024-06-17", "2024-08-15", "2024-08-19", "2024-08-26", "2024-09-07", "2024-09-17",
				"2024-10-02", "2024-10-11", "2024-10-12", "2024-10-31", "2024-11-01", "2024-11-02", "2024-11-15",
				"2024-12-25");
		return list();
	}
	
	public List<String> list(){
		List<OptionalHoliday> list =optionalHolidayService.list();
		return list.stream().map(OptionalHoliday::getDate).map(e->e.format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))).toList();
	}

	public  List<LocalDate> getOptionalAndHolidayInLocalDates() {

		List<LocalDate> localdateList = new ArrayList<>();
		for (String date : getOptionalAndHolidayDates()) {
			LocalDate localDate = LocalDate.parse(date);
			localdateList.add(localDate);
		}
		return localdateList;
	}

	public static Date asDate(LocalDate localDate) {
		return Date.from(localDate.atStartOfDay().atZone(ZoneId.of("UTC")).toInstant());
	}

	public static double round(double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		long factor = (long) Math.pow(10, places);
		value = value * factor;
		long tmp = Math.round(value);
		return (double) tmp / factor;
	}
}
