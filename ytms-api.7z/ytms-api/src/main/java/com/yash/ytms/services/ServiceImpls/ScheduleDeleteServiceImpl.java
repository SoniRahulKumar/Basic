package com.yash.ytms.services.ServiceImpls;

import java.security.Principal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ytms.domain.Calendar;
import com.yash.ytms.domain.ScheduleDelete;
import com.yash.ytms.domain.YtmsUser;
import com.yash.ytms.dto.CalendarDto;
import com.yash.ytms.dto.ScheduleDeleteDto;
import com.yash.ytms.dto.YtmsUserDto;
import com.yash.ytms.repository.CalendarRepository;
import com.yash.ytms.repository.ScheduleDeleteRepository;
import com.yash.ytms.services.IServices.ICalendarService;
import com.yash.ytms.services.IServices.IScheduleDeleteService;
import com.yash.ytms.services.IServices.IYtmsUserService;

@Service
public class ScheduleDeleteServiceImpl implements IScheduleDeleteService {
	final Logger LOGGER = LoggerFactory.getLogger(ScheduleDeleteServiceImpl.class);

	@Autowired
	private ICalendarService calendarService;
	@Autowired
	private ScheduleDeleteRepository deleteRepository;
	@Autowired
	private IYtmsUserService userService;
	@Autowired
	private ModelMapper modelMapper;
    @Autowired
    private CalendarRepository calendarRepository;
	
	
    @Override
    public ScheduleDeleteDto save(CalendarDto calendarDto) {
    	LOGGER.info("In Save");
        // TODO Auto-generated method stub
        ScheduleDeleteDto scheduleDeleteDto = new ScheduleDeleteDto();
        Calendar calendar = this.modelMapper.map(calendarDto, Calendar.class);
        scheduleDeleteDto.setCalendar(calendar);
        ScheduleDelete save = this.modelMapper.map(scheduleDeleteDto, ScheduleDelete.class);
        save.setStatus(0);
        save.setType("Training");

        DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
        LocalDateTime localDateTime = LocalDateTime.parse(calendarDto.getStart(), formatter);

        LocalDate localDate = localDateTime.toLocalDate();

        LOGGER.info(String.valueOf(localDate));
        save.setDelete_date(localDate);

        return this.modelMapper.map(deleteRepository.saveAndFlush(save), ScheduleDeleteDto.class);
    }

	
	
	@Override
	public ScheduleDeleteDto saveTask(CalendarDto calendarDto) {
		LOGGER.info("In Save Task");
	    // TODO Auto-generated method stub
	    ScheduleDeleteDto scheduleDeleteDto = new ScheduleDeleteDto();
	    Calendar calendar = this.modelMapper.map(calendarDto, Calendar.class);
	    scheduleDeleteDto.setCalendar(calendar);
	    ScheduleDelete save = this.modelMapper.map(scheduleDeleteDto, ScheduleDelete.class);
	    save.setStatus(0);
	    save.setType("Task");

	    DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;
	    LocalDateTime localDateTime = LocalDateTime.parse(calendarDto.getStart(), formatter);

	    LocalDate localDate = localDateTime.toLocalDate();
	    LOGGER.info(String.valueOf(localDate));
	    save.setDelete_date(localDate);

	    return this.modelMapper.map(deleteRepository.saveAndFlush(save), ScheduleDeleteDto.class);
	}
	

	@Override
	public ScheduleDeleteDto approve(Long id,Principal principal) {
		LOGGER.info("In Approve");
		final String userName = principal.getName();
		YtmsUserDto userDto = this.userService.getUserByEmailAdd(userName);
		YtmsUser user = this.modelMapper.map(userDto, YtmsUser.class);
		ScheduleDelete delete = deleteRepository.getReferenceById(id);
		if(delete.getType().equals("Training"))
		{
		delete.setStatus(1);
		delete.setScheduleUser(user);
		ScheduleDeleteDto scheduleDeleteDto = this.modelMapper.map(deleteRepository.saveAndFlush(delete), ScheduleDeleteDto.class);
		if(delete.getCalendar().getGroup_id()== null)
		{
			delete.getCalendar().setGroup_id(delete.getCalendar().getId());
		}
		
		calendarService.deleteById(delete.getCalendar().getGroup_id());
		return scheduleDeleteDto;
		}
		else
		{
			delete.setStatus(1);
			delete.setScheduleUser(user);
			calendarService.singluarDelete(delete.getDelete_date(),delete.getCalendar().getId());
			return this.modelMapper.map(deleteRepository.saveAndFlush(delete), ScheduleDeleteDto.class);
		}
		}

	@Override
	public ScheduleDeleteDto deny(Long id,Principal principal) {
		LOGGER.info("In Delete DTO");
		final String userName = principal.getName();
		YtmsUserDto userDto = this.userService.getUserByEmailAdd(userName);
		YtmsUser user = this.modelMapper.map(userDto, YtmsUser.class);
		ScheduleDelete save = deleteRepository.getReferenceById(id);
		save.setScheduleUser(user);
		save.setStatus(2);
		return this.modelMapper.map(deleteRepository.saveAndFlush(save), ScheduleDeleteDto.class);
	}

	@Override
	public List<ScheduleDeleteDto> getToApprove() {
		LOGGER.info("In Scheule Delete DTO");
	 List<ScheduleDelete> toDelete = deleteRepository.findByStatus(0);
		return toDelete.stream().map(ce -> this.modelMapper.map(ce, ScheduleDeleteDto.class)).toList();
	 	
	}

}
