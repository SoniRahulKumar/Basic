package com.yash.ytms.controller;

import java.io.IOException;
import java.security.Principal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ytms.domain.AssociateSummaryResponseDto;
import com.yash.ytms.dto.AssociateDto;
import com.yash.ytms.dto.AssociateSummaryDto;
import com.yash.ytms.dto.NominationDto;
import com.yash.ytms.dto.TrainingRequestFormDto;
import com.yash.ytms.services.IServices.IAssociateService;
import com.yash.ytms.services.IServices.INominationService;
import com.yash.ytms.util.ExcelExporter;
import com.yash.ytms.util.TrainingExcelExporter;

import jakarta.servlet.http.HttpServletResponse;

@RestController
public class NominationBulkUploadController {

	@Autowired
	private INominationService iNominationUploadService;

	@Autowired
	private IAssociateService iAssociateService;

	final Logger LOGGER = LoggerFactory.getLogger(NominationBulkUploadController.class);

	@PostMapping("/register/readExcel")
	public List<NominationDto> bulkUpload(@RequestParam("file") MultipartFile file) {
		List<NominationDto> nominationUploadDataList = null;
		LOGGER.info("FileName : " + file.getOriginalFilename());
		try {
			nominationUploadDataList = iNominationUploadService.parseExcel(file);
			nominationUploadDataList.stream().forEach(System.out::println);
			LOGGER.info("uploading file");
			return nominationUploadDataList;
		} catch (Exception e) {
			LOGGER.error("Error i uploading file" + e);
			return nominationUploadDataList;
		}
	}

	@PostMapping("/register/saveNomination")
	public NominationDto saveNomination(@RequestBody NominationDto dto, Principal principal) {
		LOGGER.info("Saving nomination");
		return iNominationUploadService.saveNomination(dto, principal);
	}
	
	@PostMapping("/register/updateNomination")
	public NominationDto updateNomination(@RequestBody NominationDto dto, Principal principal) {
		LOGGER.info("Saving nomination");
		return iNominationUploadService.updateNomination(dto);
	}

	@GetMapping("/register/getNominationListByTrainingId/{trainingId}")
	public List<NominationDto> getNominationListByTrainingId(@PathVariable Long trainingId) {
		LOGGER.info("Getting nomination by training Id");
		return iNominationUploadService.findNominationsByTrainingID(trainingId);
	}

	@GetMapping("/register/getNominationById/{nominationId}")
	public NominationDto getNominationById(@PathVariable Long nominationId) {
		LOGGER.info("Getting nomination by nomination Id");
		return iNominationUploadService.getNomiationById(nominationId);
	}

	@GetMapping("/register/getAllNominations")
	public AssociateSummaryResponseDto getAllNominations() {
		LOGGER.info("Getting all nominations");
		return iNominationUploadService.list();
	}

	@GetMapping("/register/getAllTrainingsByAssociate/{emailId}")
	public List<AssociateDto> getAllTrainingsByAssociate(@PathVariable String emailId) {
		LOGGER.info("Getting all getAllTrainingsByAssociate");
		return iAssociateService.findAllAssociateTrainingByMailId(emailId);
	}

	@PutMapping("/register/update-nomination")
	public NominationDto updateNominationById(@RequestBody NominationDto dto) {
		LOGGER.info("Updating nomination Id");
		return iNominationUploadService.saveNomination(dto);
	}

	@DeleteMapping("/register/deleteNominationById/{nominationId}")
	public void deleteTraining(@PathVariable long nominationId) {
		LOGGER.info("Deleting nomination Id");
		iNominationUploadService.deleteNominationById(nominationId);
		return;
	}

	@PostMapping(value = "/register/export-to-excel")
	public void exportIntoExcelFile(@RequestBody List<AssociateSummaryDto> data, HttpServletResponse response)
			throws IOException {
		response.setContentType("text/csv");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=Associates" + currentDateTime + ".xlsx";
		response.setHeader(headerKey, headerValue);
		response.addHeader(headerKey, headerValue);
		ExcelExporter generator = new ExcelExporter(data);
		generator.generateExcelFile(response);
	}

	@PutMapping("/register/updateFeedBack")
	public List<NominationDto> updateFeedBack(@RequestBody List<NominationDto> feedBackList) {
		LOGGER.info("Updating FeedBack In Nomination");
		return iNominationUploadService.updateFeedBack(feedBackList);
	}

	@PutMapping("/register/updateFinalScore")
	public List<NominationDto> updateFinalScore(@RequestBody List<NominationDto> finalScoreList) {
		LOGGER.info("Updating Final Score In Nomination");
		return iNominationUploadService.updateFinalScore(finalScoreList);
	}

	@PostMapping(value = "/register/export-traings-to-excel")
	public void exportExcelFile(@RequestBody List<TrainingRequestFormDto> data, HttpServletResponse response)
			throws IOException {
		response.setContentType("text/csv");
		DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
		String currentDateTime = dateFormatter.format(new Date());

		String headerKey = "Content-Disposition";
		String headerValue = "attachment; filename=Associates" + currentDateTime + ".xlsx";
		response.setHeader(headerKey, headerValue);
		response.addHeader(headerKey, headerValue);
		TrainingExcelExporter generator = new TrainingExcelExporter(data);
		generator.generateExcelFile(response);
	}

}