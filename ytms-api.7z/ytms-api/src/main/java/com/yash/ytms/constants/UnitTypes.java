package com.yash.ytms.constants;

/**
 * Project Name - ytms-api
 * <p>
 * IDE Used - IntelliJ IDEA
 *
 * @author - yash.raj
 * @since - 25-01-2024
 */
public enum UnitTypes {

	BG1_BU2,
	BG1_BU3,
	BG1_BU4,
	BG1_BU5,
    
}
