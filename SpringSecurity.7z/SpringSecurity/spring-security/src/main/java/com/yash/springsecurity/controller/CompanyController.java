package com.yash.springsecurity.controller;

import com.yash.springsecurity.service.CompanyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/secure/company")
public class CompanyController {

    @Autowired
    private CompanyService companyService;

    @GetMapping("/getByd")
    public void getById(){
        
    }

}
