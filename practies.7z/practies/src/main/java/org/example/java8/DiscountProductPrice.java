package org.example.java8;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

//public class DiscountProductPrice {
//
//    // Create some example products
//    Product product1 = new Product("Laptop", 1000);
//    Product product2 = new Product("Smartphone", 500);
//    Product product3 = new Product("Headphones", 200);
//    Product product4 = new Product("Tablet", 800);
//
//    // Create a list of products
//    List<Product> products = new ArrayList<>();
//        products.add(product1);
//        products.add(product2);
//        products.add(product3);
//        products.add(product4);
//
//    // Find the product with the highest price
//    Product productWithHighestPrice = products.stream()
//            .max(Comparator.comparingDouble(Product::getPrice))
//            .orElseThrow(IllegalArgumentException::new);
//
//    // Apply 10% discount to the product with the highest price
//    double discount = productWithHighestPrice.getPrice() * 0.1;
//    double discountedPrice = productWithHighestPrice.getPrice() - discount;
//
//    // Calculate the total amount paid to the shopkeeper
//    double totalAmount = products.stream()
//            .mapToDouble(product -> product == productWithHighestPrice ? discountedPrice : product.getPrice())
//            .sum();
//
//        System.out.println("Total amount paid to the shopkeeper: $"+totalAmount);
//}
