package com.yash.ytms.services.ServiceImpls;

import java.security.Principal;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.ytms.constants.RequestStatusTypes;
import com.yash.ytms.domain.Calendar;
import com.yash.ytms.domain.Holiday;
import com.yash.ytms.domain.YtmsUser;
import com.yash.ytms.dto.CalendarDto;
import com.yash.ytms.dto.ResponseWrapperDto;
import com.yash.ytms.dto.YtmsUserDto;
import com.yash.ytms.exception.ApplicationException;
import com.yash.ytms.repository.CalendarRepository;
import com.yash.ytms.repository.HolidayRepository;
import com.yash.ytms.services.IServices.ICalendarService;
import com.yash.ytms.services.IServices.IYtmsUserService;

import jakarta.transaction.Transactional;

@Service
public class CalendarServiceImpl implements ICalendarService {
	final Logger LOGGER = LoggerFactory.getLogger(CalendarServiceImpl.class);

	@Autowired
	private HolidayRepository holidayRepository;

	@Autowired
	private CalendarRepository calendarRepository;

	@Autowired
	private IYtmsUserService userService;

	@Autowired
	private ModelMapper modelMapper;

	@Override
	public List<CalendarDto> createCalendarEvents(List<CalendarDto> calendarDto, Principal principal) {
		LOGGER.info("In Create Calendar Event");
		final String userName = principal.getName();
		YtmsUserDto userDto = this.userService.getUserByEmailAdd(userName);
		if (ObjectUtils.isNotEmpty(calendarDto) && ObjectUtils.isNotEmpty(userDto)) {
			YtmsUser user = this.modelMapper.map(userDto, YtmsUser.class);
			List<Calendar> calendarEvents = calendarDto.stream().map(cd -> this.modelMapper.map(cd, Calendar.class))
					.toList();
			calendarEvents.stream().map(event -> {
				event.setStart();
				event.setEnd();
				event.setScheduleUser(user);
				return event;
			}).collect(Collectors.toList());

			calendarEvents = calendarRepository.saveAllAndFlush(calendarEvents);

			List<CalendarDto> calendar = calendarEvents.stream().map(ce -> this.modelMapper.map(ce, CalendarDto.class))
					.toList();
			return calendar;
		} else {
			throw new ApplicationException("Event details is invalid, please try again !");

		}
	}

	
	boolean checkExists(List<Calendar> calendars, Calendar calendarToCheck) {
		LOGGER.info("In Check Exist");
	    return calendars.stream()
	        .anyMatch(calendar -> 
	            (calendar.getScheduleUser().getEmailAdd().equals(calendarToCheck.getScheduleUser().getEmailAdd()) ) &&
	            (calendar.getStart().isBefore(calendarToCheck.getEnd()) &&
	            calendar.getEnd().isAfter(calendarToCheck.getStart()))
	        );
	}
	
	@Override
	public CalendarDto updateCalendarEvent(CalendarDto calendarDto, Principal principal) {
		LOGGER.info("In Update Calendar Event");
		List<Calendar> calendars = expandCalendarsWithWeekdays(calendarRepository.findAll());
		final String userName = principal.getName();
		
		YtmsUserDto userDto = this.userService.getUserByEmailAdd(userName);
	
		
		if (ObjectUtils.isNotEmpty(calendarDto) && ObjectUtils.isNotEmpty(userDto)) {
			YtmsUser user = this.modelMapper.map(userDto, YtmsUser.class);
			Calendar calendarEvent = this.modelMapper.map(calendarDto, Calendar.class);
		
			if(calendarEvent.getScheduleUser() == null)
			{
			calendarEvent.setScheduleUser(user);
			}
			
			calendarEvent.setStart();
			calendarEvent.setEnd();
			
				if(!checkExists(calendars, calendarEvent))
			{
				LOGGER.info(String.valueOf(checkExists(calendars, calendarEvent)));
				
				calendarEvent = calendarRepository.saveAndFlush(calendarEvent);
			CalendarDto calendar = this.modelMapper.map(calendarEvent, CalendarDto.class);
			return calendar;
			}
			else
			{
				
				throw new ApplicationException("Time-slot not available");
			}
	
		} 
			else {
			throw new ApplicationException("Event details is invalid, please try again !");
		}
	}

	
	
	
	
	
	
	@Override
	public List<CalendarDto> getAllCalendarEvents() {
		LOGGER.info("In Get All Calendar Event");
		List<Calendar> calendarEvents = expandCalendarsWithWeekdays(calendarRepository.findAll());
			return calendarEvents.stream().map(ce -> this.modelMapper.map(ce, CalendarDto.class)).toList();
	}

	public List<Calendar> expandCalendarsWithWeekdays(List<Calendar> calendars) {
		LOGGER.info("In Expand Calendars With Week Days");
		List<Holiday> holidayList = holidayRepository.findAll();
		return calendars.stream().flatMap(calendar -> {
			List<Calendar> expandedCalendars = new ArrayList<>();
			expandedCalendars.add(calendar);
			if (calendar.getNumber_of_week_days() > 0) {
				expandedCalendars.addAll(expandWeekdays(calendar, calendar.getStart(), calendar.getEnd(),
						calendar.getNumber_of_week_days(), holidayList));
			}
			return expandedCalendars.stream();
		}).collect(Collectors.toList());
	}

	private List<Calendar> expandWeekdays(Calendar originalCalendar, LocalDateTime currentDay, LocalDateTime endDay,
			long remainingWeekdays, List<Holiday> holidayList) {
		LOGGER.info("In Expand Week Days");
		if (remainingWeekdays == 1) {
			return List.of();
		}

		List<Calendar> expandedCalendars = new ArrayList<>();
		while (remainingWeekdays > 1) {
			currentDay = currentDay.plusDays(1);
			endDay = endDay.plusDays(1);
			if (isWeekday(currentDay) && isWeekday(endDay) && !isOptionalHoliday(holidayList, currentDay)
					&& !isOptionalHoliday(holidayList, endDay)) {
				LOGGER.info("In Create Calendar From Original");
				Calendar newCalendar = createCalendarFromOriginal(originalCalendar, currentDay, endDay);
				expandedCalendars.add(newCalendar);
				remainingWeekdays--;
			}
		}
		return expandedCalendars;
	}

	private boolean isWeekday(LocalDateTime day) {
		LOGGER.info("In Is Week Day");
		DayOfWeek dayOfWeek = day.getDayOfWeek();
		return dayOfWeek != DayOfWeek.SATURDAY && dayOfWeek != DayOfWeek.SUNDAY;
	}

	private boolean isOptionalHoliday(List<Holiday> holidays, LocalDateTime day) {
		LOGGER.info("In Is Optional HoliDay");
		LocalDate date = day.toLocalDate();
		return holidays.stream().anyMatch(holiday -> holiday.getStart_date().isEqual(date));
	}

	private static Calendar createCalendarFromOriginal(Calendar originalCalendar, LocalDateTime start,
			LocalDateTime end) {
		Calendar newCalendar = new Calendar();
		newCalendar.setId(originalCalendar.getId());
		newCalendar.setTitle(originalCalendar.getTitle());
		newCalendar.setStart(start);
		newCalendar.setEnd(end);
		newCalendar.setNumber_of_week_days(0L);
		newCalendar.setScheduleUser(originalCalendar.getScheduleUser());
		return newCalendar;
	}

	@Override
	public List<CalendarDto> searchByTrainer(String trainerEmail) {
		LOGGER.info("In Search By Trainer");
		if (StringUtils.isNotEmpty(trainerEmail)) {
			ResponseWrapperDto responseWrapperDto = new ResponseWrapperDto();
			List<Calendar> calendar = expandCalendarsWithWeekdays(
					this.calendarRepository.findAllEventsByTrainerEmail(trainerEmail));
			List<CalendarDto> calendarDto = calendar.stream().map(e -> this.modelMapper.map(e, CalendarDto.class))
					.toList();

			if (calendar.isEmpty()) {
				responseWrapperDto.setStatus(RequestStatusTypes.FAILED.toString());
				responseWrapperDto.setMessage("No Events Found for this trainer");
				responseWrapperDto.setData("Nil");
			} else {
				List<CalendarDto> calendarDtos = calendar.stream().map(e -> this.modelMapper.map(e, CalendarDto.class))
						.toList();
				responseWrapperDto.setStatus(RequestStatusTypes.SUCCESS.toString());
				responseWrapperDto.setMessage("Events found for trainer");
				responseWrapperDto.setData(calendarDtos);
			}
			return calendarDto;
		} else
			throw new ApplicationException("Trainer email is empty or null, please check & try again.");
	}

	@Override
	public CalendarDto getCalendarEventById(Long eventId) {
		LOGGER.info("In Get Calendar Event By ID");
		if (ObjectUtils.isNotEmpty(eventId)) {
			Optional<Calendar> optionalEvent = calendarRepository.findById(eventId);
			if (optionalEvent.isPresent()) {
				Calendar calendarEvent = optionalEvent.get();
				return this.modelMapper.map(calendarEvent, CalendarDto.class);
			} else
				throw new ApplicationException("Event not found !");
		} else
			throw new ApplicationException("Event id is null or empty, please check & try again !");
	}

	@Override
	@Transactional
	public void deleteById(Long event_id) {
		LOGGER.info("In Delete By ID");
		calendarRepository.deleteByGroupId(event_id);

	}

	public static long countWeekdays(LocalDate startDate, LocalDate endDate,LocalDate calcdate) {
	    if (startDate.isEqual(endDate) || calcdate.equals(endDate)) {
	        return 0;
	    } else {
	        long totalDays = ChronoUnit.DAYS.between(startDate, endDate);
	        // Calculate the number of weekend days between the start and end dates
	        long weekendDaysCount = 0;
	        for (LocalDate date = startDate;!date.isAfter(endDate); date = date.plusDays(1)) {
	            if (date.getDayOfWeek().getValue() >= DayOfWeek.SATURDAY.getValue()) {
	                weekendDaysCount++;
	            }
	        }
	        long weekdaysCount = totalDays - weekendDaysCount;

	        return weekdaysCount;
	    }
	}
	public LocalDate getEndDate(LocalDateTime startDate, long numWeekdays) {
		LOGGER.info("In Get End Date");
		  List<Holiday> holidayList = holidayRepository.findAll();
		  LocalDateTime currentDate = startDate;
		  for (long i = 0; i < numWeekdays; i++) {
		    currentDate = currentDate.plusDays(1);
		    if (!isWeekday(currentDate) || isOptionalHoliday(holidayList, currentDate)) {
		      i--; // Decrement counter if it's not a workday or optional holiday
		    }
		  }
		  return currentDate.toLocalDate();
		}
	
	
	
	public void singluarDelete(LocalDate date, Long id) {
		LOGGER.info("In Singular Delete");
		List<Holiday> holidays = holidayRepository.findAll();
		Calendar calendar = calendarRepository.getReferenceById(id);
		long orignalWeekDays = calendar.getNumber_of_week_days();
		LocalDate calcDate = getEndDate(calendar.getEnd(), orignalWeekDays).minusDays(1);
		LOGGER.info("In Count Week Days");
		long weekDays = countWeekdays(calendar.getEnd().toLocalDate(), date,calcDate);
		List<Calendar> calendars = new ArrayList<Calendar>();
		LOGGER.info(String.valueOf(orignalWeekDays));
		LOGGER.info(String.valueOf(getEndDate(calendar.getEnd(), orignalWeekDays).minusDays(1)));
		LOGGER.info(String.valueOf(weekDays));
	
		if ((orignalWeekDays/2) > weekDays && weekDays > 0 && weekDays>2) {
			calendar.setNumber_of_week_days((orignalWeekDays - (orignalWeekDays - weekDays))-2);
			LOGGER.info("More than half >2");
			LOGGER.info(String.valueOf(orignalWeekDays));
			LOGGER.info(String.valueOf(weekDays));
			Calendar newCalendar = new Calendar();
			newCalendar.setTitle(calendar.getTitle());
			newCalendar.setStart((date.plusDays(1)).atTime(calendar.getStart().toLocalTime()));
			newCalendar.setEnd((date.plusDays(1)).atTime(calendar.getEnd().toLocalTime()));
			newCalendar.setScheduleUser(calendar.getScheduleUser());
			newCalendar.setNumber_of_week_days((orignalWeekDays - weekDays)+1);
			if (calendar.getGroup_id() == null) {
				calendar.setGroup_id(id);
				newCalendar.setGroup_id(id);
			} else {
				newCalendar.setGroup_id(calendar.getGroup_id());
			}
			while (!(isWeekday(newCalendar.getStart()) && !isOptionalHoliday(holidays, newCalendar.getStart()))) {

				newCalendar.setStart(newCalendar.getStart().plusDays(1));
				newCalendar.setEnd(newCalendar.getEnd().plusDays(1));
			}

			if(calendar.getNumber_of_week_days()>0)
			{
				calendars.add(calendar);
						
			}
			if(newCalendar.getNumber_of_week_days()>0)
			{
			calendars.add(newCalendar);
			}
		}
		if ((orignalWeekDays/2) > weekDays && weekDays > 0 && weekDays<=2) {
			calendar.setNumber_of_week_days((orignalWeekDays - (orignalWeekDays - weekDays)));
			LOGGER.info("More than half <=2");
			LOGGER.info(String.valueOf(orignalWeekDays));
			LOGGER.info(String.valueOf(weekDays));
			Calendar newCalendar = new Calendar();
			newCalendar.setTitle(calendar.getTitle());
			newCalendar.setStart((date.plusDays(1)).atTime(calendar.getStart().toLocalTime()));
			newCalendar.setEnd((date.plusDays(1)).atTime(calendar.getEnd().toLocalTime()));
			newCalendar.setScheduleUser(calendar.getScheduleUser());
			newCalendar.setNumber_of_week_days((orignalWeekDays - weekDays)-1);
			if (calendar.getGroup_id() == null) {
				calendar.setGroup_id(id);
				newCalendar.setGroup_id(id);
			} else {
				newCalendar.setGroup_id(calendar.getGroup_id());
			}
			while (!(isWeekday(newCalendar.getStart()) && !isOptionalHoliday(holidays, newCalendar.getStart()))) {

				newCalendar.setStart(newCalendar.getStart().plusDays(1));
				newCalendar.setEnd(newCalendar.getEnd().plusDays(1));
			}

			if(calendar.getNumber_of_week_days()>0)
			{
				calendars.add(calendar);
						
			}
			if(newCalendar.getNumber_of_week_days()>0)
			{
			calendars.add(newCalendar);
			}
		}

		if ((orignalWeekDays/2) <= weekDays && weekDays > 0 &&(orignalWeekDays - weekDays)>=2) {
			calendar.setNumber_of_week_days((orignalWeekDays - (orignalWeekDays - weekDays))-2);
			LOGGER.info("Less than half > 2");
			LOGGER.info(String.valueOf(orignalWeekDays));
			LOGGER.info(String.valueOf(weekDays));
			Calendar newCalendar = new Calendar();
			newCalendar.setTitle(calendar.getTitle());
			newCalendar.setStart((date.plusDays(1)).atTime(calendar.getStart().toLocalTime()));
			newCalendar.setEnd((date.plusDays(1)).atTime(calendar.getEnd().toLocalTime()));
			newCalendar.setScheduleUser(calendar.getScheduleUser());
			newCalendar.setNumber_of_week_days((orignalWeekDays - weekDays)+1);

			if (calendar.getGroup_id() == null) {
				calendar.setGroup_id(id);
				newCalendar.setGroup_id(id);
			} else {
				newCalendar.setGroup_id(calendar.getGroup_id());
			}

			while (!(isWeekday(newCalendar.getStart()) && !isOptionalHoliday(holidays, newCalendar.getStart()))) {

				newCalendar.setStart(newCalendar.getStart().plusDays(1));
				newCalendar.setEnd(newCalendar.getEnd().plusDays(1));
			}
			if(calendar.getNumber_of_week_days()>0)
			{
			calendars.add(calendar);
			}
			if(newCalendar.getNumber_of_week_days()>0)
			{
			calendars.add(newCalendar);
			}	
		}
		else if ((orignalWeekDays/2) <= weekDays && weekDays > 0 &&(orignalWeekDays - weekDays)<2) {
			calendar.setNumber_of_week_days((orignalWeekDays - (orignalWeekDays - weekDays)));
			LOGGER.info("Less than half <2 ");
			LOGGER.info(String.valueOf(orignalWeekDays));
			LOGGER.info(String.valueOf(weekDays));
			Calendar newCalendar = new Calendar();
			newCalendar.setTitle(calendar.getTitle());
			newCalendar.setStart((date.plusDays(1)).atTime(calendar.getStart().toLocalTime()));
			newCalendar.setEnd((date.plusDays(1)).atTime(calendar.getEnd().toLocalTime()));
			newCalendar.setScheduleUser(calendar.getScheduleUser());
			newCalendar.setNumber_of_week_days((orignalWeekDays - weekDays));

			if (calendar.getGroup_id() == null) {
				calendar.setGroup_id(id);
				newCalendar.setGroup_id(id);
			} else {
				newCalendar.setGroup_id(calendar.getGroup_id());
			}

			while (!(isWeekday(newCalendar.getStart()) && !isOptionalHoliday(holidays, newCalendar.getStart()))) {

				newCalendar.setStart(newCalendar.getStart().plusDays(1));
				newCalendar.setEnd(newCalendar.getEnd().plusDays(1));
			}
			if(calendar.getNumber_of_week_days()>0)
			{
			calendars.add(calendar);
			}
			if(newCalendar.getNumber_of_week_days()>1)
			{
			calendars.add(newCalendar);
			}	
			
			}
	     	else if (weekDays == 0) {
	    	if((calendar.getNumber_of_week_days() - 1)>0)
			{
	    	if(calendar.getStart().toLocalDate().isEqual(date))
	    	{
			calendar.setStart(calendar.getStart().plusDays(1));
			calendar.setEnd(calendar.getEnd().plusDays(1));
			calendar.setNumber_of_week_days(calendar.getNumber_of_week_days() - 1);
	    	}
	    	else
	    	{
	    		calendar.setNumber_of_week_days(calendar.getNumber_of_week_days() - 1);   		
	    	}
	    	}
	    	else
	    	{
	    		calendarRepository.deleteById(calendar.getId());
	    	}
	     	}

		calendarRepository.saveAllAndFlush(calendars);
	}


	@Override
	public CalendarDto getCalendarEventByTitle(String title) {
		LOGGER.info("In Get Calendar Event By Title");
		return this.modelMapper.map(calendarRepository.getByTitle(title),CalendarDto.class);
	}

}
