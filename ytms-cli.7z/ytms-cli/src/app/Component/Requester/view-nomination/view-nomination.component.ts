import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'src/app/Core/services/auth.service';
import { JwtService } from 'src/app/Core/services/jwt.service';
import { Nomination } from 'src/app/Model/Nomination';
import { TrainingRequestService } from 'src/app/services/training-request.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-view-nomination',
  templateUrl: './view-nomination.component.html',
  styleUrls: ['./view-nomination.component.css']
})
export class ViewNominationComponent {
  nomination: Nomination[] = [];
  id:any;
  userRole:string="";
  userName:string="";
  sideNavStatus: boolean = false;

  constructor(private formBuilder: FormBuilder, private router: Router, private ser: TrainingRequestService,
    private activatedRoute: ActivatedRoute, public dialog: MatDialog,private auth:AuthService,
    private jwtServ:JwtService,private _location: Location){
      let token = auth.getToken();
      this.userRole = jwtServ.getRoleFromToken(token);
      this.userName = jwtServ.getUserNameFromToken(token);
      let trainingId = this.activatedRoute.snapshot.paramMap.get('id');
      this.id=trainingId;
      this.getNominationListByTrainingId(trainingId);
  }
  ngOnInit(): void {

  }

  backClicked() {
    this._location.back();
  }

  getNominationListByTrainingId(trainingId:any){
    if(trainingId != null && trainingId >0)
    this.ser.getNominationListByTrainingId(trainingId).subscribe(resp => {

      this.nomination = resp;
      console.log(resp)
      if(this.userRole !== 'ROLE_TECHNICAL_MANAGER'  && this.userRole !=='ROLE_COMPETENCY_MANAGER'){

        this.nomination =this.nomination.filter(nomination=>{
          console.log("nomination.requestor");
          console.log(nomination.requestor);
          console.log("this.userName");
          console.log(this.userName);
          return nomination.requestor == this.userName
        });

      }

    });
  }

  reloadComponent(){
    window.location.reload();
  }

  deleteNominationById(nominationId: any){
    confirm("Are You Sure Want Delete Nomination ")
    this.ser.deleteNominationById(nominationId).subscribe();
    //this.getNominationListByTrainingId(this.id);
    this.reloadComponent();
  }

  openNominationDialog(templateRef: any) {
    let dialogRef = this.dialog.open(templateRef, {
      width: '50%',
      height: '50%'
    });
  }
  setNominationId(nominationId: any) {
    this.ser.setNominationId(nominationId);
    //this.nominationReq.nominationId=nominationId;
  }


}
