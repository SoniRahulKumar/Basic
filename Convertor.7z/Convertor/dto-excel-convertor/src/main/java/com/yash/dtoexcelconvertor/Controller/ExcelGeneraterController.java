package com.yash.dtoexcelconvertor.Controller;

import com.yash.dtoexcelconvertor.Convertor.ExcelGenerator;
import com.yash.dtoexcelconvertor.dto.TrainingReqForm;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RestController
public class ExcelGeneraterController {

    @GetMapping("/export-to-excel")
    public void exportIntoExcelFile(HttpServletResponse response) throws IOException {
        response.setContentType("application/octet-stream");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());

        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=student" + currentDateTime + ".xlsx";
        response.setHeader(headerKey, headerValue);
        List<TrainingReqForm> trainingReqFormList = new ArrayList<>();
        TrainingReqForm trainingReqForm = new TrainingReqForm();
        trainingReqForm.setId(1);
        trainingReqForm.setTrainingIdentifierName("A");
        trainingReqForm.setTrainingDescription("A");
        trainingReqForm.setStartDate(new Date());
        trainingReqForm.setEndDate(new Date());
        trainingReqForm.setActualStartDate(new Date());
        trainingReqForm.setActualEndDate(new Date());
        trainingReqForm.setStatus("status");
        trainingReqForm.setCreatedAt(new Date());
        trainingReqForm.setUpdatedAt(new Date());
        trainingReqForm.setNoOfParticipant(10);
        trainingReqForm.setUserName("userName");
        trainingReqForm.setDeclinedMessage("message");

        trainingReqFormList.add(trainingReqForm);

        ExcelGenerator excelGenerator = new ExcelGenerator(trainingReqFormList);

        excelGenerator.generateExcelFile(response);
    }
}
