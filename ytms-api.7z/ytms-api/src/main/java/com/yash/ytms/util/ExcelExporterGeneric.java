/**
 * 
 */
package com.yash.ytms.util;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.yash.ytms.dto.AssociateDto;

import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;

/**
 * 
 */
public class ExcelExporterGeneric {
	
	public void createExcelFile(String sheetName,HttpServletResponse response, List<AssociateDto> rowData) throws IOException {
		// Create a new workbook
        XSSFWorkbook workbook = new XSSFWorkbook();
        
     // Create a new sheet
        XSSFSheet sheet = workbook.createSheet(sheetName);
		String[] header = {"emp_id", "emp_name", "emp_mail_id","competency","grade","trainingName","noOfDays","actualStartDate",
				"actualEndDate","skill","upgraded skill","current_allocation","project","current_location",
				"trainingStatus","final score","feedback"};
		
		
		// Write header row
        XSSFRow headerRow = sheet.createRow(0);
        CellStyle headerStyle = workbook.createCellStyle();
		XSSFFont headerfont = workbook.createFont();
		headerfont.setBold(true);
		headerfont.setFontHeight(16);
		headerStyle.setFont(headerfont);
        for (int i = 0; i < header.length; i++) {
//            headerRow.createCell(i).setCellValue(header[i]);
        	createCell(headerRow,i,header[i],headerStyle);
        }
        
     // Write data rows
        CellStyle style = workbook.createCellStyle();
		XSSFFont font = workbook.createFont();
		font.setFontHeight(14);
		style.setFont(font);
        int rowIndex = 1;
        for(AssociateDto associateDto : rowData) {
        	XSSFRow dataRow = sheet.createRow(rowIndex++);
        	int columnCount = 0;
        	createCell(dataRow, columnCount++, associateDto.getEmp_id(),style);
        	createCell(dataRow, columnCount++, associateDto.getEmp_name(),style);
        	createCell(dataRow, columnCount++, associateDto.getEmp_mail_id(),style);
        	createCell(dataRow, columnCount++, associateDto.getCompetency(),style);
        	createCell(dataRow, columnCount++, associateDto.getGrade(),style);
        	createCell(dataRow, columnCount++, associateDto.getTrainingName(),style);
        	createCell(dataRow, columnCount++, associateDto.getNoOfDays(),style);
        	createCell(dataRow, columnCount++, associateDto.getActualStartDate()==null?associateDto.getActualStartDate():associateDto.getActualStartDate().toLocaleString(),style);
        	createCell(dataRow, columnCount++, associateDto.getActualEndDate()==null?associateDto.getActualEndDate():associateDto.getActualEndDate().toLocaleString(),style);
        	createCell(dataRow, columnCount++, associateDto.getSkill(),style);
        	createCell(dataRow, columnCount++, associateDto.getUpgradedSkills(),style);
        	createCell(dataRow, columnCount++, associateDto.getCurrent_allocation(),style);
        	createCell(dataRow, columnCount++, associateDto.getProject(),style);
        	createCell(dataRow, columnCount++, associateDto.getCurrent_location(),style);
        	createCell(dataRow, columnCount++, associateDto.getTrainingStatus(),style);
        	createCell(dataRow, columnCount++, associateDto.getFinalScore(),style);
        	createCell(dataRow, columnCount++, associateDto.getFeedback(),style);
        }
        
     // Write the workbook to a file
        ServletOutputStream outputStream = response.getOutputStream();
		workbook.write(outputStream);
		workbook.close();
		outputStream.close();

        System.out.println("Excel file created successfully!");
	}
	
	private void createCell(XSSFRow dataRow, int columnCount, Object valueOfCell,CellStyle style) {
		XSSFCell cell = dataRow.createCell(columnCount++);
		if (valueOfCell instanceof Integer) {
			cell.setCellValue((Integer) valueOfCell);
		} else if (valueOfCell instanceof Long) {
			cell.setCellValue((Long) valueOfCell);
		} else if (valueOfCell instanceof String) {
			cell.setCellValue((String) valueOfCell);
		} else if (valueOfCell instanceof Date) {
			cell.setCellValue((Date) valueOfCell);
		}else if (valueOfCell instanceof Double) {
			cell.setCellValue((Double) valueOfCell);
		}else if (valueOfCell instanceof Boolean) {
			cell.setCellValue((Boolean) valueOfCell);
		}else if (valueOfCell == null) {
			cell.setCellValue(null+"");
		}else {
			cell.setCellValue(valueOfCell.toString());
		}
		cell.setCellStyle(style);
	}

}
