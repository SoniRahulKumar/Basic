package org.example.leadCode;

import java.util.*;

public class AnagramWordChecking {

    public static String sortString(String inputString) {
        char[] tempArray = inputString.toCharArray();
        Arrays.sort(tempArray);
        return new String(tempArray);
    }

    public static void main(String[] args) {
        String[] arr = {"abcd", "java", "dcba", "ajav", "xyz", "tavant", "aattvn", "vatatn"};
        Map<String, List<String>> anagramGroups = new HashMap<>();

        for (String str : arr) {
            String sortedStr = sortString(str);
            if (anagramGroups.containsKey(sortedStr)) {
                anagramGroups.get(sortedStr).add(str);
            } else {
                List<String> list = new ArrayList<>();
                list.add(str);
                anagramGroups.put(sortedStr, list);
            }
        }

        for (List<String> group : anagramGroups.values()) {
            System.out.println(group);
        }
    }

//    Find and print anagram from a set of String.
//            Input - String arr[] = { "abcd", "java", "dcba", "ajav", "xyz", "tavant", "aattvn", "vatatn" };
//    Output -
//            [abcd, dcba]
//            [tavant, aattvn, vatatn]
//            [xyz]
//            [java, ajav]

//    public static void main(String[] args) {
//        String arr[] = { "abcd", "java", "dcba", "ajav", "xyz", "tavant", "aattvn", "vatatn" };
//        //step 1 - pic one one word get abcd then java
//        //step2 - break first word to short ase and compare with 2nd word using compareTo method -1
//        //step 3 - compare first and 3rd word return 0
//        //step4 - array[0], array[2]
//        int count = 0;
//        for (int i = 1; i < arr.length; i++) {
//            if(arr[count].compareTo(arr[i])){
//                System.out.println(arr[[count] +" "+arr[i]]);
//                count++;
//            }
//        }
//    }
}
