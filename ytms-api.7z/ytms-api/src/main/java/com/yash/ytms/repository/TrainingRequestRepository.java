/**
 *
 */
package com.yash.ytms.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.yash.ytms.domain.TrainingRequestForm;
import com.yash.ytms.dto.AssociateSummaryDto;

import jakarta.transaction.Transactional;

/**
 *
 */
@Repository
public interface TrainingRequestRepository extends JpaRepository<TrainingRequestForm, Long> {

	
	@Query(value="select distinct trm from TrainingRequestForm trm left join"
			+ "   Nomination nom"
			+ "   on trm.id=nom.trainingId where "
			+ "   (trm.userName =:userName or nom.requestor=:userName)",nativeQuery = false)
    public List<TrainingRequestForm> findByUserName(String userName);
	
	public List<TrainingRequestForm> findByStatus(String status);

    List<TrainingRequestForm> findByTrainerContains(String trainerName);

    @Query(value = "select full_name from ytms_user where email_add =:userName", nativeQuery = true)
    String findTrainerName(String userName);
    
	@Query(value = "SELECT id FROM ytms_api.training_managment where Date(actual_start_date) <= curdate() and training_status='PLANNED'", nativeQuery = true)
	List<Long> getPlannedButStartedTrainings();
    
    List<TrainingRequestForm> findByUserNameAndStatusAndActualStartDateAfter(String userName,String status,Date time );
    
    List<TrainingRequestForm> findByUserNameAndTrainerContainsAndStatusAndActualStartDateAfter(String userName,String trainer,String status,Date time );

	public List<TrainingRequestForm> findByStatusAndActualStartDateAfter(String status, Date time);
	
	
    @Query(value="SELECT\r\n"
    		+ "    count(id) as counted FROM training_managment\r\n"
    		+ " WHERE ((actual_start_date between :actualStartDate AND :actualEndDate)\r\n"
    		+ "or (actual_end_date  between :actualStartDate AND :actualEndDate))\r\n"
    		+ "and ((actual_start_time between  cast(:actualStartTime as time) AND cast(:actualEndTime as time))\r\n"
    		+ "or (actual_end_time  between cast(:actualStartTime as time) AND cast(:actualEndTime as time))) and status='APPROVED' and trainer=:trainerName",nativeQuery = true)
	public Long findByActualStartDateAndActualEndDate(Date actualStartDate,Date actualEndDate,String actualStartTime,String actualEndTime,String trainerName);
    
    
     @Modifying
	 @Transactional
	 @Query(value = "update training_managment  set actual_end_date = :actualEndDate,actual_start_date = :actualStartDate where id=:traningId",nativeQuery = true)
	 int updateActualStartEndDate(Date actualEndDate,Date actualStartDate,Long traningId);
     
    /* @Query(value="SELECT"
     		+ "    t FROM TrainingRequestForm t "
     		+ " WHERE ((t.actualStartDate between :actualStartDate AND :actualEndDate) "
     		+ "or (t.actualEndDate  between :actualStartDate AND :actualEndDate)) "
     		+ "and ((t.actualStartTime between  cast(:actualStartTime as time) AND cast(:actualEndTime as time)) "
     		+ "or (t.actualEndTime  between cast(:actualStartTime as time) AND cast(:actualEndTime as time))) and status='APPROVED' ",nativeQuery = false)
    
 	public List<TrainingRequestForm> findAllByActualStartDateAndActualEndDate(Date actualStartDate,Date actualEndDate,String actualStartTime,String actualEndTime);*/
     
     @Query(value="SELECT"
      		+ "    t.trainer FROM TrainingRequestForm t "
      		+ " WHERE ((t.actualStartDate between :actualStartDate AND :actualEndDate) "
      		+ "or (t.actualEndDate  between :actualStartDate AND :actualEndDate)) "
      		+ "and ((t.actualStartTime between  cast(:actualStartTime as time) AND cast(:actualEndTime as time)) "
      		+ "or (t.actualEndTime  between cast(:actualStartTime as time) AND cast(:actualEndTime as time))) and status='APPROVED' and t.trainer !=:trainerName  group by t.trainer ",nativeQuery = false)
     
  	public List<String> findAllByActualStartDateAndActualEndDate(Date actualStartDate,Date actualEndDate,String actualStartTime,String actualEndTime,String trainerName);

     @Query("select min(t.actualStartDate) as actualStartDate "
 			+ " from Nomination e,TrainingRequestForm t where e.trainingId = t.id  and t.status ='APPROVED'  and e.requestor=:requestor")
 	Date findAllAssociatesWithStatusAndRequestor(@Param(value = "requestor") String requestor);

     @Query("select  min(t.actualStartDate) as actualStartDate"
 			+ " from Nomination e,TrainingRequestForm t where e.trainingId = t.id  and t.status ='APPROVED' ")
     Date findAllAssociatesWithStatus();
}
