package com.yash.ytms.domain;

import java.util.List;

import com.yash.ytms.dto.AssociateSummaryDto;

import lombok.Data;

@Data
public class AssociateSummaryResponseDto {

	private List<AssociateSummaryDto> list;

	private String actualStartDate;

}
