package com.yash.ytms.services.ServiceImpls;

import java.io.IOException;
import java.security.Principal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.yash.ytms.constants.UserRoleTypes;
import com.yash.ytms.domain.AssociateSummaryResponseDto;
import com.yash.ytms.domain.Attendance;
import com.yash.ytms.domain.Nomination;
import com.yash.ytms.domain.TrainingRequestForm;
import com.yash.ytms.dto.AssociateSummaryDto;
import com.yash.ytms.dto.NominationDto;
import com.yash.ytms.dto.TrainingRequestFormDto;
import com.yash.ytms.repository.AttendanceRepository;
import com.yash.ytms.repository.NominationRepository;
import com.yash.ytms.repository.TrainingRequestRepository;
import com.yash.ytms.security.userdetails.CustomUserDetails;
import com.yash.ytms.services.IServices.INominationService;

@Service
public class NominationServiceImpl implements INominationService {
	final Logger LOGGER = LoggerFactory.getLogger(NominationServiceImpl.class);

	@Autowired
	private NominationRepository nominationUploadRepository;
	
	@Autowired
	private TrainingRequestRepository trainingRequestRepository;

	@Autowired
	private ModelMapper modelMapper;
	
	@Autowired
	AttendanceRepository attendanceRepository;
	
	
	@Override
	public List<NominationDto> parseExcel(MultipartFile file) throws IOException {
		LOGGER.info("In Parse Excel");

		Workbook workbook = WorkbookFactory.create(file.getInputStream());
		Sheet sheet = workbook.getSheetAt(0);

		List<NominationDto> nominationUploadDataList = new ArrayList<>();

		Iterator<Row> rowIterator = sheet.iterator();
		// Conv
		// Skip header row if exists
		// rowIterator = rowIterator.skip(1);
		if (rowIterator.hasNext()) {
			rowIterator.next();
		}

		while (rowIterator.hasNext()) {
			Row row = rowIterator.next();
			if (row.getCell(0) == null) {
				break;
			}

			if(row.getCell(0) != null && row.getCell(0).toString() != "0" && row.getCell(0).toString().trim() != "") {
				NominationDto nominationData = setNominationObject(row);
	
				nominationUploadDataList.add(nominationData);
			}

		}

		workbook.close();
		return nominationUploadDataList;

	}

	NominationDto setNominationObject(Row row) {
		LOGGER.info("In Set Nomination Object");
		NominationDto nomination = new NominationDto();

		String formattedStringValue = new DecimalFormat("#").format(row.getCell(0).getNumericCellValue());
		nomination.setEmp_id(formattedStringValue);
		nomination.setEmp_name(row.getCell(1).getStringCellValue());
		nomination.setEmp_mail_id(row.getCell(2).getStringCellValue());
		nomination.setGrade(row.getCell(3).getStringCellValue());
		nomination.setSkill(row.getCell(4).getStringCellValue());
		nomination.setCurrent_allocation(row.getCell(5).getStringCellValue());
		nomination.setProject(row.getCell(6).getStringCellValue());
		nomination.setCurrent_location(row.getCell(7).getStringCellValue());
		nomination.setCompetency(row.getCell(8).getStringCellValue());
		return nomination;

	}

	@Override
	public NominationDto saveNomination(NominationDto dto) {
		LOGGER.info("In Save Nomination");
		return modelMapper.map(nominationUploadRepository.save(modelMapper.map(dto, Nomination.class)),NominationDto.class);
	}

	@Override
	public List<NominationDto> findNominationsByTrainingID(Long trainingId) {
		LOGGER.info("In Find Nomination By Training Id");
		return modelMapper.map(nominationUploadRepository.findAllByTrainingId(trainingId), List.class);
	}

	@Override
	public NominationDto getNomiationById(Long id) {
		LOGGER.info("In Get Nomination By Id");
		return modelMapper.map(nominationUploadRepository.getById(id), NominationDto.class);
	}

	@Override
	public void deleteNominationById(Long id) {
		LOGGER.info("In Delete Nomination By ID");
		nominationUploadRepository.deleteById(id);
	}

	@Override
	public AssociateSummaryResponseDto list() {
		LOGGER.info("In List");
		AssociateSummaryResponseDto associateSummaryResponseDto=new AssociateSummaryResponseDto();
		List<AssociateSummaryDto>  list = null;
		
		CustomUserDetails userDetails =(CustomUserDetails) SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		List<String> roles =Arrays.asList(UserRoleTypes.ROLE_TECHNICAL_MANAGER.name(),UserRoleTypes.ROLE_COMPETENCY_MANAGER.name());
		if (roles.contains(userDetails.getGrantedAuthorities().getAuthority())) {
			 list =nominationUploadRepository.findAllAssociatesWithStatus();
			Date actualStartDate= trainingRequestRepository.findAllAssociatesWithStatus();
			String pattern = "yyyy-MM-dd";
			DateFormat df = new SimpleDateFormat(pattern);
			String todayAsString = df.format(actualStartDate);

			
			associateSummaryResponseDto.setActualStartDate(todayAsString);
		}else {
			list =nominationUploadRepository.findAllAssociatesWithStatusAndRequestor(userDetails.getUsername());
			Date actualStartDate= trainingRequestRepository.findAllAssociatesWithStatusAndRequestor(userDetails.getUsername());
			String pattern = "yyyy-MM-dd";
			DateFormat df = new SimpleDateFormat(pattern);
			String todayAsString = df.format(actualStartDate);

			associateSummaryResponseDto.setActualStartDate(todayAsString);
		}
		
		
		for(AssociateSummaryDto associate: list) {
			List<String> names= nominationUploadRepository.findByIdAndName(associate.getEmp_id(),associate.getEmp_mail_id());
			associate.setEmp_name(names.size()>0 ? names.get(0):"");
		}
		 associateSummaryResponseDto.setList(modelMapper.map(list, List.class));
		return associateSummaryResponseDto;
	}

	@Override
	public List<TrainingRequestFormDto> getAllTrainingsByAssociate(String emailId) {
		LOGGER.info("In Get All Training By Associate");
		List<Long> ids = nominationUploadRepository.findAllAssociatesByEmpId(emailId);
		List<TrainingRequestForm> listed = trainingRequestRepository.findAllById(ids);
		listed = listed.stream().filter(e -> "APPROVED".equals(e.getStatus())).collect(Collectors.toList());
		List<TrainingRequestFormDto> listedTrainings = modelMapper.map(listed, List.class);
		return listedTrainings;
	}

	@Override
	public NominationDto saveNomination(NominationDto dto, Principal principal) {
		LOGGER.info("Save Nomination");
		dto.setRequestor(principal.getName());
		return modelMapper.map(nominationUploadRepository.save(modelMapper.map(dto, Nomination.class)),NominationDto.class);
	}

	@Override
	public List<NominationDto> updateFeedBack(List<NominationDto> feedBackList) {
		LOGGER.info("In Update FeedBack");
		List<Nomination> updatedNominationList=new ArrayList<Nomination>();
		for(NominationDto employeeDto: feedBackList) {
			Nomination nomination=nominationUploadRepository.getById(employeeDto.getId());
			if(nomination!=null) {
				nomination.setFeedback(employeeDto.getFeedback());
				nomination.setAttitude(employeeDto.getAttitude());
				nomination.setTechnicalSkills(employeeDto.getTechnicalSkills());
				nomination.setCommSkills(employeeDto.getCommSkills());
				nomination.setOverAllRating(employeeDto.getOverAllRating());
				nomination.setWorkQuality(employeeDto.getWorkQuality());
				updatedNominationList.add(nominationUploadRepository.save(nomination));
			}
		}
		List<NominationDto> updatedNominationDtoList=modelMapper.map(updatedNominationList, List.class);
		return updatedNominationDtoList;
	}

	@Override
	public List<NominationDto> updateFinalScore(List<NominationDto> finalScoreList) {
		LOGGER.info("In Update Final Score");

		List<Nomination> updatedNominationList=new ArrayList<Nomination>();
		for(NominationDto employeeDto: finalScoreList) {
			Nomination nomination=nominationUploadRepository.getById(employeeDto.getId());
			if(nomination!=null) {
				nomination.setFinalScore(employeeDto.getFinalScore());
				updatedNominationList.add(nominationUploadRepository.save(nomination));
			}
		}
		List<NominationDto> updatedNominationDtoList=modelMapper.map(updatedNominationList, List.class);
		return updatedNominationDtoList;
	
	}
	
	
	@Override
	public NominationDto updateNomination(NominationDto dto) {
		LOGGER.info("In Save Nomination");
		Nomination	nominee=nominationUploadRepository.save(modelMapper.map(dto, Nomination.class));
		List<Attendance> attendanclist=attendanceRepository.findTranieeAttendanceData(nominee.getTrainingId(),nominee.getEmp_id());
		
		attendanclist.stream()
	    .map(employee -> {
	        employee.setEmploymentStatus(nominee.getEmployment_status());
	        return employee;
	    })
	    .collect(Collectors.toList());
		attendanceRepository.saveAll(attendanclist);
		return modelMapper.map(nominee,NominationDto.class);
	}



}
