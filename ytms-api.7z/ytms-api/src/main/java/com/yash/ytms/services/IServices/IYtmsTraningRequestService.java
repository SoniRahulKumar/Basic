package com.yash.ytms.services.IServices;

import java.security.Principal;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.yash.ytms.dto.ResponseWrapperDto;
import com.yash.ytms.dto.TrainingRequestFormDto;
import com.yash.ytms.dto.TrfWithNominationDto;

public interface IYtmsTraningRequestService {

    ResponseWrapperDto saveTrainingRequestForm(TrfWithNominationDto formDto, Principal principal);

    ResponseWrapperDto approveTrainingRequestForm(TrainingRequestFormDto formDto, Principal principal);

    ResponseWrapperDto declineTrainingRequestForm(TrainingRequestFormDto formDto);

    List<TrainingRequestFormDto> getTrainingRequestForm(Principal principal);
    
    List<TrainingRequestFormDto> getTrainingByStatus(String status);

    TrainingRequestFormDto getTrainingRequestFormById(long trainingId);

    ResponseWrapperDto editTrainingRequestForm(TrainingRequestFormDto formDto);

    ResponseWrapperDto uploadFile(MultipartFile file);

    List<String> getFileName();

    List<TrainingRequestFormDto> getTrainerTrainingList(Principal principal);

	List<TrainingRequestFormDto> getUpcomingTrainingList(Principal principal);
	
	 ResponseWrapperDto changeTrainingStatus(long id,String stats);
}
