package com.yash.jenkinspipeline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JenkinsPipelineApplication {

	public static void main(String[] args) {
		SpringApplication.run(JenkinsPipelineApplication.class, args);
	}

}
