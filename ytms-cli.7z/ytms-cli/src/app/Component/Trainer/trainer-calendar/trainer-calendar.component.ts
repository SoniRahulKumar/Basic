import { Component } from '@angular/core';

@Component({
  selector: 'app-trainer-calendar',
  templateUrl: './trainer-calendar.component.html',
  styleUrls: ['./trainer-calendar.component.css']
})
export class TrainerCalendarComponent {

}
