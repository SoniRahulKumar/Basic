package com.yash.ytms.domain;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="associate")
public class Associate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Double empId;
    private String empName;
    private String empEmailId;
    private String grade;
    private String competency;
    private String resourceType;
    private String trainingStack;
    private String trainingName;
    private String purposeToAttendTraining;
    private Integer trainingDuration;
    private LocalDate trainingStartDate;
    private LocalDate trainingEndDate;
    private String currentSkill;
    private String upgradedSkill;
    private String preAssessment;
    private Double finalScore;
    private String currentAllocation;
    private String project;
    private String currentLocation;
    private String status;
    private String feedback;

    //private Integer noOfTraining;
    //private Integer attendance;

}
