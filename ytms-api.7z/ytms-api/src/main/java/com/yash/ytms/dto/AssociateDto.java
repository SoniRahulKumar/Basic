package com.yash.ytms.dto;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import java.time.LocalDate;
import java.util.Date;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AssociateDto {

    //private Long id;
    private String emp_id;
    private String emp_name;
    private String emp_mail_id;
    private String grade;
    private String competency;
    //private String resourceType;
    //private String trainingStack;
    private Long trainingId;
    private String trainingName;
    private String trainingDescription;
    //private String purposeToAttendTraining;
    //private Integer trainingDuration;
    private Integer noOfDays;
    //private LocalDate trainingStartDate;
    //private LocalDate trainingEndDate;
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private Date actualStartDate;

    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private Date actualEndDate;
    private String skill;
    private String upgradedSkills;
    //private String preAssessment;
    //private Double finalScore;
    private String current_allocation;
    private String project;
    private String current_location;
    private String trainingStatus;
    private String feedback;
    private Double finalScore;
    private String trainer;
    
    private String attendancePercentage;
    
    

	public AssociateDto(String emp_id, String emp_name, String emp_mail_id, String grade, String competency, Long trainingId,
			String trainingName, String trainingDescription, Integer noOfDays, Date actualStartDate, Date actualEndDate,
			String skill, String upgradedSkills, String current_allocation, String project, String current_location,
			String trainingStatus, String feedback, Double finalScore, String trainer) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.emp_mail_id = emp_mail_id;
		this.grade = grade;
		this.competency = competency;
		this.trainingId = trainingId;
		this.trainingName = trainingName;
		this.trainingDescription = trainingDescription;
		this.noOfDays = noOfDays;
		this.actualStartDate = actualStartDate;
		this.actualEndDate = actualEndDate;
		this.skill = skill;
		this.upgradedSkills = upgradedSkills;
		this.current_allocation = current_allocation;
		this.project = project;
		this.current_location = current_location;
		this.trainingStatus = trainingStatus;
		this.feedback = feedback;
		this.finalScore = finalScore;
		this.trainer = trainer;
	}



	public AssociateDto(String emp_id, String emp_name, String emp_mail_id, String grade, String competency, String trainingName,
			String trainingDescription, Integer noOfDays, Date actualStartDate, Date actualEndDate, String skill,
			String upgradedSkills, String current_allocation, String project, String current_location,
			String trainingStatus, String feedback, Double finalScore, String trainer) {
		super();
		this.emp_id = emp_id;
		this.emp_name = emp_name;
		this.emp_mail_id = emp_mail_id;
		this.grade = grade;
		this.competency = competency;
		this.trainingName = trainingName;
		this.trainingDescription = trainingDescription;
		this.noOfDays = noOfDays;
		this.actualStartDate = actualStartDate;
		this.actualEndDate = actualEndDate;
		this.skill = skill;
		this.upgradedSkills = upgradedSkills;
		this.current_allocation = current_allocation;
		this.project = project;
		this.current_location = current_location;
		this.trainingStatus = trainingStatus;
		this.feedback = feedback;
		this.finalScore = finalScore;
		this.trainer = trainer;
	}
    
    

}
