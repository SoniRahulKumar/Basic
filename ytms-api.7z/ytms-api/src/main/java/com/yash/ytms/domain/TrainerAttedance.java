package com.yash.ytms.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@Entity
@Table(name = "trainer_attendance_report")
@Data
public class TrainerAttedance {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@Column
	private Long training_id;
	
	@Column
	private String tranier_mail_id;

	@Column
	private String tranier_name;

	@Column
	private String tranining_name;

	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column
	private Date leave_Start_date;
	@JsonFormat(pattern = "yyyy-MM-dd")
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
	@Column
	private Date leave_End_date;

	@Column
	private String leave_status;

	@Column
	private String aprrove_by;

	@Column
	private String leave_impact_on_traning;
	
	@JsonIgnore
	@OneToMany(mappedBy  = "trainerAttedance")
	private List<TrainerAttedanceDate> trainerAttendanceDates = new ArrayList<>();


}
