package com.yash.dtoexcelconvertor.Convertor;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletResponse;

import com.yash.dtoexcelconvertor.dto.TrainingReqForm;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelGenerator {

    private final List<TrainingReqForm> trainingReqFormList;
    private final XSSFWorkbook workbook;
    private XSSFSheet sheet;

    public ExcelGenerator(List<TrainingReqForm> trainingReqFormList) {
        this.trainingReqFormList = trainingReqFormList;
        workbook = new XSSFWorkbook();
    }

    private void writeHeader() {
        sheet = workbook.createSheet("TrainingReqForm");
        Row row = sheet.createRow(0);
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setBold(true);
        font.setFontHeight(16);
        style.setFont(font);
        createCell(row, 0, "ID", style);
        createCell(row, 1, "TrainingIdentifierName", style);
        createCell(row, 2, "TrainingDescription", style);
        createCell(row, 3, "StartDate", style);
        createCell(row, 4, "EndDate", style);
        createCell(row, 5, "ActualStartDate", style);
        createCell(row, 6, "ActualEndDate", style);
        createCell(row, 7, "CreatedAt", style);
        createCell(row, 8, "UpdatedAt", style);
        createCell(row, 9, "Status", style);
        createCell(row, 10, "UserName", style);
        createCell(row, 11, "NoOfParticipant", style);
        createCell(row, 12, "DeclinedMessage", style);

    }

    private void createCell(Row row, int columnCount, Object valueOfCell, CellStyle style) {
        sheet.autoSizeColumn(columnCount);
        Cell cell = row.createCell(columnCount);
        if (valueOfCell instanceof Integer) {
            cell.setCellValue((Integer) valueOfCell);
        } else if (valueOfCell instanceof Long) {
            cell.setCellValue((Long) valueOfCell);
        } else if (valueOfCell instanceof String) {
            cell.setCellValue((String) valueOfCell);
        } else {
            cell.setCellValue((Date) valueOfCell);
        }
        cell.setCellStyle(style);
    }

    private void write() {
        int rowCount = 1;
        CellStyle style = workbook.createCellStyle();
        XSSFFont font = workbook.createFont();
        font.setFontHeight(14);
        style.setFont(font);
        for (TrainingReqForm record : trainingReqFormList) {
            Row row = sheet.createRow(rowCount++);
            int columnCount = 0;
            createCell(row, columnCount++, record.getId(), style);
            createCell(row, columnCount++, record.getTrainingIdentifierName(), style);
            createCell(row, columnCount++, record.getTrainingDescription(), style);
            createCell(row, columnCount++, record.getStartDate(), style);
            createCell(row, columnCount++, record.getEndDate(), style);
            createCell(row, columnCount++, record.getActualStartDate(), style);
            createCell(row, columnCount++, record.getActualEndDate(), style);
            createCell(row, columnCount++, record.getCreatedAt(), style);
            createCell(row, columnCount++, record.getUpdatedAt(), style);
            createCell(row, columnCount++, record.getStatus(), style);
            createCell(row, columnCount++, record.getUserName(), style);
            createCell(row, columnCount++, record.getNoOfParticipant(), style);
            createCell(row, columnCount++, record.getDeclinedMessage(), style);
        }
    }

    public void generateExcelFile(HttpServletResponse response) throws IOException {
        writeHeader();
        write();
        ServletOutputStream outputStream = response.getOutputStream();
        workbook.write(outputStream);
        workbook.close();
        outputStream.close();
    }

    public static void setWorkbook(HttpServletResponse response) throws IOException {

        response.setContentType("application/octet-stream");
        DateFormat dateFormatter = new SimpleDateFormat("yyyy-MM-dd_HH:mm:ss");
        String currentDateTime = dateFormatter.format(new Date());

        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=student" + currentDateTime + ".xlsx";
        response.setHeader(headerKey, headerValue);

        List<TrainingReqForm> trainingReqFormList = new ArrayList<>();
        TrainingReqForm trainingReqForm = new TrainingReqForm();
        trainingReqForm.setId(1);
        trainingReqForm.setTrainingIdentifierName("A");
        trainingReqForm.setTrainingDescription("A");
        trainingReqForm.setStartDate(new Date());
        trainingReqForm.setEndDate(new Date());
        trainingReqForm.setActualStartDate(new Date());
        trainingReqForm.setActualEndDate(new Date());
        trainingReqForm.setStatus("status");
        trainingReqForm.setCreatedAt(new Date());
        trainingReqForm.setUpdatedAt(new Date());
        trainingReqForm.setNoOfParticipant(10);
        trainingReqForm.setUserName("userName");
        trainingReqForm.setDeclinedMessage("message");

        trainingReqFormList.add(trainingReqForm);

        ExcelGenerator excelGenerator = new ExcelGenerator(trainingReqFormList);

        excelGenerator.generateExcelFile(response);
    }

}
