package com.yash.ytms.schedular;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.yash.ytms.constants.AppConstants;
import com.yash.ytms.repository.TrainingRequestRepository;

/**
 * @author shubham.nimase
 */
@Component
public class ChangeTrainingStatusScheduler {

	final Logger logger = LoggerFactory.getLogger(ChangeTrainingStatusScheduler.class);

	private TrainingRequestRepository requestRepository;

	public ChangeTrainingStatusScheduler(TrainingRequestRepository requestRepository) {
		this.requestRepository = requestRepository;
	}

	/**
	 * @author shubham.nimase
	 * @apiNote Running scheduled task at 10 AM and 2 PM on weekdays.
	 */
	@Scheduled(cron = "0 10 14 ? * MON-FRI")
//	@Scheduled(fixedDelay = 100000, initialDelay = 1000)
	public void changeTrainingStatus() {
		logger.info("In ChangeTrainingStatusScheduler - changeTrainingStatus()");

		List<Long> startedTrainings = requestRepository.getPlannedButStartedTrainings();

		try {
			startedTrainings.stream().forEach(id -> requestRepository.findById(id).ifPresent(obj -> {
				obj.setTrainingStatus(AppConstants.TRAINING_STATUS_INPROGRESS);
				requestRepository.save(obj);
			}));
		} catch (Exception e) {
			logger.error("Exception Occurred in ChangeTrainingStatusScheduler - changeTrainingStatus() :- {}",
					e.getLocalizedMessage());
		}

		logger.info("Out ChangeTrainingStatusScheduler - changeTrainingStatus()");
	}

}
