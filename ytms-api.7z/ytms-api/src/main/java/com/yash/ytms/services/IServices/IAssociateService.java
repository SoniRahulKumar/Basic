package com.yash.ytms.services.IServices;

import com.yash.ytms.dto.AssociateDto;
import com.yash.ytms.dto.AssociateExcelDto;
import com.yash.ytms.dto.TrainingRequestFormDto;

import org.springframework.data.repository.query.Param;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

public interface IAssociateService {
    List<AssociateExcelDto> parseExcel(MultipartFile file) throws IOException;

    List<AssociateDto> getAllAssociateTrainings();
    
    List<AssociateDto> findAllAssociateTrainingByMailId(String empId);

}
