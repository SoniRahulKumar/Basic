package com.yash.ytms.constants;

/**
 * Project Name - ytms-api
 * <p>
 * IDE Used - IntelliJ IDEA
 *
 * @author - yash.raj
 * @since - 29-01-2024
 */
public enum UserAccountStatusTypes {

    APPROVED,

    PENDING,

    DECLINED,
    
    PLANNED
}
