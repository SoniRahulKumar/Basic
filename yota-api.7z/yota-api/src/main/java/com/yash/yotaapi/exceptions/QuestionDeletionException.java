package com.yash.yotaapi.exceptions;

public class QuestionDeletionException extends RuntimeException{
    public QuestionDeletionException(String message){
        super(message);
    }
}