export const Footer = () => {

    return (
        <footer className={"py-3 my-4 fixed-bottom"}>
            <p className="text-center text-body-secondary">© 2024 YASH Technologies Pvt. Ltd.</p>
        </footer>
    )
};
