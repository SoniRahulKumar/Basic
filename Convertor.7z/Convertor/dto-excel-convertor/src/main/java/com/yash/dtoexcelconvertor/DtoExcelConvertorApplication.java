package com.yash.dtoexcelconvertor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DtoExcelConvertorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DtoExcelConvertorApplication.class, args);
	}

}
